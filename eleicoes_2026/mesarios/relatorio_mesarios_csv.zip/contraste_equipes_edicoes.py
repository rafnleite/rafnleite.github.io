"""Confere a única troca de título entre os grupos de abertura e fechamento.

O grupo de uma etapa inclui todos os títulos com registro positivo no ciclo
de presença explicitamente identificado pelo VOTA. A comparação está limitada
à mesma seção e ao turno da duplicidade. Uma linha por candidato e seção.
"""
import csv
from collections import Counter, defaultdict

from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify


def ref(eventos):
    return " | ".join(f"{e['data_hora']} · urna {e['urna']} · {e['membro']}:{e['linha']} · {e['etapa']}"
                      for e in eventos)


def auditar(grupo, equipes):
    caso=grupo[0]
    chave=identify(caso)
    repetido,alternativo=caso["titulo"],caso["titulo_alternativo"]
    atual=equipes[chave]
    outro=equipes[(str(3-int(chave[0])),*chave[1:])]
    rep=[e for e in atual["registros"] if e["titulo"]==repetido]
    alt=[e for e in atual["registros"] if e["titulo"]==alternativo]
    alt_outro=[e for e in outro["registros"] if e["titulo"]==alternativo]
    if not rep or bool(alt)!=any(x["turno"]==x["turno_fonte"] for x in grupo):
        raise ValueError(f"Registros do candidato divergem dos logs para {chave}")
    abertura,encerramento=atual["equipe_abertura"],atual["equipe_encerramento"]
    comuns=atual["equipe_em_ambas"]
    direcao=""
    if abertura==encerramento==comuns+1:
        if atual["alvos_so_abertura"]==[alternativo] and atual["alvos_so_encerramento"]==[repetido]:
            direcao="alternativo na abertura; repetido no encerramento"
        if atual["alvos_so_abertura"]==[repetido] and atual["alvos_so_encerramento"]==[alternativo]:
            direcao="repetido na abertura; alternativo no encerramento"
    if direcao:
        resultado="Troca única entre as equipes"
    elif alt:
        resultado="Candidato no turno sem troca única entre as equipes"
    else:
        resultado="Candidato registrado somente no outro turno"
    return dict(id_caso=caso["id_caso"],turno=chave[0],titulo=repetido,titulo_alternativo=alternativo,
                operacoes_minimas=caso["custo_ampliado"],uf=chave[1],codigo_municipio=chave[2],
                municipio=caso["municipio"],zona=chave[3],secao=chave[4],local=atual["local"],nome=atual["nome"],
                resultado=resultado,troca_unica=int(bool(direcao)),direcao=direcao,
                equipe_abertura=abertura,equipe_encerramento=encerramento,equipe_em_ambas=comuns,
                exclusivos_abertura=abertura-comuns,exclusivos_encerramento=encerramento-comuns,
                presencas_repetido=ref(rep),presencas_alternativo=ref(alt),presencas_alternativo_outro_turno=ref(alt_outro),
                url=atual["url_log"],sha256=atual["sha256"],url_outro_turno=outro["url_log"],sha256_outro_turno=outro["sha256"])


def main():
    grupos=defaultdict(list)
    for r in linhas("duas_edicoes_pares.csv"):
        if r["fonte"]=="registro" and r["custo_ampliado"] in ("1","2"):
            grupos[(r["id_caso"],r["turno"],r["titulo"],*identify(r)[1:],r["titulo_alternativo"])].append(r)
    requeridas=set()
    for grupo in grupos.values():
        _,*s=identify(grupo[0])
        requeridas.update((t,*s) for t in ("1","2"))
    fontes={identify(r):r for r in linhas("manifesto.csv") if identify(r) in requeridas}
    enderecos={identify(r):r for r in linhas("enderecos.csv") if identify(r) in requeridas}
    qualificados=defaultdict(Counter)
    for r in linhas("registros_qualificados.csv"):
        k=identify(r)
        if k in requeridas:
            valor=(r["titulo"],r["data_hora"],r["urna"],r["tipo"],r["membro"],int(r["linha"]))
            qualificados[k][valor]+=1
    respostas=[]
    for chave_grupo,grupo in sorted(grupos.items()):
        chave=identify(grupo[0])
        titulos={grupo[0]["titulo"],grupo[0]["titulo_alternativo"]}
        equipes={}
        for t in ("1","2"):
            k=(t,*chave[1:])
            equipes[k]=ler_secao(fontes[k],enderecos[k],titulos,qualificados[k])
        respostas.append(auditar(grupo,equipes))
    arq=BASE/"contraste_equipes_edicoes.csv"
    with arq.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=respostas[0].keys())
        w.writeheader()
        w.writerows(respostas)
    print(len(respostas),"candidatos em seções; resultados:",dict(Counter(r["resultado"] for r in respostas)))


if __name__=="__main__":
    main()
