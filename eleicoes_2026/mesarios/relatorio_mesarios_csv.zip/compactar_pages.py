"""Prepara os dados interativos para a edição estática do GitHub Pages."""
import gzip
import hashlib
import re
from pathlib import Path


def _salvar_bloco(pasta, nome, texto):
    dados = gzip.compress(texto.encode("utf-8"), compresslevel=9, mtime=0)
    destino = pasta / "blocos" / (nome + ".gz")
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_bytes(dados)
    return f"blocos/{destino.name}?v={hashlib.sha256(dados).hexdigest()[:12]}"


def _compactar_json(html, identificador, arquivo, pasta):
    padrao = rf'(<script type="application/json" id="{identificador}")>(.*?)</script>'
    def substituir(m):
        caminho = _salvar_bloco(pasta, arquivo, m[2])
        return f'{m[1]} data-bloco-mesarios="{caminho}"></script>'

    resultado, n = re.subn(padrao, substituir, html, flags=re.S)
    if n != 1:
        raise ValueError(f"Bloco JSON não encontrado exatamente uma vez: {identificador}")
    return resultado


def destinos_dos_casos(html):
    """Encontra exemplos, listas de equipes e comparações numéricas do capítulo."""
    destinos = {}
    for ident in re.findall(r'''\sid=["']([^"']+)["']''', html):
        caso = re.fullmatch(r"(?:listas|exemplo)-(f-[12]-[ml]-[0-9a-f]+)", ident)
        analise = re.fullmatch(r"analise-([ml]-[0-9a-f]+)-([12])", ident)
        if caso:
            destinos.setdefault(caso[1], ident)
        elif analise:
            destinos[f"f-{analise[2]}-{analise[1]}"] = ident
    return destinos


def integrar_fichas(html, destinos):
    # O pacote offline tem dois anexos próprios. Na edição web, os exemplos
    # já mostram os trajetos e cada ficha em aberto já contém sua análise.
    html = re.sub(r"<p><a href='relatorio_tecnico\.html#[^']+'>Detalhes do trajeto no anexo técnico</a></p>", "", html)
    html = re.sub(r" <a [^>]*href='relatorio_tecnico\.html#[^']+'>Ver a análise do caso</a>\.", "", html)
    html = re.sub(r'<p class="fine">[^<>]*<a href="casos_em_aberto\.html">[^<>]*</a>\.</p>', "", html)
    html = html.replace(' · <a href="relatorio_tecnico.html">Anexo técnico e fichas por seção</a>', "")
    def destino(m):
        chave = m[1].replace("equipes-", "f-", 1)
        return "#" + destinos[chave]
    html = re.sub(r"relatorio_tecnico\.html#((?:f|equipes)-[12]-[ml]-[0-9a-f]+)", destino, html)
    # A abertura automática dos <details> logo a seguir cuida da âncora local.
    html = re.sub(r'const anterior = \(\) => \{[^\n]*relatorio_tecnico\.html[^\n]*\n'
                  r'anterior\(\);addEventListener\("hashchange",anterior\);\n', "", html)
    return html


def _ligar_leitor(html, posicao, descricao):
    # O JS da edição portátil espera os dados já no DOM. Inicializar esses
    # scripts na ordem original, depois que o conteúdo local estiver disponível.
    leitor = '<script src="../assets/mesarios-dados.js"></script>'
    padrao = re.compile(r'<script>(.*?)</script>', re.S)
    def apos_leitura(m):
        return ('<script>window.dadosMesariosProntos.then(function (prontos) {\n'
                'if (!prontos) return;\n' + m[1] + '\n});</script>')

    html, quantidade = padrao.subn(apos_leitura, html)
    if not quantidade:
        raise ValueError("Inicializador de página ausente")
    html = html.replace("<script>window.dadosMesariosProntos", leitor +
                        "<script>window.dadosMesariosProntos", 1)
    if html.count(posicao) != 1:
        raise ValueError("Local da mensagem sobre o carregamento não encontrado")
    estado = (f'<p id="estado-dados-mesarios" role="status" hidden>Carregando {descricao}…</p>'
              '<noscript><p>Os dados completos também estão no '
              '<a href="relatorio.html#arquivos">pacote para leitura offline</a>.</p></noscript>')
    return html.replace(posicao, estado + posicao, 1)


def preparar_web(nome, html, pasta_destino):
    """Retorna HTML para o Pages e grava os blocos comprimidos ao lado das páginas."""
    pasta = Path(pasta_destino)
    if nome == "relatorio.html":
        # A edição web contém links diretos aos mesmos CSVs. O pacote offline
        # continua com a cópia incorporada e seu manipulador de download.
        html, n = re.subn(r'<script type="application/json" id="csvs">.*?</script>', "", html, flags=re.S)
        html, m = re.subn(r'if \("DecompressionStream" in window\) \{\s*const dados=JSON\.parse\(document\.getElementById\("csvs"\)\.textContent\);.*?\n\}(?=\s*</script>)', "", html, flags=re.S)
        if (n, m) != (1, 1):
            raise ValueError("Revisar a cópia incorporada de CSVs do relatório principal")
        return html
    if nome == "sankey_turnos.html":
        html = _compactar_json(html, "dados", "sankey-casos.json", pasta)
        html = _compactar_json(html, "equipes-para-previa", "sankey-equipes.json", pasta)
        return _ligar_leitor(html, '<div class="cab-grafico">', "os casos do diagrama")
    return html
