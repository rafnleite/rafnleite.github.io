"""Confere nos pacotes os dois exemplos do relatório ilustrado.

Executar com Python 3.10+ depois de extrair.py e comparar.py.
"""
from __future__ import annotations

import csv
import io
import json
from collections import Counter, defaultdict
from datetime import datetime
from itertools import combinations
from zipfile import ZipFile

from extrair import BASE, DATES, TITLE_EVENT, encoding, identify, read_package
from geografia import distancia

ALTERNATIVO = "137009230523"
REPETIDO = "170092230523"
CASA = ("BA", "34436", "66", "249")
PORTO = ("BA", "38075", "122", "643")
MARCADORES = {
    "Registrando mesários antes da votação": "abertura",
    "Registrando mesários durante a votação": "durante a votação",
    "Registrando mesários após a votação": "encerramento",
    "Operador encerrou ciclo de registro de mesários": "fora do ciclo",
    "Operador selecionou: Registrar mesários": "registro pelo menu de votação",
}


def linhas(nome):
    with (BASE / nome).open(encoding="utf-8-sig", newline="") as f:
        yield from csv.DictReader(f)


def maior_caso():
    with ZipFile(BASE / "arvor.zip") as z, z.open("lista_mesarios.csv") as f:
        registros = list(csv.DictReader(io.TextIOWrapper(f, encoding="utf-8-sig")))
    def soma(r):
        return int(r["Seções 1º T"]) + int(r["Seções 2º T"])
    maior = max(map(soma, registros))
    (caso,) = [r for r in registros if soma(r) == maior]
    return caso["ID de auditoria"], maior


def vinculo_eleitoral(linhas_log, num, codec, dia, serie, titulo):
    """Localiza a declaração anterior à confirmação, admitindo telemetria intercalada."""
    for indice in range(num - 2, -1, -1):
        anterior = linhas_log[indice].decode(codec).rstrip("\r").split("\t")
        if len(anterior) != 6 or anterior[0][:10] != dia or anterior[2:4] != [serie, "VOTA"]:
            break
        msg = anterior[4]
        if msg == f"Mesário {titulo} é eleitor da seção":
            return "sim", indice + 1
        if msg == f"Mesário {titulo} não é eleitor da seção":
            return "não", indice + 1
        if not msg.startswith(("Espaço livre na ", "Espaço utilizado na ", "Quantidade de memória ",
                               "Urna ligada conectada na rede CA em ")):
            break
    return "", None


def ler_secao(fonte, endereco, titulos, qualificados):
    """Lê os bytes do JEZ e associa os marcadores de etapa na mesma série e data."""
    sha, membros = read_package({**fonte, "_path": BASE / fonte["arquivo"]})
    chave = identify(fonte)
    turno = chave[0]
    grupos = defaultdict(set)
    eventos = defaultdict(list)
    observados = Counter()
    for membro, bruto in membros:
        codec = encoding(bruto)
        marcadores = {}
        linhas_log = bruto.split(b"\n")
        for num, raw in enumerate(linhas_log, 1):
            partes = raw.decode(codec).rstrip("\r").split("\t")
            if len(partes) != 6:
                continue
            data_hora, _, serie, aplicativo, msg, _ = partes
            dia = data_hora[:10]
            if dia not in DATES[turno] or aplicativo != "VOTA":
                continue
            if msg in MARCADORES:
                marcadores[dia, serie] = MARCADORES[msg], num
                continue
            evento = TITLE_EVENT.fullmatch(msg)
            if not evento:
                continue
            titulo, verbo = evento.groups()
            tipo = "registro" if verbo == "registrado" else "habilitacao"
            etapa, linha_marcador = marcadores.get((dia, serie), ("indeterminada", None))
            identidade = (titulo, data_hora, serie, tipo, membro, num)
            # A base qualificada confere a fase oficial e a identidade da seção.
            if identidade not in qualificados:
                continue
            observados[identidade] += 1
            if tipo == "registro":
                grupos[etapa].add(titulo)
            if titulo in titulos:
                item = dict(titulo=titulo, data_hora=data_hora, urna=serie,
                            etapa=etapa, membro=membro, linha=num, linha_marcador=linha_marcador)
                if tipo == "registro":
                    vinculo, linha_vinculo = vinculo_eleitoral(linhas_log, num, codec, dia, serie, titulo)
                    item.update(eleitor_da_secao=vinculo, linha_eleitor_da_secao=linha_vinculo)
                eventos[tipo].append(item)
    if observados != qualificados:
        raise ValueError(f"As linhas físicas divergem do índice qualificado: {chave}")
    abertura, fechamento = grupos["abertura"], grupos["encerramento"]
    def selecionar(tipo):
        return sorted(eventos[tipo], key=lambda r: (r["data_hora"], r["linha"]))
    return dict(turno=int(turno), uf=chave[1], codigo_municipio=chave[2], municipio=fonte["municipio"],
                zona=int(chave[3]), secao=int(chave[4]), local=endereco["local"], nome=endereco["nome"],
                endereco=endereco["endereco"], bairro=endereco["bairro"], cep=endereco["cep"],
                latitude=endereco["latitude"], longitude=endereco["longitude"], local_arvor=fonte["local"],
                urnas=sorted({r["urna"] for r in eventos["registro"]}), registros=selecionar("registro"),
                habilitacoes=selecionar("habilitacao"), equipe_abertura=len(abertura),
                equipe_encerramento=len(fechamento), equipe_em_ambas=len(abertura & fechamento),
                alvos_so_abertura=sorted(titulos & (abertura-fechamento)),
                alvos_so_encerramento=sorted(titulos & (fechamento-abertura)),
                arquivo=fonte["arquivo"], sha256=sha, url_log=fonte["url_log"])


def resumir_sp(secoes):
    urnas, locais, chaves_secao, enderecos = set(), set(), set(), set()
    eventos = []
    for s in secoes:
        urnas.update(s["urnas"])
        locais.add((s["uf"], s["codigo_municipio"], s["zona"], s["local"]))
        chaves_secao.add((s["uf"], s["codigo_municipio"], s["zona"], s["secao"]))
        enderecos.add((s["municipio"], s["endereco"], s["bairro"]))
        eventos.extend(s["registros"])
    return dict(secoes_turno=len(secoes), secoes_distintas=len(chaves_secao), urnas_distintas=len(urnas),
                locais_distintos=len(locais), enderecos_distintos=len(enderecos), registros=len(eventos),
                registros_abertura=sum(e["etapa"]=="abertura" for e in eventos),
                registros_encerramento=sum(e["etapa"]=="encerramento" for e in eventos),
                habilitacoes=sum(len(s["habilitacoes"]) for s in secoes))


def coordenada(s):
    return float(s["latitude"]), float(s["longitude"])


def main():
    id_sp, total_publicado = maior_caso()
    casos = list(linhas("todos_casos.csv"))
    (sp,) = [r for r in casos if r["id_caso"] == id_sp]
    (ba,) = [r for r in casos if r["titulo"] == REPETIDO and r["turno"] == "2"]
    chaves_sp = {identify(r) for r in linhas("vinculos.csv") if r["id"] == id_sp}
    chaves_ba = {(t, *s) for t in ("1", "2") for s in (CASA, PORTO)}
    procuradas = chaves_sp | chaves_ba
    fontes = {identify(r): r for r in linhas("manifesto.csv") if identify(r) in procuradas}
    locais = {identify(r): r for r in linhas("enderecos.csv") if identify(r) in procuradas}
    qualificados = defaultdict(Counter)
    for r in linhas("registros_qualificados.csv"):
        chave = identify(r)
        if chave in procuradas:
            item = (r["titulo"], r["data_hora"], r["urna"], r["tipo"], r["membro"], int(r["linha"]))
            qualificados[chave][item] += 1
    def seções(chaves, titulos):
        result = [ler_secao(fontes[k], locais[k], titulos, qualificados[k]) for k in chaves]
        return sorted(result, key=lambda r:(r["turno"], r["municipio"], r["zona"], r["secao"]))
    ss = seções(chaves_sp, {sp["titulo"]})
    bs = seções(chaves_ba, {REPETIDO, ALTERNATIVO})
    if len(ss) != total_publicado:
        raise ValueError("Quantidade de seções-turno divergente da lista por identificador")
    por_turno = {str(t): resumir_sp([s for s in ss if s["turno"]==t]) for t in (1,2)}
    sp1 = [s for s in ss if s["turno"]==1]
    ultimos = sorted([(r["data_hora"],s) for s in sp1 for r in s["registros"] if r["data_hora"][11:]>="17:00:00"],
                     key=lambda par: par[0])
    data = lambda texto: datetime.strptime(texto,"%d/%m/%Y %H:%M:%S")
    deslocamentos = [
        dict(secao_origem=a["secao"], hora_origem=x, secao_destino=b["secao"], hora_destino=y,
             segundos=int((data(y)-data(x)).total_seconds()),
             distancia_reta_km=round(distancia(coordenada(a),coordenada(b)),4))
        for (x,a),(y,b) in zip(ultimos,ultimos[1:]) if a["secao"]!=b["secao"]]
    distancias = [distancia(coordenada(a),coordenada(b)) for a,b in combinations(sp1,2)]
    sp_dados = dict(id_caso=id_sp, titulo_repetido=sp["titulo"], secoes=ss,
                    resumo=dict(por_turno=por_turno, ambos=resumir_sp(ss),
                                registros_apos_17h_1t=len(ultimos), inicio_apos_17h_1t=ultimos[0][0], fim_apos_17h_1t=ultimos[-1][0],
                                janela_apos_17h_1t_s=int((data(ultimos[-1][0])-data(ultimos[0][0])).total_seconds()),
                                distancia_min_entre_locais_km=round(min(distancias),4),
                                distancia_max_entre_locais_km=round(max(distancias),4)),
                    deslocamentos_apos_17h_1t=deslocamentos)
    # Conservamos a primeira cópia do 2 na correspondência visual; o log não
    # distingue entre as duas cópias adjacentes.
    intermediario = ALTERNATIVO[:1] + ALTERNATIVO[2:]
    resultado = intermediario[:6] + ALTERNATIVO[6] + intermediario[6:]
    if resultado != REPETIDO:
        raise ValueError("A transformação indicada não reproduziu o título do log")
    b2=[s for s in bs if s["turno"]==2]
    instantes=[data(r["data_hora"]) for s in b2 for r in s["registros"]
               if r["titulo"]==REPETIDO and r["etapa"]=="encerramento"]
    if len(instantes)!=2:
        raise ValueError("Esperado um registro de fechamento por seção no segundo turno da Bahia")
    bahia = dict(id_caso=ba["id_caso"], titulo_repetido=REPETIDO, titulo_alternativo=ALTERNATIVO,
                 secoes=bs, intervalo_encerramentos_s=int((max(instantes)-min(instantes)).total_seconds()),
                 distancia_reta_km=round(distancia(coordenada(b2[0]),coordenada(b2[1])),4),
                 comparacao=dict(origem=ALTERNATIVO, intermediario=intermediario, destino=resultado,
                                 posicao_omitida_na_origem=2, digito_omitido="3",
                                 posicao_duplicada_na_origem=7, digito_duplicado="2",
                                 alinhamento_origem=ALTERNATIVO[:7]+"–"+ALTERNATIVO[7:],
                                 alinhamento_destino=REPETIDO[:1]+"–"+REPETIDO[1:]))
    arquivo = BASE/"exemplos_ilustrados.json"
    arquivo.write_text(json.dumps(dict(bahia=bahia, sao_paulo=sp_dados),indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(f"Conferidos {len(procuradas)} pacotes e {sum(sum(c.values()) for c in qualificados.values())} eventos de presença ou habilitação das equipes.")


if __name__ == "__main__":
    main()
