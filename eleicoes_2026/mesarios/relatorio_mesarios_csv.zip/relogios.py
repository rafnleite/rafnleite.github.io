"""Testa um deslocamento contínuo com até cinco minutos de diferença entre relógios.

Cada número de série tem um ajuste constante no caso e no turno. Os ajustes podem
ser transladados para o intervalo [0, MARGEM_S] sem alterar as diferenças. O teste
considera as ordens de eventos compatíveis com essa faixa e com a ordem de cada
urna. Distâncias e tempos usam a mesma revisão cadastral dos trajetos publicados.
"""
import csv
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import pairwise
from math import ceil

from avaliar_sem_rota import CADASTRO, avaliar as avaliar_sem_rota
from geografia import DADOS, MESMO, datas_horas, ler_csv, secao
from logistica import checar_rota, rede


MARGEM_MIN = 5
MARGEM_S = 60 * MARGEM_MIN
# Hipótese favorável ao deslocamento terrestre quando falta uma rota utilizável:
# percurso retilíneo, sem paradas, a até 200 km/h. Não é uma velocidade observada.
LIMITE_TERRESTRE_KMH = 200
COMPATIVEL = "Compatível"
IMPROVAVEL = "Ainda improvável"
INDETERMINADO = "Indeterminado"
CSV_CASOS = DADOS / "relatorio" / f"relogios_{MARGEM_MIN}min.csv"
CSV_TRECHOS = DADOS / "relatorio" / f"relogios_{MARGEM_MIN}min_trechos.csv"
REDE = "Rota estimada"
GEOMETRICO = f"Linha reta a {LIMITE_TERRESTRE_KMH} km/h, sem paradas"
MESMO_LOCAL = "Mesmo local"
SEM_MEDIDA = "Sem coordenadas"


@dataclass(frozen=True)
class Evento:
    instante: int  # décimos de segundo desde o início do dia do turno
    secao: tuple
    urna: str
    hora: str
    tipo: str
    membro: str
    linha: int


@dataclass(frozen=True)
class Percurso:
    minimo: int  # décimos de segundo entre os eventos
    base: str
    modo: str = ""
    fonte: str = ""
    percurso_rede_km: float | str = ""
    tempo_com_folga_s: float | str = ""
    acesso_fora_rede_m: float | str = ""


def chave(r):
    return r["turno"], r["titulo"]


def percursos(pares, redes):
    caminhos = {}
    for (a, b), g in pares.items():
        mesmo = a[1:4] == b[1:4] and g["local_a"] == g["local_b"]
        for origem, destino in ((a, b), (b, a)):
            if mesmo:
                rota = Percurso(0, MESMO_LOCAL)
            else:
                # Menor duração utilizável entre carro e caminhada. O acesso
                # à malha já integra a duração calculada por checar_rota.
                opcoes = [checar_rota(g, origem, 86400, {modo: dados}) for modo, dados in redes.items()]
                medidas = [p for p in opcoes if p["tempo_trajeto_s"] != ""]
                if medidas:
                    melhor = min(medidas, key=lambda p: p["tempo_trajeto_s"])
                    rota = Percurso(round(melhor["tempo_trajeto_s"] * 10), REDE,
                                    melhor["modo"], melhor["fonte_rota"], melhor["percurso_rede_km"],
                                    melhor["tempo_com_folga_s"], melhor["acesso_fora_rede_m"])
                elif g["distancia_km"]:
                    minimo = float(g["distancia_km"]) * 36000 / LIMITE_TERRESTRE_KMH
                    rota = Percurso(ceil(minimo - 1e-9), GEOMETRICO)
                else:
                    rota = Percurso(0, SEM_MEDIDA)
            caminhos[origem, destino] = rota
    return caminhos


def caminho(caminhos, a, b):
    return Percurso(0, MESMO_LOCAL) if a.secao == b.secao else caminhos[a.secao, b.secao]


def solucao(eventos, caminhos, aceitar_sem_rota=False):
    """Busca exata nas ordens possíveis, com restrições de diferenças de relógio.

    Se i precede j por pelo menos D, então x[j] >= x[i] + D - (t[j]-t[i]).
    Relaxar todas essas desigualdades a partir de zero produz seus menores
    ajustes viáveis. Um ciclo positivo ou um ajuste acima da margem descarta o
    prefixo. A próxima ocorrência de um mesmo aparelho tem ordem fixa.
    """
    series = sorted({e.urna for e in eventos})
    indices = {s: i for i, s in enumerate(series)}
    fila = [[e for e in eventos if e.urna == s] for s in series]
    total = len(series)
    limite = 10 * MARGEM_S

    def relaxar(ajustes, regras):
        valores = ajustes.copy()
        for _ in range(total):
            mudou = False
            for i, j, peso in regras:
                minimo = valores[i] + peso
                if valores[j] < minimo:
                    if minimo > limite:
                        return None
                    valores[j] = minimo
                    mudou = True
            if not mudou:
                return valores
        return None

    def buscar(ordem, fronteira, ajustes, regras):
        if len(ordem) == len(eventos):
            return ordem, dict(zip(series, ajustes))
        candidatos = sorted((fila[i][p].instante, i) for i, p in enumerate(fronteira) if p < len(fila[i]))
        for instante, i in candidatos:
            if instante > candidatos[0][0] + limite:
                break
            prox = fila[i][fronteira[i]]
            novas = []
            if ordem:
                anterior = ordem[-1]
                rota = caminho(caminhos, anterior, prox)
                if not aceitar_sem_rota and rota.base in (GEOMETRICO, SEM_MEDIDA):
                    continue
                novas.append((indices[anterior.urna], i, rota.minimo - (instante - anterior.instante)))
            # Todos os demais primeiros eventos ainda pendentes seguem o atual.
            novas.extend((i, j, instante - t) for t, j in candidatos if j != i)
            restricoes = regras + novas
            valores = relaxar(ajustes, restricoes)
            if valores is not None:
                seguintes = fronteira.copy()
                seguintes[i] += 1
                resultado = buscar(ordem + [prox], seguintes, valores, restricoes)
                if resultado is not None:
                    return resultado
        return None

    return buscar([], [0] * total, [0] * total, [])


def dados_eventos(casos, pares):
    secoes = {k: {s for par in pp for s in par} for k, pp in pares.items()}
    por_caso = defaultdict(list)
    for r in ler_csv("registros_qualificados.csv"):
        k = chave(r)
        if k not in casos or secao(r) not in secoes[k]:
            continue
        h = datas_horas(r["data_hora"])
        t = 10 * (3600 * h.hour + 60 * h.minute + h.second)
        por_caso[k].append(Evento(t, secao(r), r["urna"], h.isoformat(" "), r["tipo"], r["membro"], int(r["linha"])))
    for k, eventos in por_caso.items():
        if len({e.hora[:10] for e in eventos}) != 1 or any(not e.urna for e in eventos):
            raise ValueError(f"Sem data única ou série de urna em {k}")
        eventos.sort(key=lambda e: (e.instante, e.secao, e.membro, e.linha))
    return por_caso


def descrever(a, b, pares, caminhos, ajustes, tipo, id_caso):
    par = tuple(sorted((a.secao, b.secao)))
    g = pares[par]
    percurso = caminho(caminhos, a, b)
    delta = (b.instante - a.instante) / 10
    ajustado = delta + (ajustes[b.urna] - ajustes[a.urna]) / 10 if ajustes is not None else ""
    maximo = abs(delta) + (MARGEM_S if a.urna != b.urna else 0)
    geometrico = percurso.base == GEOMETRICO
    r = dict(id_caso=id_caso, id_caso_revisao=g["id_caso"], turno=g["turno"], titulo=g["titulo"], base_trecho=percurso.base,
             modo=percurso.modo, fonte_rota=percurso.fonte, distancia_km=g["distancia_km"],
             percurso_rede_km=percurso.percurso_rede_km, tempo_com_folga_s=percurso.tempo_com_folga_s,
             acesso_fora_rede_m=percurso.acesso_fora_rede_m,
             fonte_distancia="Coordenadas dos locais de votação do TSE de 25/10/2026" if geometrico else "",
             url_fonte_distancia=CADASTRO if geometrico else "",
             tempo_trajeto_s=percurso.minimo/10 if percurso.base == REDE else "", intervalo_s=delta,
             intervalo_ajustado_s=round(ajustado, 1) if ajustado != "" else "",
             intervalo_maximo_entre_eventos_s=maximo,
             velocidade_minima_com_margem_kmh=(round(float(g["distancia_km"])*3600/maximo, 2)
                                                if g["distancia_km"] and maximo else ""),
             limite_terrestre_testado_kmh=LIMITE_TERRESTRE_KMH if geometrico else "",
             minimo_geometrico_s=percurso.minimo/10 if geometrico else "",
             tipo_sequencia=tipo)
    for lado, evento in (("origem", a), ("destino", b)):
        l = "a" if evento.secao == par[0] else "b"
        for col in ("uf", "codigo_municipio", "municipio", "zona", "secao", "local", "nome", "url"):
            r[col + "_" + lado] = g[col + "_" + l]
        r.update({"hora_" + lado: evento.hora, "urna_" + lado: evento.urna, "evento_" + lado: evento.tipo,
                  "membro_" + lado: evento.membro, "linha_" + lado: evento.linha,
                  "ajuste_" + lado + "_s": ajustes[evento.urna]/10 if ajustes is not None else ""})
    return r


def avaliar():
    casos = {chave(r):r for r in ler_csv("logistica_por_caso_revisao.csv") if r["avaliacao"] != MESMO}
    ids_catalogo = {chave(r):r["id_caso"] for r in ler_csv("todos_casos.csv")}
    pares = defaultdict(dict)
    for r in ler_csv("deslocamentos_revisao.csv"):
        if chave(r) in casos:
            pares[chave(r)][secao(r, "_a"), secao(r, "_b")] = r
    eventos = dados_eventos(casos, pares)
    redes = {"carro": rede("rotas.csv"), "a pé": rede("rotas_a_pe.csv")}
    contextuais = avaliar_sem_rota()
    resultados = {}
    for k, original in casos.items():
        id_caso = ids_catalogo[k]
        cronologia = eventos[k]
        caminhos = percursos(pares[k], redes)
        contexto = contextuais.get(k)
        if contexto and contexto["plausivel"]:
            # As transições efetivas deste caso foram conferidas individualmente
            # na revisão sem rota e já são plausíveis com os horários registrados.
            resultado = COMPATIVEL
            motivo = contexto["justificativa"]
            base = contexto["base"]
            testemunha = cronologia, {e.urna: 0 for e in cronologia}
        else:
            testemunha = solucao(cronologia, caminhos)
            if testemunha is not None:
                resultado, base = COMPATIVEL, REDE
                motivo = "Há uma sequência de eventos em que todos os trajetos estimados cabem com os mesmos ajustes por urna."
            else:
                faltam = any(p.base in (GEOMETRICO, SEM_MEDIDA) for p in caminhos.values())
                testemunha = solucao(cronologia, caminhos, aceitar_sem_rota=True) if faltam else None
                if testemunha is not None:
                    resultado, base = INDETERMINADO, "Sem estimativa de rota"
                    motivo = "Uma sequência satisfaz os limites disponíveis, mas ao menos um trecho carece de estimativa de percurso."
                else:
                    resultado, base = IMPROVAVEL, "Teste de todas as sequências viáveis"
                    motivo = f"Nenhuma sequência comporta os deslocamentos com ajustes fixos e diferença máxima de {MARGEM_MIN} minutos."
        ordem, ajustes = testemunha if testemunha is not None else (cronologia, None)
        tipo = ("Ordem registrada, sem solução" if ajustes is None else
                "Ordem ajustada" if ordem != cronologia else "Ordem registrada")
        trechos = [descrever(a, b, pares[k], caminhos, ajustes, tipo, id_caso) for a, b in pairwise(ordem)
                   if caminho(caminhos, a, b).base != MESMO_LOCAL]
        if not trechos:
            raise ValueError(f"Caso sem transição entre locais em {k}")

        def falta(r):
            referencia = r["intervalo_ajustado_s"] if ajustes is not None else r["intervalo_maximo_entre_eventos_s"]
            minimo = r["tempo_trajeto_s"] if r["tempo_trajeto_s"] != "" else r["minimo_geometrico_s"]
            return round(minimo - referencia, 1) if minimo != "" else float("-inf")

        ref = max(trechos, key=falta)
        deficit = max(0, falta(ref)) if falta(ref) != float("-inf") else ""
        tipo_ref = ("Trecho da sequência viável com menor folga" if ajustes is not None else
                    "Trecho de referência na ordem registrada, com margem máxima isolada")
        if resultado == IMPROVAVEL and ref["base_trecho"] == GEOMETRICO and ref["velocidade_minima_com_margem_kmh"]:
            velocidade = str(ref["velocidade_minima_com_margem_kmh"]).replace(".", ",")
            if ref["velocidade_minima_com_margem_kmh"] > LIMITE_TERRESTRE_KMH:
                base = GEOMETRICO
                motivo = (f"A distância em linha reta entre as seções e o intervalo máximo entre os dois registros "
                          f"exigiriam pelo menos {velocidade} km/h, mesmo com a margem de {MARGEM_MIN} minutos. "
                          f"O deslocamento terrestre é improvável até na hipótese de {LIMITE_TERRESTRE_KMH} km/h sem paradas.")
        if resultado == INDETERMINADO:
            ref = next(t for t in trechos if t["base_trecho"] in (SEM_MEDIDA, GEOMETRICO))
            tipo_ref, deficit = "Trecho sem duração de rota na sequência testada", ""
        if contexto and contexto["plausivel"]:
            def identificar(t):
                return tuple((t["hora_"+lado], t["membro_"+lado], str(t["linha_"+lado]),
                              str(t["secao_"+lado])) for lado in ("origem", "destino"))
            por_evento = {identificar(t):t for t in contexto["trechos"]}
            for t in trechos:
                p = por_evento[identificar(t)]
                if t["base_trecho"] != REDE:
                    medido = p["distancia_reta_km"] is not None
                    t["base_trecho"] = "Linha reta e intervalo entre eventos" if medido else "Município e intervalo entre eventos"
                    t["distancia_km"] = p["distancia_reta_km"] if medido else ""
                    t["minimo_geometrico_s"] = ""
                    t["limite_terrestre_testado_kmh"] = ""
                    t["velocidade_minima_com_margem_kmh"] = (round(t["distancia_km"]*3600/t["intervalo_maximo_entre_eventos_s"], 2)
                                                              if medido and t["intervalo_maximo_entre_eventos_s"] else "")
                    t["fonte_distancia"] = p["fonte_distancia"]
                    t["url_fonte_distancia"] = p["url_fonte_distancia"]
            ref = next(t for t in trechos if identificar(t) == identificar(contexto["trecho_principal"]))
            tipo_ref, deficit = "Trecho da revisão por município, distância disponível e horários", ""
        amplitude = (max(ajustes.values()) - min(ajustes.values())) / 10 if ajustes is not None else ""
        resultados[k] = dict(turno=k[0], titulo=k[1], id_caso=id_caso, id_caso_revisao=original["id_caso"], resultado=resultado,
                             base=base, motivo=motivo, avaliacao_anterior=original["avaliacao"],
                             margem_total_s=MARGEM_S, numero_eventos=len(cronologia), numero_urnas=len({e.urna for e in cronologia}),
                             trechos_entre_locais=len(trechos), amplitude_na_solucao_s=amplitude, tipo_sequencia=tipo,
                             ajustes_por_urna_s=(" | ".join(f"{s}={ajustes[s]/10:g}" for s in sorted(ajustes))
                                                if ajustes is not None else ""),
                             tipo_referencia=tipo_ref, deficit_referencia_s=deficit, trecho_referencia=ref, trechos=trechos)
    return resultados


def gravar_csv(analises):
    resumos, trechos = [], []
    for r in analises.values():
        resumo = {k:v for k,v in r.items() if k not in ("trecho_referencia", "trechos")}
        resumo.update({k:v for k,v in r["trecho_referencia"].items() if k not in resumo})
        resumos.append(resumo)
        trechos.extend(dict(t, resultado_caso=r["resultado"], base_caso=r["base"], ordem_trecho=i,
                            referencia=int(t is r["trecho_referencia"])) for i, t in enumerate(r["trechos"], 1))
    for arq, dados in ((CSV_CASOS, resumos), (CSV_TRECHOS, trechos)):
        with arq.open("w", encoding="utf-8-sig", newline="") as saida:
            escritor = csv.DictWriter(saida, fieldnames=dados[0].keys())
            escritor.writeheader()
            escritor.writerows(dados)
    return CSV_CASOS, CSV_TRECHOS


if __name__ == "__main__":
    resultado = avaliar()
    gravar_csv(resultado)
    print(Counter((r["turno"], r["resultado"]) for r in resultado.values()))
