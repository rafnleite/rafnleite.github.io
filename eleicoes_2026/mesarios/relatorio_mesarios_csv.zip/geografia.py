"""Cruza pares de registros individuais, coordenadas e horários do recorte."""
from __future__ import annotations

import csv
import io
from collections import defaultdict
from datetime import datetime
from itertools import combinations, product
from math import asin, cos, radians, sin, sqrt
from pathlib import Path
from zipfile import ZipFile

DADOS = Path(__file__).resolve().parent / "dados"
URL_CADASTRO_LOCAIS = "https://cdn.tse.jus.br/estatistica/sead/odsele/eleitorado_locais_votacao/eleitorado_local_votacao_2026.zip"
SHA256_CADASTRO_LOCAIS = "771ecfe5086b65c38943df9f694831dc5b94e0addd563517cd139fbd97642981"
LIMITE_KMH = 1000
MARGEM_S = 120
FORTE = "Deslocamento incompatível com o cenário"
OUTROS = "Locais distintos, deslocamento inconclusivo"
MESMO = "Mesmo local cadastrado"


def ler_zip(arquivo, nome):
    with io.TextIOWrapper(arquivo.open(nome), encoding="utf-8-sig", newline="") as entrada:
        yield from csv.DictReader(entrada)


def ler_csv(nome):
    with (DADOS / nome).open(encoding="utf-8-sig", newline="") as entrada:
        yield from csv.DictReader(entrada)


def secao(r, sufixo=""):
    mun = r.get("codigo_municipio" + sufixo) or r.get("mun" + sufixo)
    return (int(r["turno"]), r["uf" + sufixo].upper(), int(mun),
            int(r["zona" + sufixo]), int(r["secao" + sufixo]))


def distancia(a, b):
    if a is None or b is None:
        return None
    lat1, lon1 = map(radians, a)
    lat2, lon2 = map(radians, b)
    h = sin((lat2 - lat1) / 2) ** 2 + cos(lat1) * cos(lat2) * sin((lon2 - lon1) / 2) ** 2
    return 12742.018 * asin(min(1, sqrt(h)))


def localidades(z):
    coords = {}
    for r in ler_zip(z, "locais.csv"):
        ponto = (float(r["latitude"]), float(r["longitude"])) if r["latitude"] and r["longitude"] else None
        chave = (int(r["turno"]), r["uf"].upper(), int(r["codigo_municipio"]), int(r["zona"]), int(r["local"]))
        if chave in coords and coords[chave] != ponto:
            raise ValueError(f"Coordenadas divergentes no cadastro: {chave}")
        coords[chave] = ponto
    secoes = {}
    for r in ler_zip(z, "votos_por_secao.csv"):
        chave = secao(r)
        local = (*chave[:4], int(r["local"]))
        secoes[chave] = (local, coords[local], r["municipio"], r["nome"], r["url_log"])
    return secoes


def datas_horas(texto):
    for formato in ("%d/%m/%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(texto, formato)
        except ValueError:
            continue
    raise ValueError(f"Data sem interpretação: {texto}")


def gerar():
    with ZipFile(DADOS / "arvor.zip") as z:
        locais = localidades(z)
        pares = {tuple(sorted([secao(r, "_a"), secao(r, "_b")])): r
                 for r in ler_zip(z, "pares_de_secoes.csv")}
    grupos = defaultdict(list)
    for r in ler_csv("comparacao_secoes.csv"):
        grupos[(int(r["turno"]), r["titulo"], r["id_caso"])].append(secao(r))
    chaves = {(s,t) for (_,t,_),itens in grupos.items() for s in itens}
    horarios = defaultdict(list)
    for r in ler_csv("registros_qualificados.csv"):
        if r["tipo"] == "registro":
            chave = (secao(r), r["titulo"])
            if chave in chaves:
                horarios[chave].append(datas_horas(r["data_hora"]))

    campos = ["id_caso", "turno", "titulo", "avaliacao", "distancia_km", "intervalo_s", "fonte_intervalo",
              "hora_local_a", "hora_local_b", "km_h_min_com_margem", "alcance", "equipes_invertidas", "titulos_em_comum"]
    for lado in ("a", "b"):
        campos.extend(f"{col}_{lado}" for col in ("uf", "municipio", "codigo_municipio", "zona", "secao",
                                                  "local", "nome", "latitude", "longitude", "url"))
    with (DADOS / "deslocamentos.csv").open("w", encoding="utf-8-sig", newline="") as saida:
        gravar = csv.DictWriter(saida, fieldnames=campos)
        gravar.writeheader()
        for (turno, titulo, identificador), secoes in sorted(grupos.items()):
            for a, b in combinations(sorted(set(secoes)), 2):
                publicado = pares[a, b]
                local_a, ponto_a, *_ = locais[a]
                local_b, ponto_b, *_ = locais[b]
                dist = distancia(ponto_a, ponto_b)
                hora_a = hora_b = ""
                if a[1:3] == b[1:3]:
                    diferenca, ha, hb = min((abs((ha-hb).total_seconds()), ha, hb)
                                            for ha, hb in product(horarios[a,titulo], horarios[b,titulo]))
                    hora_a, hora_b = ha.isoformat(" "), hb.isoformat(" ")
                    fonte = "Registros do título nos dois arquivos, mesmo município"
                else:
                    if int(publicado["ids_em_comum"]) != 1:
                        raise ValueError(f"Intervalo publicado ambíguo: {a} {b}")
                    diferenca = int(publicado["menor_intervalo_registros_utc_s"])
                    fonte = "Menor intervalo em UTC da Arvor, um título comum no par"
                velocidade = (dist * 3600 / (diferenca + MARGEM_S)) if dist is not None else None
                avaliacao = MESMO if local_a == local_b else OUTROS
                if local_a != local_b and velocidade is not None and velocidade > LIMITE_KMH:
                    avaliacao = FORTE
                linha = dict(id_caso=identificador, turno=turno, titulo=titulo, avaliacao=avaliacao,
                             distancia_km=round(dist, 4) if dist is not None else "", intervalo_s=int(diferenca),
                             fonte_intervalo=fonte, hora_local_a=hora_a, hora_local_b=hora_b,
                             km_h_min_com_margem=round(velocidade, 2) if velocidade is not None else "",
                             alcance=publicado["alcance"], equipes_invertidas=publicado["equipes_de_quatro_invertidas"],
                             titulos_em_comum=publicado["ids_em_comum"])
                for lado,s in (("a",a), ("b",b)):
                    local, coord, municipio, nome, url = locais[s]
                    for col,val in zip(("uf", "municipio", "codigo_municipio", "zona", "secao", "local", "nome",
                                        "latitude", "longitude", "url"),
                                       (s[1],municipio,f"{s[2]:05}",s[3],s[4],local[-1],nome,
                                        coord[0] if coord else "",coord[1] if coord else "",url)):
                        linha[f"{col}_{lado}"] = val
                gravar.writerow(linha)


if __name__ == "__main__":
    gerar()
