"""Determina as divisas entre os municípios dos pares intermunicipais da Arvor.

Requer Python 3.11+, numpy, shapely==2.1.2 e pyshp==2.3.1. Os polígonos
da Malha Municipal Digital 2025 são comparados na resolução original, sem
buffer ou simplificação. Compara com a tabela Municípios Limítrofes 2024.
"""
import csv
import hashlib
import io
import re
import unicodedata
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import shapefile
from shapely.geometry import shape


DATA = Path(__file__).resolve().parent / "dados"
BASE = "https://geoftp.ibge.gov.br/organizacao_do_territorio/"
POLYGON = BASE + "malhas_territoriais/malhas_municipais/municipio_2025/Brasil/BR_Municipios_2025.zip"
TABLE = BASE + "estrutura_territorial/municipios_limitrofes/2024/BR_Municipios_2024_LIMITROFES.ods"


def official(url, digest):
    path = DATA / url.rsplit("/",1)[1]
    if not path.exists():
        temp = path.with_suffix(path.suffix + ".tmp")
        urllib.request.urlretrieve(url, temp)
        with temp.open("rb") as f:
            if hashlib.file_digest(f,"sha256").hexdigest() != digest:
                raise ValueError(f"Versão diferente da referência: {url}")
        temp.replace(path)
    with path.open("rb") as f:
        if hashlib.file_digest(f,"sha256").hexdigest() != digest:
            raise ValueError(f"SHA-256 divergente: {path}")
    return path


def name(value):
    return "".join(c for c in unicodedata.normalize("NFKD",value.upper()) if c.isalnum())


def official_limits(path):
    ns = "{urn:oasis:names:tc:opendocument:xmlns:table:1.0}"
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("content.xml"))
    table = next(t for t in root.iter(ns+"table") if t.get(ns+"name")=="Municípios Limítrofes")
    limits = {}
    for row in table.iter(ns+"table-row"):
        values = ["".join(cell.itertext()) for cell in row.iter(ns+"table-cell")]
        if len(values)>=6 and re.fullmatch(r"[0-9]{7}",values[0]):
            limits[values[0],values[3]] = float(values[5].replace(",","."))
    return limits


def run():
    shp = official(POLYGON,"840bbe6f73726ef9d1460ce49fdfe01a278935c41180d3c893e25ca21db083bd")
    ods = official(TABLE,"c811594801deca33a34dd5fed39521220d67daf0d57892a01ae2bb329ae1c95a")
    limits = official_limits(ods)
    with zipfile.ZipFile(DATA/"arvor.zip") as archive:
        with io.TextIOWrapper(archive.open("pares_de_secoes.csv"),encoding="utf-8-sig",newline="") as f:
            pairs = [r for r in csv.DictReader(f) if (r["uf_a"],r["mun_a"]) != (r["uf_b"],r["mun_b"])]
    targets = {(r["uf_"+s].upper(),name(r["municipio_"+s])) for r in pairs for s in ("a","b")}
    shapes = {}
    with zipfile.ZipFile(shp) as z:
        with shapefile.Reader(**{ext: io.BytesIO(z.read(f"BR_Municipios_2025.{ext}"))
                                  for ext in ("shp","shx","dbf")},encoding="utf-8") as layer:
            for rec in layer.iterRecords():
                key = rec.SIGLA_UF,name(rec.NM_MUN)
                if key in targets:
                    if key in shapes:
                        raise ValueError(f"Nome ambíguo na UF: {key}")
                    poly = shape(layer.shape(rec.oid).__geo_interface__)
                    if not poly.is_valid:
                        raise ValueError(f"Polígono inválido: {key}")
                    shapes[key] = rec.CD_MUN,poly
    if targets != shapes.keys():
        raise ValueError(f"Municípios sem correspondência: {targets-shapes.keys()}")
    rows = []
    for pair in pairs:
        r = {"turno":pair["turno"]}
        pol = []
        for s in ("a","b"):
            uf = pair["uf_"+s].upper()
            city = pair["municipio_"+s]
            code,geom = shapes[uf,name(city)]
            pol.append(geom)
            for column,val in [("uf",uf),("codigo_municipio",pair["mun_"+s].zfill(5)),
                               ("municipio",city),("zona",pair["zona_"+s]),("secao",pair["secao_"+s]),("ibge",code)]:
                r[column+"_"+s] = val
        line = pol[0].boundary.intersection(pol[1].boundary)
        contact = "sem contato" if line.is_empty else "trecho de divisa" if line.length>0 else "somente ponto"
        neighbors = contact=="trecho de divisa"
        length = limits.get((r["ibge_a"],r["ibge_b"]))
        if length != limits.get((r["ibge_b"],r["ibge_a"])):
            raise ValueError("Tabela IBGE assimétrica.")
        r.update(vizinhos=int(neighbors),contato=contact,limite_km_ibge_2024=length,ano_malha=2025,
                 fonte_malha=POLYGON,fonte_tabela=TABLE)
        rows.append(r)
    if len(rows)!=43:
        raise ValueError("Cobertura diferente dos 43 pares intermunicipais.")
    path = DATA/"vizinhanca.csv"
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f,fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)
    print(len(rows),"pares;",sum(r["vizinhos"] for r in rows),"com trecho de divisa;",
          sum(r["contato"]=="somente ponto" for r in rows),"apenas um ponto;",
          sum(bool(r["vizinhos"]) != bool(r["limite_km_ibge_2024"]) for r in rows),"divergentes da tabela de 2024.")


if __name__ == "__main__":
    run()
