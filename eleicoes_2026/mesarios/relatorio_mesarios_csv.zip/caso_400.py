"""Conferência do número 400 nos dois turnos em Mogi Mirim e Petrópolis."""
from collections import Counter
from html import escape

from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify, team_scan
from nota_dv import NORMA, calcular
from paineis_casos import original, tabela


TITULO = "000000000400"
HIPOTESE_MOGI = "177371350183"
MESAS = (("SP", "67172", "75", "201"), ("RJ", "58777", "29", "93"))


def hipotese_em_mogi(mesas):
    fases = {(turno, etapa): [r for r in mesa["registros"] if r["etapa"] == etapa]
             for turno, mesa in mesas.items() for etapa in ("abertura", "encerramento")}
    grupos = {k: {r["titulo"] for r in registros} for k, registros in fases.items()}
    colegas = grupos[1, "encerramento"]
    if (len(colegas) != 3 or colegas & {TITULO, HIPOTESE_MOGI}
            or grupos[1, "abertura"] != colegas | {TITULO}
            or not all(grupos[2, etapa] == colegas | {HIPOTESE_MOGI}
                       and fases[2, etapa][0]["titulo"] == HIPOTESE_MOGI for etapa in ("abertura", "encerramento"))):
        raise ValueError("Rever a composição das equipes que sustenta a hipótese de Mogi Mirim")
    abertura = fases[2, "abertura"][0]
    encerramento = fases[2, "encerramento"][0]
    return (f"<p><strong>Qual título se pretendia registrar em Mogi Mirim?</strong> "
            f"Considero <code>{HIPOTESE_MOGI}</code> o título mais provável. Na seção 201, os mesmos três outros "
            f"títulos aparecem na abertura e no encerramento dos dois turnos. A única diferença entre as duas listas "
            f"de abertura está no primeiro registro. No 1º turno, ele foi <code>{TITULO}</code>. No 2º, foi "
            f"<code>{HIPOTESE_MOGI}</code>, às {abertura['data_hora'][11:]} (linha {abertura['linha']}). Esse último número também foi "
            f"o primeiro no encerramento do 2º turno, às {encerramento['data_hora'][11:]} (linha {encerramento['linha']}).</p>"
            f"<p>Nos dois números de 12 dígitos, só coincide o zero da 9ª posição. Isso afasta a hipótese de um simples "
            f"erro de digitação. Se o título pretendido em Mogi Mirim era <code>{HIPOTESE_MOGI}</code>, considero "
            f"o registro de <code>{TITULO}</code> um <strong>erro de operação da urna</strong> ao cadastrar o mesário. "
            "Uma substituição de integrante entre os turnos também é compatível com as listas. Por isso, o título "
            "que se pretendia registrar no 1º turno em Mogi Mirim permanece incerto.</p>")


def painel_mogi_petropolis():
    chaves = [(t, *mesa) for t in ("1", "2") for mesa in MESAS]
    fontes = {identify(r): r for r in linhas("manifesto.csv") if identify(r) in chaves}
    enderecos = {identify(r): r for r in linhas("enderecos.csv") if identify(r) in chaves}
    if calcular(TITULO[:8], TITULO[8:10])[2] != TITULO[-2:]:
        raise ValueError("Rever o cálculo dos dígitos verificadores do número 400")
    quadro = []
    mesas_mogi = {}
    for chave in chaves:
        fonte = fontes[chave]
        _, _, eventos, _, _ = team_scan({**fonte, "_path": BASE / fonte["arquivo"]})
        titulos = {ev[0] for ev in eventos}
        mesa = ler_secao(fonte, enderecos[chave], titulos, Counter(eventos))
        if mesa["uf"] == "SP":
            mesas_mogi[mesa["turno"]] = mesa
        registros_400 = [r for r in mesa["registros"] if r["titulo"] == TITULO]
        abertura = [r for r in mesa["registros"] if r["etapa"] == "abertura"]
        hab = sum(r["titulo"] == TITULO for r in mesa["habilitacoes"])
        primeiro_turno = mesa["turno"] == 1
        if not abertura or registros_400 != (abertura[:1] if primeiro_turno else []):
            raise ValueError(f"Rever as ocorrências do número 400 em {chave}")
        if hab != (7 if primeiro_turno and mesa["uf"] == "SP" else 0):
            raise ValueError(f"Rever as habilitações atribuídas ao número 400 em {chave}")
        presenca = (f"<b>1º registro</b> às {registros_400[0]['data_hora'][11:]} "
                    f"(linha {registros_400[0]['linha']})" if primeiro_turno else "Ausente")
        quadro.append((f"{escape(mesa['municipio'].title())}/{mesa['uf']} · Z{mesa['zona']} S{mesa['secao']}",
                       f"{mesa['turno']}º", f"{presenca} · {mesa['equipe_abertura']} títulos",
                       f"Ausente · {mesa['equipe_encerramento']} títulos", original(mesa)))
    registros = tabela(("Seção", "Turno", "400 na abertura", "400 no encerramento", "Fonte"), quadro)
    return f"""<article id="caso-mogi-petropolis"><h4>Mogi Mirim/SP e Petrópolis/RJ · o número 400</h4>
<p>Nas duas urnas, o primeiro título aceito na abertura do 1º turno foi <code>{TITULO}</code>,
ou <strong>400</strong> sem os zeros à esquerda. A grafia chama a atenção porque os oito algarismos
da sequência são zeros. O código <code>04</code> corresponde ao Rio Grande do Sul e os dois dígitos
verificadores calculados são <code>00</code>. O número é válido nesse teste. A existência de uma
inscrição emitida com ele exigiria confirmação no cadastro eleitoral.
<a href="{NORMA}">Resolução TSE nº 23.659/2021, art. 36</a>.</p>
<p>Em Petrópolis, quatro outros títulos vieram logo depois do 400. Foram esses quatro que
compuseram a abertura do 2º turno. Em Mogi Mirim, a urna registrou três tentativas com títulos
inválidos antes de aceitar o 400 (linhas 533 a 539). Nas duas seções, ele ficou fora do
encerramento do 1º turno e de todos os registros de mesário do 2º turno.</p>
{registros}
{hipotese_em_mogi(mesas_mogi)}
<p>Em Mogi Mirim, o log atribui ao 400 sete habilitações de eleitores no 1º turno.
Cada habilitação vincula ao número informado uma autorização para o eleitor prosseguir.
O voto é uma operação posterior, realizada pelo eleitor na cabine. A combinação do número incomum, da posição idêntica nas duas
aberturas e das três tentativas inválidas em Mogi Mirim torna o <strong>mau uso da função de
cadastro de mesários</strong> a explicação que considero mais provável. A identidade de quem
digitou o número e sua intenção permanecem desconhecidas.</p></article>"""
