"""Conferência suplementar dos cinco pares entre locais sem ponto na edição de 25/10.

Os pontos externos são transcritos com fontes e ressalvas explícitas. O
resultado não substitui a análise de base, nem converte linha reta em trajeto.
"""
import csv
import io
import zipfile
from collections import defaultdict

from enderecos import DATA, URL, csv_file, distancia, valid_point, write_csv

MUNICIPAL = "https://www.ananindeua.pa.gov.br/mapas/index?grupo=2"
CNEFE = "https://ftp.ibge.gov.br/Cadastro_Nacional_de_Enderecos_para_Fins_Estatisticos/Censo_Demografico_2022/Arquivos_CNEFE/CSV/Municipio/"
TRE = "https://www.tre-pi.jus.br/comunicacao/noticias/2026/Setembro/alteracoes-de-locais-de-votacao-capital-e-interior"
SCHOOL = "https://www.ce.gov.br/seduc/2026/06/24/nova-eemti-jose-leopoldino-da-silva-filho-oferta-tempo-integral-no-conjunto-ceara/"
CAPS = "https://apidadosabertos.saude.gov.br/cnes/estabelecimentos/4276175"
CAPS_ADDR = "https://ms.dados.sms.fortaleza.ce.gov.br/RelacaoMunicipaldeMedicamentosEssenciais2025.2026.pdf"
JOAO = "https://joaocosta.pi.gov.br/prefeitura-de-joao-costa-publica-aviso-de-dispensa-eletronica-no-013-2026-para-projeto-de-ampliacao-do-centro-educacional-conceicao-abigail-castro/"
NOTES = {
    ("PA","04154","2550"): (
        (-1.3497197167414714,-48.400498986121534), "Marcador municipal de estabelecimento",
        "Geo Ananindeua, camada Escolas municipais nº 2, marcador 77, UEI Pequenos Ananis, WE 75. "
        "O CNEFE 2022 situa a Creche Pequenos Ananis na mesma rua a cerca de 14 m do marcador. "
        "O Diário Oficial municipal de 06/07/2023 também identifica a travessa WE 75 e o nº 501.",
        MUNICIPAL, CNEFE+"15_PA/1500800_ANANINDEUA.zip",
        "Os pontos são próximos em linha reta. Entre os registros de presença houve 19min53s. "
        "Depois, do registro da seção 228 à habilitação na 126 decorreram só 158s; "
        "a transição seguinte entre as seções durou 1.284s. A distância retilínea não mede o trajeto porta a porta."),
    ("CE","13897","1864"): (
        (-3.781877169155403,-38.60190909999576), "Ponto aproximado de estabelecimento com número de porta divergente",
        "O CNES 4276175 localiza o CAPS Infantil SER V na Rua Humberto Lomeu, 1132, Granja Portugal. "
        "A Secretaria Municipal de Saúde e o TSE informam nº 1105 para o mesmo CAPS. "
        "A distância usa o marcador da unidade de saúde. A entrada da seção não foi georreferenciada.",
        CAPS,CAPS_ADDR,
        "A referência do CAPS e o outro local são próximos; a medida aproximada depende da correspondência entre as duas numerações."),
    ("CE","13897","1481"): (
        None,"Endereço confirmado sem ponto contemporâneo do estabelecimento",
        "O TSE 2024 situa a escola na Rua Quatrocentos e Quarenta e Oito; o CNEFE 2022 indica o prédio antigo. "
        "A Secretaria da Educação inaugurou a nova sede em junho de 2026 e o TRE indica a Rua 420. "
        "A posição da sede anterior não serve para medir o trajeto de 2026.",
        SCHOOL,"https://apps.tre-ce.jus.br/CartorioEleitoral/LocaisMunicipioSedeController.do?municipio=13897&nomeMunicipio=FORTALEZA",
        "O intervalo é compatível em princípio com deslocamento dentro de Fortaleza; distância e itinerário ficam sem medição."),
    ("PI","12386","1120"): (
        None,"Estabelecimento identificado sem ponto validado",
        "O município documenta o CECAC em 2026. O TSE informa a Avenida José Agostinho de Castro. "
        "A busca no CNEFE 2022 não identificou com segurança a escola neste endereço.",
        JOAO,CNEFE+"22_PI/2205359_JOAO_COSTA.zip",
        "O intervalo admite em princípio deslocamento dentro de João Costa. A distância até a outra escola fica sem medição."),
    ("PI","10260","1104"): (
        None,"Mudança da seção documentada pelo TRE-PI sem ponto validado",
        "O TRE-PI identificou a mudança da seção 40 da escola Cândido Fernandes Braga, Praça Senhora do Carmo, "
        "para o CMEI Engenheiro Raimundo Nonato Campinho Braga, na Avenida São Raimundo. "
        "O TRE indica bairro São João e o cadastro de 25/10 escreve São José. A escola de origem aparece no CNEFE de 2022, "
        "mas o novo CMEI não foi identificado nesse endereço.",
        TRE,CNEFE+"22_PI/2203750_FARTURA_DO_PIAUI.zip",
        "O intervalo de 9h06 admite em princípio remanejamento ou deslocamento entre os locais. O trajeto e sua extensão ficam sem medição."),
}


def run():
    catalog = DATA/"eleitorado_local_votacao_2026.zip"
    seen = defaultdict(set)
    with zipfile.ZipFile(catalog) as z:
        for uf in sorted({k[0] for k in NOTES}):
            with io.TextIOWrapper(z.open(f"eleitorado_local_votacao_2026_{uf}.csv"),encoding="latin1") as f:
                for row in csv.DictReader(f,delimiter=";"):
                    k = uf,row["CD_MUNICIPIO"].zfill(5),row["NR_LOCAL_VOTACAO"]
                    if k in NOTES:
                        point = {"latitude":row["NR_LATITUDE"].replace(",","."),"longitude":row["NR_LONGITUDE"].replace(",",".")}
                        seen[k].add((row["NR_TURNO"],row["NM_LOCAL_VOTACAO"],row["DS_ENDERECO"],valid_point(point)))
    rows = []
    jumps = defaultdict(list)
    for r in csv_file(DATA/"trajetos_por_evento_revisao.csv"):
        ends = frozenset((r["uf_"+s],r["codigo_municipio_"+s],r["zona_"+s],r["secao_"+s]) for s in ("origem","destino"))
        jumps[r["id_caso"],ends].append(int(r["intervalo_s"]))
    for pair in csv_file(DATA/"deslocamentos_revisao.csv"):
        if pair["distancia_km"] or pair["local_a"]==pair["local_b"]:
            continue
        missing, other = ("b","a") if pair["latitude_a"] else ("a","b")
        k = tuple(pair[c+"_"+missing] for c in ("uf","codigo_municipio","local"))
        pt,category,note,source,second,conclusion = NOTES[k]
        support = [r for r in seen[k] if r[1]==pair["nome_"+missing]]
        if {r[0] for r in support}!={"1","2"} or any(r[3] for r in support):
            raise ValueError(f"Dados dos turnos exigem nova revisão: {k}")
        anchor = tuple(float(pair[c+"_"+other]) for c in ("latitude","longitude"))
        gap = int(pair["intervalo_s"])
        ends = frozenset((pair["uf_"+s],pair["codigo_municipio_"+s],pair["zona_"+s],pair["secao_"+s]) for s in ("a","b"))
        event_gaps = jumps[pair["id_caso"],ends]
        rows.append(dict(id_caso=pair["id_caso"],turno=pair["turno"],uf=k[0],municipio=pair["municipio_"+missing],
                         zona_sem_ponto=pair["zona_"+missing],secao_sem_ponto=pair["secao_"+missing],local_sem_ponto=k[2],
                         estabelecimento=pair["nome_"+missing],endereco_tse=" | ".join(sorted({r[2] for r in support})),
                         zona_outro=pair["zona_"+other],secao_outro=pair["secao_"+other],nome_outro=pair["nome_"+other],
                         latitude_outro=anchor[0],longitude_outro=anchor[1],situacao=category,
                         latitude_externa=pt[0] if pt else "",longitude_externa=pt[1] if pt else "",
                         distancia_reta_m=round(1000*distancia(anchor,pt)) if pt else "",
                         intervalo_s=gap,intervalo=f"{gap//3600:02}:{gap//60%60:02}:{gap%60:02}",
                         fonte_intervalo_s="Menor diferença entre registros positivos de presença do título nas duas seções",
                         menor_intervalo_eventos_s=min(event_gaps) if event_gaps else "",
                         fonte_eventos="Transições cronológicas entre locais, incluindo registros de presença e habilitações do título",
                         verificacao=note,interpretacao=conclusion,fonte_primaria=source,segunda_fonte=second,
                         fonte_cadastro=URL))
    if len(rows)!=len(NOTES):
        raise ValueError("A lista de pares sem coordenadas mudou.")
    write_csv(DATA/"conferencia_coordenadas.csv",list(rows[0]),rows)
    for r in rows:
        print(r["id_caso"],r["intervalo"],r["distancia_reta_m"])


if __name__=="__main__":
    run()
