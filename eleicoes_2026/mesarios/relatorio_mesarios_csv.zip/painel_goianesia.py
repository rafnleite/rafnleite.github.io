"""Reconfere os quatro pacotes na comparação Goianésia/GO – Ataléia/MG."""
import csv
import io
import json
from collections import Counter, defaultdict
from html import escape
from zipfile import ZipFile

from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify
from ilustracoes import cartao_candidato, rotulos_mesarios
from paineis_casos import original, tabela
from quadro_equipes import indicador_eleitor

ID = "M-56737337C02A"
GO = ("GO", "93718", "74", "60")
MG = ("MG", "40932", "270", "10")
ARQUIVO = BASE / "goianesia_ataleia.json"
CADASTRO = "https://cdn.tse.jus.br/estatistica/sead/odsele/eleitorado_locais_votacao/eleitorado_local_votacao_2026.zip"


def reunir():
    chaves = {(turno, *local) for turno in ("1","2") for local in (GO, MG)}
    fontes = {identify(r):r for r in linhas("manifesto.csv") if identify(r) in chaves}
    enderecos = {identify(r):r for r in linhas("enderecos.csv") if identify(r) in chaves}
    qualificados = defaultdict(Counter)
    for r in linhas("registros_qualificados.csv"):
        chave = identify(r)
        if chave in chaves:
            ref = (r["titulo"],r["data_hora"],r["urna"],r["tipo"],r["membro"],int(r["linha"]))
            qualificados[chave][ref] += 1
    (candidato,) = [r for r in linhas("duas_edicoes_pares.csv")
                    if r["id_caso"]==ID and r["fonte"]=="registro" and r["custo_ampliado"]]
    alternativo,repetido = candidato["titulo_alternativo"],candidato["titulo"]
    intermediario = alternativo[:3] + alternativo[4:]
    if intermediario.zfill(12)!=repetido or alternativo[3]!="2" or candidato["turno_fonte"]!="2":
        raise ValueError("Divergência na relação numérica da quarta posição")
    secoes=[]
    equipes={}
    for chave in sorted(chaves, key=lambda k: (k[1], k[0])):
        candidatos={ref[0] for ref in qualificados[chave]}
        s=ler_secao(fontes[chave],enderecos[chave],candidatos,qualificados[chave])
        for etapa in ("abertura","encerramento"):
            equipes[s["uf"],s["turno"],etapa]={r["titulo"] for r in s["registros"] if r["etapa"]==etapa}
        for campo in ("registros","habilitacoes"):
            s[campo]=[r for r in s[campo] if r["titulo"] in {alternativo,repetido}]
        for campo in ("alvos_so_abertura","alvos_so_encerramento"):
            s.pop(campo)
        secoes.append(s)
    mantidos = set.intersection(*(v for (uf,_,_),v in equipes.items() if uf=="GO"))
    if len(mantidos)!=3:
        raise ValueError("Divergência nas quatro composições em Goianésia")
    for (uf,t,etapa),grupo in equipes.items():
        if uf=="GO" and grupo != mantidos | ({repetido} if t==1 else {alternativo}):
            raise ValueError(f"A mudança de turno em Goianésia envolve mais de um título: {t}, {etapa}")
        if uf=="MG" and not (repetido in grupo and alternativo not in grupo):
            raise ValueError(f"Registros da mesa de Ataléia divergentes: {t}, {etapa}")
    with ZipFile(BASE/"eleitorado_local_votacao_2026.zip") as z:
        with io.TextIOWrapper(z.open("eleitorado_local_votacao_2026_BRASIL.csv"),encoding="latin1") as f:
            municipios=sorted({(r["NM_MUNICIPIO"],r["SG_UF"],r["CD_MUNICIPIO"])
                               for r in csv.DictReader(f,delimiter=";") if "GOIANÉSIA" in r["NM_MUNICIPIO"]})
    return dict(id_caso=ID,titulo_repetido=repetido,titulo_alternativo=alternativo,intermediario=intermediario,
                caminho_usual=json.loads(candidato["caminho_usual"]),secoes=secoes,
                goianesia_titulos_constantes_nas_quatro_etapas=len(mantidos),
                ataleia_fechamentos_em_comum=len(equipes["MG",1,"encerramento"] & equipes["MG",2,"encerramento"]),
                municipios_com_goianesia=[dict(nome=nome,uf=uf,codigo_municipio_tse=cd) for nome,uf,cd in municipios],
                cadastro_municipios=CADASTRO)


def gerar():
    dados=reunir()
    ARQUIVO.write_text(json.dumps(dados,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return dados


def painel_goianesia():
    d=json.loads(ARQUIVO.read_bytes()) if ARQUIVO.exists() else gerar()
    alt=d["titulo_alternativo"]
    rep=d["titulo_repetido"]
    origem, = (s for s in d["secoes"] if s["uf"] == "GO" and str(s["turno"]) == "2")
    contraparte, = (s for s in d["secoes"] if s["uf"] == "MG" and str(s["turno"]) == "1")
    figura=cartao_candidato(dict(titulo_alternativo=alt,titulo=rep,caminho_usual=d["caminho_usual"]),
                            rotulos_mesarios(origem, contraparte), erro_forte=True)
    linhas_html=[]
    for s in d["secoes"]:
        etapas=[]
        for etapa in ("abertura","encerramento"):
            (r,)=[e for e in s["registros"] if e["etapa"]==etapa]
            etapas.append(f"<code>{escape(r['titulo'])}</code><small>{r['data_hora'][11:]} · linha {r['linha']}{indicador_eleitor(r)}</small>")
        mesa=f"<b>{escape(s['municipio'].title())}/{s['uf']}</b><small>Z{s['zona']} · S{s['secao']} · urna {escape(s['urnas'][0])}</small>"
        linhas_html.append((mesa,f"{s['turno']}º",*etapas,original(s)))
    grade=tabela(["Mesa","Turno","Registro na abertura","Registro no encerramento","Fonte"],linhas_html)
    return (f"<section id='goianesia'><h2>Goianésia e Ataléia · a pista está no segundo turno</h2>"
            f"<p>Na mesa de <strong>Goianésia/GO</strong>, o título do segundo turno foi <code>{alt}</code>. "
            f"Com a omissão do <b>2 da quarta posição</b> e o preenchimento com zero à esquerda, "
            f"esse título passa a <code>{rep}</code>, exatamente o número registrado no primeiro turno em Goianésia "
            f"e nos dois turnos em <strong>Ataléia/MG</strong>.</p>{figura}"
            f"<p>Em Goianésia, <b>os mesmos outros três títulos</b> aparecem na abertura e no encerramento "
            f"dos dois turnos. O primeiro turno, lido sozinho, mostra duas digitações iguais. É na comparação com o "
            f"segundo turno que se identifica o título com o 2 e a provável omissão nas duas digitações do primeiro. "
            f"Em Ataléia, a mesa voltou a registrar os mesmos quatro títulos nos dois fechamentos.</p>"
            f"<div class='evidencia'>{grade}</div><p class='fine'>Horários locais. A posição do dígito é contada "
            f"a partir da esquerda na grafia de 12 algarismos. O contraste documenta a transformação e a "
            f"continuidade dos outros títulos. A ata e o boletim de identificação permitem confirmar quem atuou.</p>"
            f"<p class='fine'>O cadastro do TSE identifica a seção 60 no município de Goianésia, Goiás, "
            f"código 93718. Goianésia do Pará tem código 04006. "
            f"<a href='{CADASTRO}'>Cadastro oficial de locais</a> · "
            f"<a href='dados/goianesia_ataleia.json'>Linhas, horários e fontes</a> · "
            f"<a data-equipe-prever='1-{ID.lower()}' href='#f-1-{ID.lower()}'>Ficha da duplicidade</a></p></section>")


if __name__=="__main__":
    evidencia=gerar()
    print(f"{len(evidencia['secoes'])} pacotes oficiais conferidos. Evidência em {ARQUIVO.name}.")
