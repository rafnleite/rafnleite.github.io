"""Explicação do registro da equipe e da habilitação de eleitores em 2026."""


def leitura_casos_em_aberto():
    return """
<p>Para esse conjunto, considero mais provável que, em pelo menos uma das urnas, o título repetido tenha entrado como <strong>um registro de presença a mais</strong>, além dos registros dos mesários que estavam na mesa. Também é possível que alguém tenha registrado a própria presença com um número diferente do seu título.
Nos dois casos interestaduais, a ordem das entradas ajuda a explicar essa leitura. Nos demais, a repetição e
os horários deixam em aberto quem fez o registro e em que circunstâncias.</p>
<p><strong>Registrar a presença de um mesário não registra nem altera voto.</strong> Esse cadastro compõe a lista
da equipe. Para votar, cada eleitor precisa ser identificado e habilitado na própria seção. Mesmo quando se usa
a digital de um mesário para autorizar o atendimento de um eleitor cuja biometria falhou, a escolha do voto
cabe ao eleitor na cabine. A repetição de um título na lista da equipe não acrescenta votos à apuração.
<a href="https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026">Resolução TSE nº 23.751/2026, arts. 123 e 133–135</a>
· <a href="https://www.justicaeleitoral.jus.br/fato-ou-boato/checagens/2026/repeticao-de-titulo-em-logs-de-urnas-nao-comprova-existencia-de-mesarios-virtuais">Esclarecimento da Justiça Eleitoral sobre títulos repetidos nos logs</a>.</p>
""".strip()


def painel_mesario():
    return """
<section id="biometria" aria-labelledby="titulo-biometria">
  <h2 id="titulo-biometria">O que a urna confere no registro do mesário e na hora do voto</h2>
  <h3>Quando o mesário registra presença</h3>
  <p>Na abertura, cada integrante da mesa informa o próprio título e coloca o polegar ou o indicador no leitor.
  A equipe repete o registro no encerramento. Quem chega depois da abertura também pode registrar a presença
  durante a votação. A urna verifica se o número informado tem formato de título eleitoral e funciona sem
  consulta em tempo real a outras urnas. Por isso, um erro de digitação que produza outro número válido pode
  aparecer no log como presença.
  <a href="https://www.justicaeleitoral.jus.br/mesario/cursos/mesarios-brasil/m2-o-que-fazer-antes-da-votacao/a4-registro-de-mesarias-e-mesarios/index.html">Treinamento de 2026, registro da equipe</a> ·
  <a href="https://www.justicaeleitoral.jus.br/fato-ou-boato/checagens/2026/repeticao-de-titulo-em-logs-de-urnas-nao-comprova-existencia-de-mesarios-virtuais">Esclarecimento da Justiça Eleitoral sobre títulos repetidos</a>.</p>
  <ul>
    <li><strong>Mesário eleitor da própria seção, com biometria disponível.</strong>
    A urna compara a impressão apresentada com a cadastrada para aquela inscrição.</li>
    <li><strong>Mesário eleitor de outra seção.</strong> A urna armazena a impressão coletada e a encaminha
    ao TSE para eventual verificação posterior de identidade. Mesmo que o número digitado esteja errado,
    fica preservada uma amostra da digital apresentada por quem estava diante do leitor.
    <a href="https://www.justicaeleitoral.jus.br/fato-ou-boato/checagens/2026/repeticao-de-titulo-em-logs-de-urnas-nao-comprova-existencia-de-mesarios-virtuais">Justiça Eleitoral, seção sobre quem trabalhou na mesa</a>.</li>
  </ul>
  <h3>Quando um eleitor é habilitado a votar</h3>
  <p>A mesa confere um documento oficial com foto e localiza a inscrição da pessoa no eleitorado daquela
  seção pelo CPF ou pelo título. Confere os dados e, quando disponível, a fotografia. Havendo impressão digital
  cadastrada, o eleitor apresenta o dedo para reconhecimento. Se o terminal informa que o eleitor está
  <strong>sem dados biométricos</strong>, a presidência pede diretamente o ano de nascimento. O terminal
  confere esse dado com o cadastro e a pessoa assina o Caderno de Votação.
  <a href="https://www.justicaeleitoral.jus.br/eleicoes/mesario/assets/arquivos/manual_do_mesario.pdf#page=18">Manual do Mesário de 2026, pp. 18–19</a>.</p>
  <p><strong>A digital do mesário funciona como uma assinatura da autorização</strong> quando a urna deixa
  de reconhecer a digital cadastrada do eleitor após quatro tentativas de leitura. A presidência da mesa
  reconfere a identificação e o número digitado. Se persistir dúvida sobre a identidade, cabe ao juízo eleitoral
  decidir. Confirmada a identidade, a presidência pergunta o ano de nascimento e o informa ao terminal. Aceito o ano, o mesário atesta
  o procedimento com a própria digital, o eleitor assina o Caderno de Votação ou nele apõe sua impressão se
  não puder assinar, e a mesa registra a ocorrência em ata. Assim, um registro de habilitação atribuído ao número de um mesário indica uma
  autorização dada no atendimento de um eleitor.
  <a href="https://www.justicaeleitoral.jus.br/mesario/cursos/mesarios-brasil/m3-o-que-fazer-durante-a-votacao/a5-situacoes-especificas-no-fluxo-de-votacao/index.html">Treinamento de 2026, biometria não reconhecida</a> ·
  <a href="https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026">Resolução TSE nº 23.751/2026, arts. 133–135</a>.</p>
  <h3>Por que a equipe pode mudar no dia</h3>
  <p>A escala prevista pode mudar entre a convocação e o encerramento. Se alguém faltar, a presidência
  comunica o fato ao juízo eleitoral. O juiz pode remanejar integrante de outra mesa, autorizar a substituição
  por uma pessoa nomeada para apoio logístico na zona ou autorizar a nomeação de um eleitor presente que
  atenda aos requisitos legais. Um impedimento da presidência pode surgir durante a votação. Outro exemplo
  é o abandono injustificado dos trabalhos por um integrante. Essa conduta pode deixar um posto a preencher e
  é tratada expressamente pelo Código Eleitoral.
  <a href="https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026">Resolução TSE nº 23.751/2026, arts. 123–125</a> ·
  <a href="https://www.tse.jus.br/legislacao/codigo-eleitoral/codigo-eleitoral-1/codigo-eleitoral-lei-nb0-4.737-de-15-de-julho-de-1965">Código Eleitoral, art. 124, § 4º</a>.</p>
  <p>Essa possibilidade de recompor a equipe ajuda a entender por que o terminal admite o registro de presença
  de quem vota em outra seção. Para confirmar um remanejamento específico, é possível comparar a convocação,
  a Ata da Mesa Receptora, o Boletim de Identificação do Mesário assinado pela equipe e a anotação do cartório
  no sistema ELO. A ata registra comparecimentos, substituições e remanejamentos.
  <a href="https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026">Resolução TSE nº 23.751/2026, arts. 125, §§ 1º–2º, e 127, VI e VIII</a>.</p>
</section>
""".strip()
