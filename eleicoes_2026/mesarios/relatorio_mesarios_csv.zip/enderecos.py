"""Recorta o cadastro oficial de locais do TSE por turno e seção do manifesto.

O arquivo do TSE gerado em 25/10 traz linhas individualizadas dos dois turnos.
Para preservar a comparação com a Arvor, o manifesto mantém os valores que ela
publicou e recebe códigos e nomes somente nos campos faltantes.
"""
import csv
from collections import defaultdict
import hashlib
import io
from pathlib import Path
import urllib.request
import zipfile

from fontes import DATA, FIELDS, consolidate, create_row, csv_file, official_url, verify, write_csv
from geografia import SHA256_CADASTRO_LOCAIS as DIGEST, URL_CADASTRO_LOCAIS as URL, distancia


FIELDS_ADDRESS = FIELDS[:5] + "local nome endereco bairro cep latitude longitude geracao hora_geracao".split()


def row_key(r):
    return tuple(str(r[f]) for f in FIELDS[:5])


def valid_point(r):
    try:
        lat,lon = float(r["latitude"]),float(r["longitude"])
    except (TypeError, ValueError):
        return None
    return (lat,lon) if -35<lat<6 and -75<lon<-32 else None


def revise(manifest, selected, addresses):
    base = {row_key(r):r for r in manifest if "repeticao" in r["escopo"].split()}
    groups = defaultdict(list)
    for k,r in base.items():
        for ident in r["ids"].split():
            groups[k[0],ident].append(k)
    case_fields = ["id_arvor","turno","locais_arvor","locais_25out","classe_arvor","classe_25out","mudou_classe"]
    class_changes, section_changes, details = [], [], []
    for (turn, ident),keys in groups.items():
        n0 = len({(*k[1:4],base[k]["local"]) for k in keys})
        n1 = len({(*k[1:4],selected[k]["local"]) for k in keys})
        c0 = "mesmo local" if n0==1 else "locais diferentes"
        c1 = "mesmo local" if n1==1 else "locais diferentes"
        label = dict(id_arvor=ident,turno=turn,locais_arvor=n0,locais_25out=n1,classe_arvor=c0,
                     classe_25out=c1,mudou_classe=int(c0!=c1))
        locations = []
        affected = False
        for k in keys:
            old,new = base[k],selected[k]
            old_code = old["local"]
            addr = addresses.get((*k[:4],old_code),set())
            pt0,pt1 = valid_point(old),valid_point(new)
            changed_code = old_code!=new["local"]
            changed_coords = pt0!=pt1
            affected |= changed_code or changed_coords
            comparison = dict(zip(FIELDS[:5],k),municipio=old["municipio"],local_arvor=old_code,
                              nome_arvor=old["nome"],endereco_codigo_arvor_consulta_25out=" | ".join(sorted(addr)),
                              latitude_arvor=old["latitude"],longitude_arvor=old["longitude"],local_25out=new["local"],
                              nome_25out=new["nome"],endereco_25out=new["endereco"],latitude_25out=new["latitude"],
                              longitude_25out=new["longitude"],mudou_codigo=int(changed_code),mudou_coordenadas=int(changed_coords),
                              deslocamento_ponto_m=round(1000*distancia(pt0,pt1),2) if pt0 and pt1 else "")
            locations.append(comparison)
            if changed_code:
                section_changes.append(comparison)
        if c0!=c1:
            class_changes.append(label)
        if affected:
            details.extend({**label,**r} for r in locations)
    if len(groups)!=11866:
        raise ValueError("Cobertura de IDs-turno divergente.")
    unique = {row_key(r):r for r in section_changes}
    write_csv(DATA/"mudancas_classes.csv",case_fields,class_changes)
    write_csv(DATA/"mudancas_locais.csv",list(section_changes[0]),unique.values())
    write_csv(DATA/"revisao_locais.csv",list(details[0]),details)
    return [(g["turno"],g["id_arvor"],groups[g["turno"],g["id_arvor"]])
            for g in class_changes if g["classe_arvor"]=="mesmo local"]


def supplement(groups, manifest, selected):
    original = {row_key(r):r for r in manifest}
    output = DATA/"revisao_manifesto.csv"
    previous = {row_key(r):r for r in csv_file(output)} if output.exists() else {}
    rows = []
    for turn, ident, keys in groups:
        for k0 in keys:
            for t in ["1","2"]:
                k = (t,*k0[1:])
                addr = selected[k]
                row = original.get(k)
                if row:
                    row = row.copy()
                else:
                    kt = (int(t),k[1],k[2],int(k[3]),int(k[4]))
                    row = create_row(kt,original[k0]["municipio"],addr["nome"])
                    if k in previous:
                        row["url_log"] = previous[k]["url_log"]
                    url = official_url(row,lambda url: urllib.request.urlopen(url,timeout=35).read())
                    dest = DATA/row["arquivo"]
                    if dest.exists():
                        data = dest.read_bytes()
                    else:
                        with urllib.request.urlopen(url,timeout=35) as response:
                            data = response.read()
                    sha = verify(data,[previous.get(k,{}).get("sha256")])
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    if not dest.exists():
                        tmp = dest.with_suffix(".part")
                        tmp.write_bytes(data)
                        tmp.replace(dest)
                    row.update(url_log=url,sha256=sha)
                row.update({f:addr[f] for f in ("local","nome","latitude","longitude")})
                row.update(prioridade=0 if turn==t else 1,escopo="revisao_25out",id_revisao=ident)
                rows.append(row)
    write_csv(output,[*FIELDS,"id_revisao"],rows)


def run():
    archive = DATA / Path(URL).name
    if not archive.exists():
        urllib.request.urlretrieve(URL,archive)
    with archive.open("rb") as fin:
        if hashlib.file_digest(fin,"sha256").hexdigest()!=DIGEST:
            raise ValueError("SHA-256 diferente da edição do cadastro de locais utilizada.")
    manifest = csv_file(DATA/"manifesto.csv")
    keys = {tuple(r[k] for k in FIELDS[:5]) for r in manifest}
    compare_keys = keys | {(t,*k[1:]) for t in ("1","2") for k in keys}
    historic = {(*row_key(r)[:4],r["local"]) for r in manifest if r["local"]}
    addresses = defaultdict(set)
    selected = {}
    with zipfile.ZipFile(archive) as z:
        with io.TextIOWrapper(z.open("eleitorado_local_votacao_2026_BRASIL.csv"),encoding="latin1") as raw:
            for r in csv.DictReader(raw,delimiter=";"):
                key = (r["NR_TURNO"],r["SG_UF"],r["CD_MUNICIPIO"].zfill(5),r["NR_ZONA"],r["NR_SECAO"])
                for code,field in [(r["NR_LOCAL_VOTACAO"],"DS_ENDERECO"),(r["NR_LOCAL_VOTACAO_ORIGINAL"],"DS_ENDERECO_LOCVT_ORIGINAL")]:
                    code_key = (*key[:4],code)
                    if code_key in historic and r[field] not in ("","#NULO#","#NE#"):
                        addresses[code_key].add(r[field])
                if key not in compare_keys:
                    continue
                value = dict(zip(FIELDS[:5],key),local=r["NR_LOCAL_VOTACAO"],nome=r["NM_LOCAL_VOTACAO"],
                             endereco=r["DS_ENDERECO"],bairro=r["NM_BAIRRO"],cep=r["NR_CEP"],
                             latitude=r["NR_LATITUDE"].replace(",","."),longitude=r["NR_LONGITUDE"].replace(",","."),
                             geracao=r["DT_GERACAO"],hora_geracao=r["HH_GERACAO"])
                if key in selected and value!=selected[key]:
                    raise ValueError(f"Local ambíguo no cadastro: {key}")
                selected[key] = value
    if keys-selected.keys():
        raise ValueError(f"Faltam locais para {len(keys-selected.keys())} seções-turno.")
    write_csv(DATA/"enderecos.csv",FIELDS_ADDRESS,(selected[k] for k in sorted(keys)))
    consolidate(manifest,{})
    groups = revise(manifest,selected,addresses)
    supplement(groups,manifest,selected)
    print(f"{len(keys)} endereços do cadastro do TSE por seção e turno.")


if __name__=="__main__":
    run()
