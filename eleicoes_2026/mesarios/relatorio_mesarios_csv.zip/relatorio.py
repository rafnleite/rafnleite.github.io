"""Gera o relatório HTML local a partir dos resultados da extração e comparação."""
from __future__ import annotations

import csv
import html
import json
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import quote

from casos_em_aberto import FICHAS_INTERESTADUAIS
from geografia import DADOS, FORTE, MESMO, gerar as gerar_geografia, ler_csv, secao
from fichas_digitacao import PEDRA_BRANCA, particularidade, qualificar, turno_mesa
from logistica import OK, LIMIAR, CURTO, EXTREMO, ORDEM, gerar as gerar_logistica
from ilustracoes import ESTILO, cartao_candidato, comparacao_mais_proxima, painel_casa_nova, rotulos_mesarios
from paineis_casos import painel_bahia, painel_sao_paulo
from painel_goianesia import painel_goianesia
from listas_equipes import carregar_listas
from previa_equipes import atributo, componentes
from quadro_equipes import renderizar as renderizar_equipes
from relogios import CSV_CASOS, IMPROVAVEL as IMPROVAVEL_RELOGIOS, MARGEM_MIN

ROOT = DADOS.parent


def e(v):
    return html.escape(str(v), quote=True)


def n(v):
    return f"{int(v):,}".replace(",", ".")


def decimal(v, casas=1):
    return f"{float(v):,.{casas}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def duracao(seg):
    h, resto = divmod(int(seg), 3600)
    m, s = divmod(resto, 60)
    return " ".join([*([f"{h} h"] if h else []), *([f"{m} min"] if m or h else []), f"{s} s"])


def chave(r):
    return int(r["turno"]), r["titulo"]


def tabela(cabecalhos, linhas):
    head = "".join(f"<th scope='col'>{c}</th>" for c in cabecalhos)
    body = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in linhas)
    return f"<div class='scroll'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"


def id_html(r):
    return "f-" + r["turno"] + "-" + r["id_caso"].lower()


def deslocamento_do_caso(cenario_relogios, cadastro):
    if cenario_relogios:
        resultado = cenario_relogios["resultado"]
        return "Improvável" if resultado == IMPROVAVEL_RELOGIOS else resultado
    if cadastro["avaliacao"] == MESMO:
        return MESMO
    raise ValueError(f"Falta a avaliação dos horários para {cadastro['id_caso']}")


def rotulo_logistico(classe):
    if classe in (FORTE, EXTREMO):
        return "Distância incompatível com o intervalo"
    return classe


def previa_da_mesa(r):
    return (f"{atributo(r)} data-equipe-uf='{e(r['uf'])}' "
            f"data-equipe-municipio='{e(r['codigo_municipio'])}' "
            f"data-equipe-zona='{int(r['zona'])}' data-equipe-secao='{int(r['secao'])}'")


def numero(s):
    return "<code>" + e(s) + "</code>"


def fonte(a, sec, catalogo):
    arquivo = catalogo[secao(sec)]
    link = "dados/" + quote(arquivo["arquivo"].replace("\\", "/"), safe="/")
    return f"<a href='{e(link)}'>{a}</a> · <a href='{e(arquivo['url_log'])}'>TSE</a>"


def custo(r):
    return int(r["custo_ampliado"]) if r["custo_ampliado"] else 3


def ordem_candidato(c):
    return (not bool(c["custo_usual"]), int(c["custo_usual"] or custo(c)), c["turno_fonte"] != c["turno"],
            int(c["distancia_levenshtein"]), c["titulo_alternativo"])


def classificacao(positivos, outras):
    for indice, nome in ((positivos,"título registrado"), (outras,"outra menção")):
        candidatos = [r for grupo in indice.values() for r in grupo if custo(r) <= 2]
        if candidatos:
            perto=min(candidatos,key=ordem_candidato)
            if not perto["custo_usual"]:
                return "Somente com troca distante · "+nome
            return ("Uma edição" if perto["custo_usual"]=="1" else "Duas edições")+" · "+nome
    return "Sem correspondência em até duas edições"


def cartoes_da_secao(linhas, rotulos):
    numeros = defaultdict(list)
    for c in sorted(linhas,key=ordem_candidato):
        if custo(c)<=2:
            numeros[c["titulo_alternativo"]].append(c)
    paineis=[]
    for lista in numeros.values():
        linha=lista[0]
        fonte_texto="Registro de presença" if linha["fonte"]=="registro" else "Menção sem registro de presença"
        turnos=sorted({c["turno_fonte"] for c in lista})
        periodos=" e ".join(f"{t}º" for t in turnos)
        periodo=f"no {periodos} turno" if len(turnos)==1 else f"nos {periodos} turnos"
        paineis.append(f"<p class='fine'>{fonte_texto} {periodo}.</p>"+
                       cartao_candidato(linha, rotulos, erro_forte=linha["erro_forte"]))
        equipe=linha.get("equipe_conferida")
        if equipe:
            abertura=equipe["equipe_abertura"]
            encerramento=equipe["equipe_encerramento"]
            comuns=equipe["equipe_em_ambas"]
            if equipe["troca_unica"]=="1":
                antes,depois=(("alternativo","repetido") if equipe["direcao"].startswith("alternativo") else ("repetido","alternativo"))
                leitura=(f"A única mudança entre as duas listas foi a passagem do título {antes} "
                         f"na abertura para o {depois} no encerramento.")
            elif linha.get("parecer_entre_turnos"):
                leitura="<b>Erro de digitação com evidência forte.</b> "+linha["parecer_entre_turnos"]
            elif equipe["resultado"]=="Candidato registrado somente no outro turno":
                leitura="A comparação usa o título alternativo registrado nesta seção apenas no outro turno."
            else:
                leitura=("O alternativo teve registro neste turno. A composição observada permite outras "
                         "explicações para a diferença entre as equipes.")
            paineis.append(f"<p><b>Equipe da seção no {e(linha['turno'])}º turno.</b> "
                           f"A abertura teve {e(abertura)} títulos registrados e o encerramento, {e(encerramento)}. "
                           f"Os dois grupos têm {e(comuns)} títulos em comum. {leitura}</p>")
            evidencias=[]
            for campo,rotulo,titulo in (("presencas_repetido","Repetido no turno da ocorrência",linha["titulo"]),
                                        ("presencas_alternativo","Alternativo no turno da ocorrência",linha["titulo_alternativo"]),
                                        ("presencas_alternativo_outro_turno","Alternativo no outro turno",linha["titulo_alternativo"])):
                evidencias.extend((numero(titulo),rotulo,e(item)) for item in equipe[campo].split(" | ") if item)
            paineis.append(f"<details><summary {previa_da_mesa(linha)}>Horários, urnas e linhas da conferência da equipe</summary>"+
                           tabela(["Título","Ocorrência","Registro no log"],evidencias)+"</details>")
            if linha["contraste_ampliado_entre_turnos"]=="1":
                paineis.append("<p class='fine'>O alternativo foi registrado aqui nos dois turnos. "
                               "No outro turno, o título repetido apareceu em outro local do caso e "
                               "deixou de constar nos registros de presença desta seção.</p>")
    return "".join(paineis)


def operacoes_resumidas(c):
    if custo(c)>2:
        return "Mais de duas"
    passos=json.loads(c["caminho_usual"] if c["custo_usual"] else c["caminho_ampliado"])
    nomes={"omissao":"omissão","insercao":"inserção","duplicacao":"duplicação","substituicao":"substituição",
           "troca_adjacente":"troca adjacente","troca_distante":"troca distante","troca_nao_adjacente":"troca distante"}
    return " + ".join(e(nomes.get(p["tipo"],p["tipo"].replace("_"," "))) for p in passos)


def contexto_secao(r, candidatos, suplementar, catalogo, outras_secoes):
    heading = f"{e(r['municipio'])}/{e(r['uf'])} · zona {int(r['zona'])} · seção {int(r['secao'])}"
    local = f"{e(r['nome'])} · local {int(r['local'])}"
    atual = catalogo[secao(r)]
    local += (f"<br>Cadastro do TSE de 25/10: {e(atual['nome_tse'])} · local {e(atual['local_tse'])} · "
              f"{e(atual['endereco_tse'])}, {e(atual['bairro_tse'])}.")
    instantes = e(r["primeiro"])
    if r["primeiro"] != r["ultimo"]:
        instantes += " a " + e(r["ultimo"])
    rotulos = rotulos_mesarios(r, outras_secoes)
    destaques=cartoes_da_secao(candidatos, rotulos)
    if not destaques and candidatos:
        menor=min(candidatos,key=lambda c:(int(c["distancia_levenshtein"]),c["turno_fonte"]!=r["turno"],c["titulo_alternativo"]))
        destaques=("<p class='fine'>Entre os demais títulos registrados, este é um dos mais próximos "
                   f"pela distância de edição. Foi registrado no {menor['turno_fonte']}º turno.</p>"+
                   comparacao_mais_proxima(menor["titulo_alternativo"], r["titulo"], rotulos,
                                           erro_forte=menor["erro_forte"]))
    tabela_equipes = tabela(["Turno da fonte", "Outro título registrado", "Primeiro registro", "Último registro",
                             "Distância¹", "Teste de até duas operações"], [
        (c["turno_fonte"] + "º", numero(c["titulo_alternativo"]), e(c["primeiro_alternativo"]),
         e(c["ultimo_alternativo"]), c["distancia_levenshtein"], operacoes_resumidas(c))
        for c in sorted(candidatos, key=ordem_candidato)])
    extra = ""
    if suplementar:
        tabela_extra = tabela(["Turno", "Outro número", "Evento", "Distância¹", "Teste de até duas operações"], [
            (c["turno_fonte"] + "º", numero(c["titulo_alternativo"]), e(c["tipos"]),
             c["distancia_levenshtein"], operacoes_resumidas(c)) for c in suplementar])
        encontrados = sum(custo(c)<=2 for c in suplementar)
        rotulos_mencao = rotulos_mesarios(r, outras_secoes, so_mencao=True)
        extra = (cartoes_da_secao(suplementar, rotulos_mencao) + f"<details><summary>Outros números mencionados sem registro de presença "
                 f"({len(suplementar)} comparações, {encontrados} com transformação)</summary>{tabela_extra}</details>")
    return (f"<section class='mesa'><h4>{heading}</h4><p>{local}</p><p>O título repetido teve "
            f"{r['registros']} registro(s) de presença e {r['habilitacoes']} habilitação(ões). "
            f"Horários locais de registro: {instantes}. {fonte('Arquivo original',r,catalogo)}</p>{destaques}"
            f"<details><summary {previa_da_mesa(r)}>Comparar os demais títulos registrados ({r['comparados_turno']} no turno, "
            f"{r['comparados_outro_turno']} no outro)</summary>{tabela_equipes}</details>{extra}</section>")


def ficha(r, secoes, comparacoes, extras, distancias, catalogo, logistica, trajetos, revisao, trechos_rev, quadro_equipes, coord=None, sem_rota=None, cenario_relogios=None):
    lugares = list(dict.fromkeys(f"{s['municipio']}/{s['uf']}" for s in secoes))
    lugar = " ↔ ".join(lugares)
    resumo = e(classificacao(comparacoes,extras))
    busca = " ".join([r["id_caso"], r["ids_arvor_possiveis"], r["titulo"], lugar, *[
        v for s in secoes for v in (s["nome"], f"z{s['zona']} s{s['secao']}")],
        *[c["titulo_alternativo"] for s in secoes for indice in (comparacoes,extras) for c in indice[secao(s)]]])
    comp = [contexto_secao(s, comparacoes[secao(s)], extras[secao(s)], catalogo,
                           [outra for outra in secoes if secao(outra) != secao(s)]) for s in secoes]
    pares = []
    for d in distancias:
        if d["avaliacao"] in (MESMO, FORTE):
            rotulo = "Mesmo local" if d["avaliacao"] == MESMO else rotulo_logistico(FORTE)
        else:
            rotulo = "Inconclusivo"
        observacao = " · quartetos invertidos entre abertura e fechamento" if d["equipes_invertidas"] == "True" else ""
        pares.append((f"{e(d['municipio_a'])} Z{d['zona_a']} S{d['secao_a']} ↔ "
                      f"{e(d['municipio_b'])} Z{d['zona_b']} S{d['secao_b']}",
                      decimal(d["distancia_km"], 2) if d["distancia_km"] else "Sem coordenadas",
                      duracao(d["intervalo_s"]),
                      rotulo + observacao))
    tab_pares = tabela(["Seções", "Distância em linha reta (km)", "Menor intervalo entre registros", "Leitura do trecho"], pares)
    trechos = []
    for t in trajetos:
        viz = "Municípios limítrofes" if t["municipios_vizinhos"]=="1" else "Municípios sem divisa"
        territorio = "Mesmo município" if t["mesmo_municipio"]=="1" else viz
        territorio += ", mesma zona" if t["mesma_zona"]=="1" else ", zonas distintas"
        trecho = (f"{e(t['municipio_origem'])} · Z{t['zona_origem']} S{t['secao_origem']} → "
                  f"{e(t['municipio_destino'])} · Z{t['zona_destino']} S{t['secao_destino']}")
        etapas = (e(t["hora_origem"])+" ("+e(t["evento_origem"].replace("habilitacao","habilitação"))+") → "
                  +e(t["hora_destino"])+" ("+e(t["evento_destino"].replace("habilitacao","habilitação"))+")")
        rota = "Sem estimativa" if not t["modo"] else (e(t["modo"])+", "
                +decimal(t["percurso_rede_km"],2)+" km, "+duracao(round(float(t["tempo_trajeto_s"])))+
                " de trajeto. Com folga: "+duracao(round(float(t["tempo_com_folga_s"]))))
        trechos.append((trecho+"<br>"+territorio,etapas,duracao(t["intervalo_s"]),rota,e(rotulo_logistico(t["avaliacao_logistica"]))))
    tab_trechos = tabela(["Mudança de local","Do evento ao evento (hora local)","Tempo disponível","Estimativa","Resultado"],trechos)
    jurisdicao = "mesmo município" if logistica["todos_no_mesmo_municipio"]=="1" else ("municípios limítrofes" if logistica["vizinhanca"]=="1" else "municípios sem divisa")
    zona = "mesma zona" if logistica["todos_na_mesma_zona"]=="1" else "zonas distintas"
    corresponde = ("Correspondência unívoca pelos dados publicados." if r["id_caso"].startswith("M-")
                   else "Rótulo local. IDs da Arvor com a mesma assinatura observada: " + (e(r["ids_arvor_possiveis"]) or "nenhum") + ".")
    # A ficha inteira permanece acessível sem JavaScript. Os filtros só alteram sua visibilidade.
    outra = (f"<p><b>Cadastro do TSE de 25/10.</b> Mudanças de local entre eventos consecutivos: "
             f"{revisao['mudancas_de_local']}.</p>")
    if sem_rota:
        outra += (f"<p><b>Avaliação sem rota calculada · {e(sem_rota['status'])}.</b> "
                  f"{e(sem_rota['justificativa'])} <a href='dados/relatorio/trechos_sem_rota.csv'>Trechos, horários e fontes</a>.</p>")
    if coord:
        medicao = f"Distância aproximada entre as referências: {e(coord['distancia_reta_m'])} m. " if coord["distancia_reta_m"] else ""
        menor = min((int(t["intervalo_s"]) for t in trechos_rev), default=None)
        dur = " Menor intervalo incluindo habilitações: "+duracao(menor)+"." if menor is not None else ""
        outra += (f"<p><b>Conferência do endereço.</b> {medicao}{e(coord['interpretacao'])}{dur} "
                  "<a href='dados/conferencia_coordenadas.csv'>Fontes do endereço</a></p>")
    if trechos_rev and [(t["avaliacao_logistica"],t["distancia_km"],t["tempo_com_folga_s"]) for t in trechos_rev] != [
            (t["avaliacao_logistica"],t["distancia_km"],t["tempo_com_folga_s"]) for t in trajetos]:
        resumo_rev=tabela(["Seções", "Linha reta (km)", "Tempo disponível", "Trajeto com folga", "Avaliação na edição de 25/10"],[
            (f"Z{t['zona_origem']} S{t['secao_origem']} → Z{t['zona_destino']} S{t['secao_destino']}",
             decimal(t["distancia_km"],2) if t["distancia_km"] else "—",duracao(t["intervalo_s"]),
             duracao(round(float(t["tempo_com_folga_s"]))) if t["tempo_com_folga_s"] else "—",
             e(rotulo_logistico(t["avaliacao_logistica"]))) for t in trechos_rev])
        outra+=f"<details><summary>Trajetos com as coordenadas de 25/10</summary>{resumo_rev}</details>"
    parecer_contextual = r.get("parecer_contextual", "")
    diagnostico = ""
    desfecho_local = deslocamento_do_caso(cenario_relogios, revisao)
    leitura_resumida = "Mesmo local no cadastro do TSE de 25/10"
    if cenario_relogios:
        leitura_resumida = f"Deslocamento com até {MARGEM_MIN} minutos entre relógios · {e(desfecho_local)}"
        diagnostico = (f"<div class='accent'><p><strong>{leitura_resumida}</strong></p>"
                       f"<p>{e(cenario_relogios['motivo'])} "
                       "<a href='relatorio.html#cenario-relogios'>Critério para a diferença entre os relógios</a>.</p></div>")
    if ancora := FICHAS_INTERESTADUAIS.get(r["id_caso"]):
        diagnostico += f"<p><a href='relatorio.html#{ancora}'>Ler a análise da ordem dos cadastros nas duas urnas</a>.</p>"
    return (f"<details class='ficha' id='{id_html(r)}' data-t='{r['turno']}' data-c='{e(r['classe'])}' "
            f"data-r='{resumo}' data-g='{e(desfecho_local)}' data-v='{jurisdicao}' data-q='{e(busca)}'><summary {atributo(r)}><span>"
            f"<b>{numero(r['titulo'])} · {e(lugar)}</b><small>{r['turno']}º turno · {r['secoes']} seções</small>"
            f"<small>{leitura_resumida} · {jurisdicao} · {zona}</small></span>"
            f"<span class='veredito'>{resumo}</span></summary><div class='ficha-corpo'>"
            f"{diagnostico}<p>Referência de auditoria {e(r['id_caso'])}. {corresponde} <a href='#{id_html(r)}'>Link desta ficha</a></p>{parecer_contextual}"
            f"<section id='equipes-{e(r['turno'])}-{e(r['id_caso'].lower())}'><h3>Equipes registradas nas urnas do caso</h3>{quadro_equipes}</section>"
            f"<h3>Comparação dos títulos em cada seção</h3>{''.join(comp)}{outra}<h4>Rotas e horários registrados</h4>{tab_trechos}"
            f"<details><summary>Pares de seções e menor intervalo entre registros</summary>{tab_pares}</details></div></details>")


def opcoes(valores):
    return "".join(f"<option value='{e(v)}'>{e(v)}</option>" for v in sorted(valores))


def main(*, atualizar_tabelas=True):
    from avaliar_sem_rota import avaliar
    from relogios import COMPATIVEL, IMPROVAVEL, INDETERMINADO, avaliar as avaliar_relogios
    if atualizar_tabelas:
        gerar_geografia()
        gerar_logistica()
        gerar_logistica(True)
    todos = list(ler_csv("todos_casos.csv"))
    casos = list(ler_csv("comparacao_casos.csv"))
    catalogo = {secao(r):r for r in ler_csv("manifesto.csv")}
    for r in ler_csv("downloads.csv"):
        if r["erro"]:
            raise ValueError(f"Arquivo pendente em {secao(r)}")
        catalogo[secao(r)]["url_log"] = r["url_log"]
    for r in ler_csv("enderecos.csv"):
        catalogo[secao(r)].update({c+"_tse":r[c] for c in ("nome","local","endereco","bairro")})
    por_titulo = {chave(r): r for r in todos}
    campos = ("id_caso", "turno", "titulo", "classe", "uf", "codigo_municipio", "municipio", "zona",
              "secao", "local", "nome", "registros", "habilitacoes", "primeiro", "ultimo", "arquivo", "url_log")
    if atualizar_tabelas:
        with (DADOS / "secoes_por_caso.csv").open("w",encoding="utf-8-sig",newline="") as arq:
            escritor = csv.DictWriter(arq,fieldnames=campos,extrasaction="ignore")
            escritor.writeheader()
            for r in ler_csv("equipes.csv"):
                caso = por_titulo.get(chave(r))
                if caso:
                    escritor.writerow({**catalogo[secao(r)], **r, **caso, "secao":r["secao"]})
    secoes, pares = defaultdict(list), defaultdict(list)
    comps = defaultdict(lambda:defaultdict(list))
    extra = defaultdict(lambda:defaultdict(list))
    for r in ler_csv("comparacao_secoes.csv"):
        secoes[chave(r)].append(r)
    for r in ler_csv("deslocamentos.csv"):
        pares[chave(r)].append(r)
    logistica={chave(r):r for r in ler_csv("logistica_por_caso.csv")}
    trajetos=defaultdict(list)
    for r in ler_csv("trajetos_por_evento.csv"):
        trajetos[chave(r)].append(r)
    revisao={chave(r):r for r in ler_csv("logistica_por_caso_revisao.csv")}
    rev_trechos=defaultdict(list)
    for r in ler_csv("trajetos_por_evento_revisao.csv"):
        rev_trechos[chave(r)].append(r)
    equipes_ilustradas={(chave(r),secao(r),r["titulo_alternativo"]):r for r in ler_csv("contraste_equipes_edicoes.csv")}
    evidencias_fichas={chave(f):f for f in json.loads((DADOS/"evidencia_fichas_digitacao.json").read_bytes())}
    evidencias_fortes = {k: f for k, f in evidencias_fichas.items() if qualificar(f)[0] == "forte"}
    pares_fortes = {}
    for k, evidencia in evidencias_fortes.items():
        # O título repetido em Pedra Branca é o provável correto. A figura
        # com a omissão no sentido documentado está na ficha do capítulo.
        if evidencia["id_caso"] != PEDRA_BRANCA:
            mesa = turno_mesa(evidencia, True, True)
            pares_fortes[k] = (mesa["uf"], int(mesa["zona"]), int(mesa["secao"]), evidencia["alternativo"])
    for caso in casos:
        if chave(caso) in evidencias_fortes:
            evidencia = evidencias_fortes[chave(caso)]
            destino=f"relatorio.html#analise-{e(caso['id_caso'].lower())}-{e(caso['turno'])}"
            # As comparações que excedem o limite da busca inicial não aparecem na tabela de pares da ficha.
            complemento = particularidade(evidencia) + " " if evidencia["operacoes"] > 2 or caso["id_caso"] == PEDRA_BRANCA else ""
            caso["parecer_contextual"]=(
                f"<p><b>Erro de digitação com evidência forte.</b> {complemento}"
                f"<a href='{destino}'>Conferir a comparação dos títulos e as presenças nas duas seções</a>.</p>")
    equipes_associadas=set()
    com_contraste=set()
    for r in ler_csv("duas_edicoes_pares.csv"):
        r["erro_forte"] = (r["fonte"] == "registro" and pares_fortes.get(chave(r)) ==
                           (r["uf"], int(r["zona"]), int(r["secao"]), r["titulo_alternativo"]))
        if r["fonte"]=="registro" and custo(r)<=2:
            key=chave(r),secao(r),r["titulo_alternativo"]
            r["equipe_conferida"]=equipes_ilustradas[key]
            if r["equipe_conferida"]["troca_unica"] != "1" and r["erro_forte"]:
                r["parecer_entre_turnos"] = particularidade(evidencias_fichas[chave(r)])
            equipes_associadas.add(key)
            if r["escopo"]=="base" and r["contraste_ampliado_entre_turnos"]=="1":
                com_contraste.add(chave(r))
        indice=comps if r["fonte"]=="registro" else extra
        indice[chave(r)][secao(r)].append(r)
    if equipes_associadas!=set(equipes_ilustradas):
        raise ValueError("Há uma conferência da equipe sem comparação correspondente")
    desfechos={chave(r):classificacao(comps[chave(r)],extra[chave(r)]) for r in casos}
    destaques_logs=json.loads((DADOS/"exemplos_ilustrados.json").read_text(encoding="utf-8"))
    soma_edicoes=json.loads((DADOS/"duas_edicoes_resumo.json").read_text(encoding="utf-8"))["base"]["usual"]
    resumo = json.loads((DADOS / "extracao.json").read_text(encoding="utf-8"))
    classes = Counter((r["classe"],int(r["turno"])) for r in todos)
    resultados = Counter((desfechos[chave(r)],int(r["turno"])) for r in casos)
    def total(ch, v):
        return ch[v,1] + ch[v,2]
    def resumo_tabela(ch, ordem):
        return tabela(["Classificação", "1º turno", "2º turno", "Total"],
                      [(e(rotulo_logistico(v)),n(ch[v,1]),n(ch[v,2]),n(total(ch,v))) for v in ordem])
    ordem = ["Mesmo local cadastrado", "Locais distintos do mesmo município", "Municípios distintos na mesma UF", "UFs distintas"]
    por_resultado=sorted({c[0] for c in resultados},key=lambda v:("Sem correspondência" in v,
                         "outra menção" in v,not v.startswith("Uma"),v))
    casos.sort(key=lambda r:(ordem.index(r["classe"]) * -1, int(r["turno"]), secoes[chave(r)][0]["municipio"], r["id_caso"]))
    if set(map(chave,casos)) != set(secoes) or set(secoes) != set(pares):
        raise ValueError("Cobertura inconsistente entre as tabelas de casos, pares e seções")
    coord_externa={r["id_caso"]:r for r in ler_csv("conferencia_coordenadas.csv")}
    sem_rota={(int(t),titulo):a for (t,titulo),a in avaliar().items()}
    relogios = avaliar_relogios()
    resultados_relogios = Counter(r["resultado"] for r in relogios.values())
    listas=carregar_listas()
    alternativos={k:f["alternativo"] for k,f in evidencias_fichas.items()}
    def quadro_do_caso(caso):
        t=caso["titulo"]
        return renderizar_equipes(listas[caso["turno"],t], t, alternativos.get(chave(caso)), turno_do_caso=caso["turno"])
    fichas = "".join(ficha(r, secoes[chave(r)], comps[chave(r)], extra[chave(r)], pares[chave(r)], catalogo,
                           logistica[chave(r)],trajetos[chave(r)],revisao[chave(r)],rev_trechos[chave(r)],quadro_do_caso(r),
                           coord_externa.get(r["id_caso"]),sem_rota.get(chave(r)),relogios.get((r["turno"],r["titulo"]))) for r in casos)
    novos=list(ler_csv("revisao_comparacao_casos.csv"))
    if len(novos)!=1:
        raise ValueError("Verificar quantos casos passaram a locais distintos na revisão")
    novo=novos[0]
    fontes_previa = {(r["turno"], r["titulo"]): f"equipes-{r['turno']}-{r['id_caso'].lower()}" for r in [*casos, novo]}
    estilo_previa, controles_previa = componentes(listas, fontes_previa.keys(), fontes=fontes_previa)
    k=chave(novo)
    novos_pares=[r for r in ler_csv("deslocamentos_revisao.csv") if chave(r)==k]
    ficha_nova=ficha(novo,list(ler_csv("revisao_comparacao_secoes.csv")),comps[k],extra[k],novos_pares,
                     catalogo,revisao[k],rev_trechos[k],revisao[k],rev_trechos[k],quadro_do_caso(novo),
                     coord_externa.get(novo["id_caso"]),sem_rota.get(k),relogios[(novo["turno"],novo["titulo"])])
    ficha_nova=ficha_nova.replace("class='ficha'","class='ficha adicional'",1)
    om_turno = sum(int(r["omissoes_turno"]) > 0 for r in casos)
    om_outro = sum(int(r["omissoes_so_outro_turno"]) > 0 and not int(r["omissoes_turno"]) for r in casos)
    def com_candidato(r):
        return "título registrado" in desfechos[chave(r)]
    compativeis=sum(map(com_candidato,casos))
    mun_dif = [r for r in casos if r["classe"] in ordem[2:]]
    mes_mun = [r for r in casos if r["classe"] == ordem[1]]
    ufs_dif = [r for r in casos if r["classe"] == ordem[3]]
    suplementares=sum("outra menção" in v for v in desfechos.values())
    fortes = sum(r["avaliacao"] == EXTREMO for r in logistica.values())
    linha_logistica = Counter((r["avaliacao"],int(r["turno"])) for r in logistica.values())
    cruzamento=Counter()
    for r in casos:
        k=chave(r)
        tipo = "presença" if com_candidato(r) else "outra menção" if "outra menção" in desfechos[k] else "sem candidato"
        cruzamento[logistica[k]["avaliacao"],tipo]+=1
    log_rev = [r for r in revisao.values() if r["avaliacao"]!=MESMO]
    improvaveis_por_turno = Counter(r["turno"] for r in relogios.values() if r["resultado"] == IMPROVAVEL)
    mesmo_mun_zona=[r for r in logistica.values() if r["todos_no_mesmo_municipio"]=="1" and r["todos_na_mesma_zona"]=="1"]
    limitrofes=[r for r in logistica.values() if r["vizinhanca"]=="1"]
    ex_log=[]
    for candidatos in (mesmo_mun_zona,limitrofes,[r for r in limitrofes if r["avaliacao"]==CURTO]):
        desejada = CURTO if len(ex_log)==2 else OK
        for l in sorted(candidatos,key=lambda r:(int(r["turno"]),r["id_caso"])):
            if l["avaliacao"]!=desejada:
                continue
            t=next(x for x in trajetos[chave(l)] if x["avaliacao_logistica"]==desejada)
            if not t["percurso_rede_km"] or float(t["percurso_rede_km"])<=0:
                continue
            ex_log.append((numero(l["titulo"]),f"<a href='#{id_html(l)}'>{e(t['municipio_origem'])} · S{t['secao_origem']} → "
                           f"{e(t['municipio_destino'])} · S{t['secao_destino']}</a>",l["turno"]+"º",
                           duracao(t["intervalo_s"]),decimal(t["percurso_rede_km"],1)+" km · "+e(t["modo"]),
                           duracao(round(float(t["tempo_com_folga_s"]))),e(desejada)))
            break
    exemplos = []
    for uf_cidades in ({"RIBEIRA DO POMBAL","RIO DE JANEIRO"}, {"BRAGANÇA","RIO MARIA"},
                       {"GOIANÉSIA","ATALÉIA"}, {"CASA NOVA","PORTO SEGURO"}, {"PIRENÓPOLIS"}):
        for r in casos:
            k = chave(r)
            if {s["municipio"].upper() for s in secoes[k]} != uf_cidades:
                continue
            if uf_cidades == {"PIRENÓPOLIS"} and not any(p["equipes_invertidas"] == "True" for p in pares[k]):
                continue
            p = min(pares[k],key=lambda x:int(x["intervalo_s"]))
            ops = sorted((c for lst in comps[k].values() for c in lst if custo(c)<=2),key=ordem_candidato)
            if ops:
                c = ops[0]
                txt = (f"{e(c['municipio'])}, seção {c['secao']}, {c['turno_fonte']}º turno. "
                       f"{numero(c['titulo_alternativo'])} → {numero(c['titulo'])}. {operacoes_resumidas(c)}.")
            else:
                txt = "Nenhuma transformação testada reproduziu o número a partir dos outros títulos registrados."
            if p["equipes_invertidas"] == "True":
                txt += " As duas equipes de quatro aparecem em ordem invertida na abertura e no encerramento."
            exemplos.append((numero(r["titulo"]),f"<a href='#{id_html(r)}'>{e(p['municipio_a'])} ↔ {e(p['municipio_b'])}</a>",
                             r["turno"]+"º",decimal(p["distancia_km"]) if p["distancia_km"] else "—",
                             duracao(p["intervalo_s"]),txt))
            break
    contagem = len(todos)
    mesmo = contagem - len(relogios)
    incompatibilidades=[]
    for caso in casos:
        k=chave(caso)
        if logistica[k]["avaliacao"]!=EXTREMO:
            continue
        criticos=[t for t in trajetos[k] if t["avaliacao_logistica"]==EXTREMO]
        t=max(criticos,key=lambda t:float(t["distancia_km"])/(int(t["intervalo_s"])+120))
        caminho=f"{t['municipio_origem'].title()}/{t['uf_origem']} S{t['secao_origem']} → {t['municipio_destino'].title()}/{t['uf_destino']} S{t['secao_destino']}"
        grupos=[c for lista in comps[k].values() for c in lista if custo(c)<=2]
        if grupos:
            melhor=min(grupos,key=ordem_candidato)
            explicacao=(f"{numero(melhor['titulo_alternativo'])} → {numero(caso['titulo'])}<br>"
                        f"{operacoes_resumidas(melhor)} · {e(melhor['municipio'].title())} · {melhor['turno_fonte']}º turno")
        else:
            explicacao=f"{numero(caso['titulo'])}<br>{e(desfechos[k])}"
        incompatibilidades.append((f"<a href='#{id_html(caso)}'>{e(caminho)}</a>",caso["turno"]+"º",
                                   decimal(t["distancia_km"])+" km",duracao(t["intervalo_s"]),explicacao))
    novos_numericos=[]
    for caso in casos:
        k=chave(caso)
        if desfechos[k]!="Duas edições · título registrado":
            continue
        c=min((c for lst in comps[k].values() for c in lst if custo(c)<=2),key=ordem_candidato)
        lugares=" ↔ ".join(dict.fromkeys(s["municipio"].title()+" / "+s["uf"] for s in secoes[k]))
        novos_numericos.append((f"<a href='#{id_html(caso)}'>{e(lugares)}</a>",caso["turno"]+"º",
            f"{e(c['municipio'].title())} · Z{c['zona']} S{c['secao']} · {c['turno_fonte']}º T",
            numero(c["titulo_alternativo"]),numero(c["titulo"]),operacoes_resumidas(c)))
    bahia = destaques_logs["bahia"]
    secoes_bahia = secoes[2, bahia["titulo_repetido"]]
    origem_bahia = next(s for s in secoes_bahia if s["municipio"] == "CASA NOVA")
    rotulos_bahia = rotulos_mesarios(origem_bahia, [s for s in secoes_bahia if secao(s) != secao(origem_bahia)])
    dados = dict(MARGEM_MIN=str(MARGEM_MIN), CSV_RELOGIOS=CSV_CASOS.name, ESTILO_PREVIA=estilo_previa, CONTROLES_PREVIA=controles_previa,
                 COMPATIVEIS_RELOGIOS=n(resultados_relogios[COMPATIVEL]), IMPROVAVEIS_RELOGIOS=n(resultados_relogios[IMPROVAVEL]),
                 NOTA_INDETERMINADOS_RELOGIOS=(f" Em {n(resultados_relogios[INDETERMINADO])}, faltam dados para decidir."
                                               if resultados_relogios[INDETERMINADO] else ""),
                 TOTAL=n(contagem), DIF=n(len(casos)), MESMO=n(mesmo), PERCENTUAL=decimal(100*mesmo/contagem),
                 TITULOS=n(len({r['titulo'] for r in todos})), ARQUIVOS=n(resumo["pacotes_lidos"]),
                 MENSOES=n(resumo["linhas_por_titulo"]), FRAGMENTOS=n(resumo["fragmentos"]),
                 COMP=n(compativeis), SEM=n(len(casos)-compativeis-suplementares), OMISSAO=n(om_turno+om_outro),
                 UMA=n(soma_edicoes["registro_1"]), DUAS=n(soma_edicoes["registro_2"]),
                 DUAS_T=n(soma_edicoes["registro_2_mesmo_turno"]), DUAS_O=n(soma_edicoes["registro_2_so_outro_turno"]),
                 CASANOVA=painel_casa_nova(rotulos_bahia, erro_forte=True)+painel_bahia(bahia),
                 EXTREMOS=tabela(["Seções do trecho mais restritivo","Turno","Em linha reta","Intervalo","Resultado numérico"],incompatibilidades),
                 EXTREMOS_COM=n(cruzamento[EXTREMO,"presença"]),
                 GOIANESIA=painel_goianesia(),
                 OUTRO_TURNO=tabela(["Seção","Turno da repetição","Número repetido e registros","Alternativo no outro turno e registros"],
                     [(f"<a href='#{id_html(r)}'>{e(r['municipio'].title())} · Z{r['zona']} S{r['secao']}</a>",r["turno"]+"º",
                       numero(r["titulo"])+"<br>"+"<br>".join(e(x) for x in r["presencas_repetido"].split(" | ")),
                       numero(r["titulo_alternativo"])+"<br>"+"<br>".join(e(x) for x in r["presencas_alternativo_outro_turno"].split(" | ")))
                      for r in sorted(equipes_ilustradas.values(),key=lambda r:r["municipio"])
                      if r["resultado"]=="Candidato registrado somente no outro turno"]),
                 TROCA_UNICA=n(len({chave(r) for r in equipes_ilustradas.values() if r["troca_unica"]=="1"})),
                 SAOPAULO=painel_sao_paulo(destaques_logs["sao_paulo"]), ESTILO_EDICOES=ESTILO,
                 LISTA_NOVOS=tabela(["Caso","Turno","Seção com o alternativo","Alternativo","Repetido","Duas operações"],novos_numericos),
                 OM_T=n(om_turno), OM_O=n(om_outro), EXTRA=n(suplementares), FORTES=n(fortes),
                 TOTAL_LIDO=n(resumo["titulos_pesquisados"]),JANELA=n(resumo["linhas_fisicas_na_janela_do_turno"]),
                 ADICIONAIS=n(sum(1 for r in ler_csv("repeticoes_adicionais.csv"))),
                 EX_LOG=tabela(["Título repetido","Locais e seções","Turno","Tempo disponível","Trajeto","Com folga","Resultado"],ex_log),
                 LOGISTICA=resumo_tabela(linha_logistica,ORDEM),
                 FILTRO_LOG=opcoes({deslocamento_do_caso(relogios.get((r["turno"],r["titulo"])),revisao[chave(r)]) for r in casos}),
                 CRUZAMENTO=tabela(["Deslocamento","Alternativo registrado","Só em outra menção","Sem candidato"],[
                     (e(rotulo_logistico(v)),n(cruzamento[v,"presença"]),n(cruzamento[v,"outra menção"]),n(cruzamento[v,"sem candidato"])) for v in ORDEM]),
                 IMPROVAVEIS_PRIMEIRO=n(improvaveis_por_turno["1"]), IMPROVAVEIS_SEGUNDO=n(improvaveis_por_turno["2"]),
                 TOTAL_REV=n(len(log_rev)), NOVA=ficha_nova,
                 QUADRO_REV=resumo_tabela(Counter((r["avaliacao"],int(r["turno"])) for r in log_rev),ORDEM),
                 MNZ=n(len(mesmo_mun_zona)),MNZ_OK=n(sum(r["avaliacao"]==OK for r in mesmo_mun_zona)),
                 LIMITROFES=n(len(limitrofes)), LIMITROFES_OK=n(sum(r["avaliacao"]==OK for r in limitrofes)),
                 OK=n(sum(r["avaliacao"]==OK for r in logistica.values())),
                 CONTRASTE=n(len(com_contraste)),
                 ALCANCE_TIPOS=tabela(["Locais do caso", "Com título alternativo", "Sem título alternativo", "Casos"],
                                      [(legenda,n(sum(map(com_candidato,linhas))),n(len(linhas)-sum(map(com_candidato,linhas))),n(len(linhas)))
                                       for legenda,linhas in (("No mesmo município",mes_mun),("Em municípios diferentes",mun_dif),
                                                               ("↳ dos quais em UFs diferentes",ufs_dif))]),
                 GEO=resumo_tabela(classes,ordem), RESULTADOS=resumo_tabela(resultados,por_resultado),
                 EXEMPLOS=tabela(["Título repetido","Locais", "Turno", "km", "Intervalo", "Comparação na seção"], exemplos),
                 TIPO=opcoes({r["classe"] for r in casos}), FILTRO=opcoes(por_resultado), FICHAS=fichas)
    template = (ROOT / "modelo_relatorio.html").read_text(encoding="utf-8")
    import re
    pagina = re.sub(r"\{\{([A-Z_]+)\}\}",lambda m:dados[m[1]],template)
    destino = ROOT / "relatorio_tecnico.html"
    destino.write_text(pagina,encoding="utf-8")
    print(f"{n(len(casos))} fichas. {n(compativeis)} casos com candidato registrado em até duas operações.")


if __name__ == "__main__":
    main()
    from relatorio_estruturado import publicar
    publicar()
