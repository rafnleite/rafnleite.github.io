"""Recalcula o local e a distância por seção segundo a edição TSE de 25/10.

Lê as fontes do relatório e grava dados/deslocamentos_revisao.csv. Preserva
os pares da edição anterior e adiciona os que passam a ter locais distintos.
"""
from collections import defaultdict
import csv
from itertools import combinations, product
import math
import re
from zipfile import ZipFile

from geografia import (DADOS, FORTE, LIMITE_KMH, MARGEM_S, MESMO, OUTROS,
                       datas_horas, distancia, ler_csv, ler_zip, localidades, secao)


REF = re.compile(r"([A-Z]{2})/([0-9]+)/Z([0-9]+)/S([0-9]+)")


def chave_local(sec, endereco):
    return (*sec[1:4], int(endereco["local"]))


def coordenadas(endereco):
    try:
        lat, lon = float(endereco["latitude"]), float(endereco["longitude"])
    except (TypeError, ValueError):
        return None
    if not (math.isfinite(lat) and math.isfinite(lon) and -34 <= lat <= 6 and -74 <= lon <= -29):
        return None
    return lat, lon


def pares_novos(enderecos):
    # Um par de locais distintos na edição posterior pode estar na parte do
    # relatório que inicialmente agrupou todas as seções no mesmo local.
    for caso in ler_csv("todos_casos.csv"):
        if caso["classe"] != MESMO:
            continue
        secoes = []
        for ref in caso["referencias_secoes"].split(" | "):
            uf, mun, zona, num = REF.fullmatch(ref).groups()
            secoes.append((int(caso["turno"]), uf, int(mun), int(zona), int(num)))
        if len({chave_local(s, enderecos[s]) for s in secoes}) > 1:
            for a, b in combinations(sorted(secoes), 2):
                yield caso, a, b


def criar_linhas_novas(enderecos):
    novos = list(pares_novos(enderecos))
    desejados = {(s, caso["titulo"]) for caso, a, b in novos for s in (a, b)}
    horarios = defaultdict(list)
    for r in ler_csv("registros_qualificados.csv"):
        chave = (secao(r), r["titulo"])
        if chave in desejados and r["tipo"] == "registro":
            horarios[chave].append(datas_horas(r["data_hora"]))
    with ZipFile(DADOS / "arvor.zip") as arquivo:
        antigas = localidades(arquivo)
        publicados = {tuple(sorted([secao(r, "_a"), secao(r, "_b")])): r
                      for r in ler_zip(arquivo, "pares_de_secoes.csv")}
    for caso, a, b in novos:
        par = publicados[a, b]
        titulo = caso["titulo"]
        # As seções de um mesmo local original necessariamente são do mesmo
        # município. Seus relógios estão no mesmo fuso.
        seg, ha, hb = min((abs((x-y).total_seconds()), x, y)
                          for x, y in product(horarios[a,titulo], horarios[b,titulo]))
        if int(par["ids_em_comum"]) == 1 and int(par["menor_intervalo_registros_utc_s"]) != int(seg):
            raise ValueError(f"Intervalo publicado diverge dos registros de {caso['id_caso']}")
        row = dict(id_caso=caso["id_caso"], turno=a[0], titulo=titulo, intervalo_s=int(seg),
                   hora_local_a=ha.isoformat(" "), hora_local_b=hb.isoformat(" "),
                   fonte_intervalo="Registros do título nos dois arquivos, mesmo município",
                   equipes_invertidas=par["equipes_de_quatro_invertidas"], titulos_em_comum=par["ids_em_comum"])
        for lado, s in (("a",a), ("b",b)):
            _, _, municipio, _, url = antigas[s]
            for col, valor in zip(("uf", "codigo_municipio", "municipio", "zona", "secao", "url"),
                                  (s[1], f"{s[2]:05}", municipio, s[3], s[4], url)):
                row[f"{col}_{lado}"] = valor
        yield row


def revisar(row, enderecos):
    keys = [secao(row, sufixo) for sufixo in ("_a", "_b")]
    points, locais = [], []
    for lado, key in zip(("a", "b"), keys):
        endereco = enderecos[key]
        point = coordenadas(endereco)
        points.append(point)
        locais.append(chave_local(key, endereco))
        row[f"local_{lado}"] = endereco["local"]
        row[f"nome_{lado}"] = endereco["nome"]
        row[f"latitude_{lado}"] = endereco["latitude"] if point else ""
        row[f"longitude_{lado}"] = endereco["longitude"] if point else ""
    km = distancia(*points)
    velocidade = 3600 * km / (int(row["intervalo_s"]) + MARGEM_S) if km is not None else None
    a, b = keys
    if locais[0] == locais[1]:
        alcance = MESMO
    elif a[1] != b[1]:
        alcance = "UFs diferentes"
    elif a[2] != b[2]:
        alcance = "Municípios diferentes na UF"
    else:
        alcance = "Locais diferentes no município"
    row["alcance"] = alcance
    row["avaliacao"] = MESMO if alcance == MESMO else OUTROS
    if alcance != MESMO and velocidade is not None and velocidade > LIMITE_KMH:
        row["avaliacao"] = FORTE
    row["distancia_km"] = "" if km is None else round(km, 4)
    row["km_h_min_com_margem"] = "" if velocidade is None else round(velocidade, 2)


def gerar():
    enderecos = {}
    for r in ler_csv("enderecos.csv"):
        key = secao(r)
        if r["geracao"] != "25/10/2026" or key in enderecos:
            raise ValueError(f"Edição ou chave inesperada em enderecos.csv: {key}")
        enderecos[key] = r
    rows = list(ler_csv("deslocamentos.csv"))
    fields = list(rows[0])
    rows.extend(criar_linhas_novas(enderecos))
    seen = set()
    path = DADOS / "deslocamentos_revisao.csv"
    temp = path.with_suffix(".csv.tmp")
    with temp.open("w", newline="", encoding="utf-8-sig") as out:
        writer = csv.DictWriter(out, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            key = (row["id_caso"], tuple(sorted([secao(row, "_a"), secao(row, "_b")])))
            if key in seen:
                raise ValueError(f"Par repetido para a mesma ficha: {key}")
            seen.add(key)
            revisar(row, enderecos)
            writer.writerow(row)
    temp.replace(path)
    print(f"{len(seen)} pares na revisão do cadastro.")


if __name__ == "__main__":
    gerar()
