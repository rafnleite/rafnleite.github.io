"""Compara o tempo entre eventos consecutivos com trajetos a pé ou de carro."""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from itertools import pairwise

from geografia import DADOS, LIMITE_KMH, MARGEM_S, MESMO, datas_horas, ler_csv, secao
from rotas import formato, ponto

OK = "Compatível com remanejamento"
LIMIAR = "Trajeto cabe, com pouca folga"
CURTO = "Intervalo menor que o trajeto estimado"
EXTREMO = "Incompatível no cenário de 1.000 km/h"
INCERTO = "Dados insuficientes para estimar o trajeto"
ORDEM = [OK,LIMIAR,INCERTO,CURTO,EXTREMO]
# Folgas operacionais ilustrativas após o tempo de rede e os acessos a pé.
FOLGAS = {"carro":300,"a pé":120}


def salvar(nome, linhas):
    with (DADOS/nome).open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=list(linhas[0]))
        w.writeheader()
        w.writerows(linhas)


def rede(nome):
    return {(r["origem"],r["destino"]):r for r in ler_csv(nome)}


def checar_rota(g,origem,intervalo,redes):
    lado="a" if origem==secao(g,"_a") else "b"
    outro="b" if lado=="a" else "a"
    p,q=ponto(g,lado),ponto(g,outro)
    opcoes=[]
    dist=float(g["distancia_km"]) if g["distancia_km"] else None
    if p and q:
        if p==q:
            # A posição coincidente tem precisão cadastral. Reservamos tempo para a troca de sala.
            opcoes.append(("coordenadas coincidentes",0,120,0,0,""))
        else:
            for modo,rotas in redes.items():
                rota = rotas.get((formato(p),formato(q)))
                if not rota or not rota["tempo_s"]:
                    continue
                acessos = [float(rota[k]) for k in ("acesso_origem_m","acesso_destino_m")]
                if max(acessos)>300:
                    continue
                acesso_m=sum(acessos)
                segundos=float(rota["tempo_s"])+acesso_m/1.111111111
                opcoes.append((modo,segundos,segundos+FOLGAS[modo],float(rota["metros"]),acesso_m,rota["resposta"]))
    escolha = min(opcoes,key=lambda op:op[2]) if opcoes else None
    if dist is not None and dist*3600/(intervalo+MARGEM_S)>LIMITE_KMH:
        status=EXTREMO
    elif not opcoes:
        status=INCERTO
    elif intervalo>=escolha[2]:
        status=OK
    elif any(intervalo>=op[1] for op in opcoes):
        status=LIMIAR
        escolha=min((op for op in opcoes if intervalo>=op[1]),key=lambda op:op[2])
    else:
        status=CURTO
    modo,seg,com_folga,metros,acesso,ref=escolha if escolha else ("",None,None,None,None,"")
    return dict(avaliacao_logistica=status,modo=modo,tempo_trajeto_s=round(seg,1) if seg is not None else "",
                tempo_com_folga_s=round(com_folga,1) if com_folga is not None else "",
                percurso_rede_km=round(metros/1000,3) if metros is not None else "",
                acesso_fora_rede_m=round(acesso,1) if acesso is not None else "",fonte_rota=ref)


def gerar(revisao=False):
    carro,pe=rede("rotas.csv"),rede("rotas_a_pe.csv")
    vizinhos={}
    for r in ler_csv("vizinhanca.csv"):
        # Campos da correspondência oficial TSE x IBGE.
        a=(r["uf_a"].upper(),int(r["codigo_municipio_a"]))
        b=(r["uf_b"].upper(),int(r["codigo_municipio_b"]))
        vizinhos[frozenset((a,b))]=r["vizinhos"]
    casos=defaultdict(dict)
    sufixo="_revisao" if revisao else ""
    for r in ler_csv("deslocamentos"+sufixo+".csv"):
        a,b=secao(r,"_a"),secao(r,"_b")
        casos[a[0],r["titulo"]][tuple(sorted((a,b)))]=r
    cronos=defaultdict(list)
    for r in ler_csv("registros_qualificados.csv"):
        k=int(r["turno"]),r["titulo"]
        if k in casos:
            s=secao(r)
            if any(s in par for par in casos[k]):
                cronos[k].append((datas_horas(r["data_hora"]),s,r["tipo"],r["membro"],int(r["linha"])))
    saida, resumos=[],[]
    for k,pares in casos.items():
        # O mesmo município usa um só relógio civil. Nestes 43 pares entre municípios
        # as duas localidades também estão no mesmo fuso, e o intervalo de registros
        # é conferido aqui contra o valor em UTC publicado para o par.
        por_sec=defaultdict(list)
        for h,s,t,_,_ in cronos[k]:
            if t=="registro":
                por_sec[s].append(h)
        for (a,b),g in pares.items():
            if a[1:3]!=b[1:3]:
                recalculo=min(abs((x-y).total_seconds()) for x in por_sec[a] for y in por_sec[b])
                if int(g["intervalo_s"])!=recalculo:
                    raise ValueError(f"Revisar fuso antes da classificação: {a}, {b}")
        trechos=[]
        for anterior,seguinte in pairwise(sorted(cronos[k])):
            h1,s1,t1,m1,l1=anterior
            h2,s2,t2,m2,l2=seguinte
            if s1==s2:
                continue
            par=tuple(sorted((s1,s2)))
            g=pares[par]
            if g["local_a"]==g["local_b"] and s1[1:4]==s2[1:4]:
                continue
            delta=int((h2-h1).total_seconds())
            teste=checar_rota(g,s1,delta,{"carro":carro,"a pé":pe})
            mesma_cidade=s1[1:3]==s2[1:3]
            divisa="" if mesma_cidade else vizinhos[frozenset((s1[1:3],s2[1:3]))]
            mesma_zona=s1[1]==s2[1] and s1[3]==s2[3]
            lados=("a","b") if s1==par[0] else ("b","a")
            r=dict(id_caso=g["id_caso"],turno=k[0],titulo=k[1],**teste,
                   mesmo_municipio=int(mesma_cidade),mesma_zona=int(mesma_zona),municipios_vizinhos=divisa,
                   distancia_km=g["distancia_km"],intervalo_s=delta)
            for destino,lado,h,s,t,m,l in zip(("origem","destino"),lados,(h1,h2),(s1,s2),(t1,t2),(m1,m2),(l1,l2)):
                r.update({c+"_"+destino:g[c+"_"+lado] for c in ("uf","codigo_municipio","municipio","zona","secao","local","nome")})
                r.update({"hora_"+destino:h.isoformat(" "),"evento_"+destino:t,"membro_"+destino:m,"linha_"+destino:l})
            trechos.append(r)
        if not trechos and any(r["avaliacao"]!=MESMO for r in pares.values()):
            raise ValueError("Caso entre locais sem transição observada")
        pior=max(trechos,key=lambda r:ORDEM.index(r["avaliacao_logistica"])) if trechos else {
            "avaliacao_logistica":MESMO,"id_caso":next(iter(pares.values()))["id_caso"]}
        cont=Counter(r["avaliacao_logistica"] for r in trechos)
        resumos.append(dict(id_caso=pior["id_caso"],turno=k[0],titulo=k[1],avaliacao=pior["avaliacao_logistica"],
                            mudancas_de_local=len(trechos),compativeis=cont[OK],limitrofes=cont[LIMIAR],curtas=cont[CURTO],
                            extremas=cont[EXTREMO],sem_estimativa=cont[INCERTO],
                            todos_no_mesmo_municipio=int(all(r["mesmo_municipio"] for r in trechos)),
                            todos_na_mesma_zona=int(all(r["mesma_zona"] for r in trechos)),
                            vizinhanca=" | ".join(sorted({str(r["municipios_vizinhos"]) for r in trechos if not r["mesmo_municipio"]}))))
        saida.extend(trechos)
    salvar("trajetos_por_evento"+sufixo+".csv",saida)
    salvar("logistica_por_caso"+sufixo+".csv",resumos)
    print(dict(Counter(r["avaliacao"] for r in resumos)))


if __name__=="__main__":
    gerar()
    if (DADOS/"deslocamentos_revisao.csv").exists():
        gerar(True)
