"""Aplica a navegação e a identidade de eleições 2026 às páginas estáticas dos mesários."""
import re
from html import escape


PAGINAS = {
    "relatorio.html": "Relatório dos mesários",
    "sankey_turnos.html": "Diagrama de Sankey por turno",
    "teste_dv.html": "Teste dos dígitos verificadores",
    "votos_vizinhas.html": "Comparação com urnas vizinhas",
}

MENU = """
<script>
(() => {
    const menu = document.getElementById("indice-mesarios");
    const botao = document.getElementById("abrir-indice-mesarios");
    function alternar(aberto) {
        menu.classList.toggle("open", aberto);
        botao.setAttribute("aria-expanded", String(aberto));
    }
    botao.addEventListener("click", () => alternar(!menu.classList.contains("open")));
    menu.addEventListener("click", evento => {
        if (evento.target.closest("a")) alternar(false);
    });
    document.addEventListener("keydown", evento => {
        if (evento.key === "Escape" && menu.classList.contains("open")) {
            alternar(false);
            botao.focus();
        }
    });
    document.addEventListener("click", evento => {
        if (!menu.contains(evento.target) && !botao.contains(evento.target)) alternar(false);
    });
    document.getElementById("imprimir-mesarios").addEventListener("click", () => window.print());
})();
</script>"""


PERFIS_AUTOR = """<small class="perfis-autor">
    <a href="https://twitter.com/rafnleite" rel="me" aria-label="Rafael Leite no Twitter (X)" title="Twitter (X)"><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="../assets/perfis.svg#twitter"></use></svg></a>
    <a href="https://www.linkedin.com/in/rafnleite/" rel="me" aria-label="Rafael Leite no LinkedIn" title="LinkedIn"><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="../assets/perfis.svg#linkedin-in"></use></svg></a>
  </small>"""


def _barra_lateral(nome, capitulos):
    links = []
    for pagina, legenda in PAGINAS.items():
        atual = ' aria-current="page"' if pagina == nome else ""
        classe = "tool active" if atual and not capitulos else "tool"
        links.append(f'<a class="{classe}" href="{pagina}"{atual}>{escape(legenda)}</a>')
    indice = ""
    if capitulos:
        indice = f'<div class="extra">NESTA PÁGINA</div>{capitulos}'
    return f"""
<a class="skip" href="#conteudo">Ir para o conteúdo</a>
<div class="mobile-nav"><strong>Eleições 2026</strong>{PERFIS_AUTOR}<button type="button" id="abrir-indice-mesarios" aria-controls="indice-mesarios" aria-expanded="false">Índice ☰</button></div>
<aside class="sidebar" id="indice-mesarios">
  <div class="identity"><img src="../assets/perfil.jpg" alt="Ilustração de Rafael Leite" width="104" height="104"><strong>Rafael Leite</strong><small>Análise de dados eleitorais</small>
    {PERFIS_AUTOR}</div>
  <nav aria-label="Índice dos relatórios">
    {indice}
    <div class="extra">TÍTULOS DE MESÁRIO</div>
    {"".join(links)}
    <a href="../index.html#mesarios">Relatório principal das eleições de 2026</a>
  </nav>
</aside>"""


def aplicar_tema(nome, html):
    """Mantém as âncoras, scripts e dados incorporados ao aplicar o tema em /eleicoes_2026/mesarios/."""
    if nome not in PAGINAS:
        raise ValueError(f"Página de mesários desconhecida: {nome}")
    # Dois anexos deixam implícitas as tags head e body. Preservar o conteúdo
    # original como texto evita processar ou reserializar os megabytes de JSON.
    inicio = re.search(r"<(?:header|main)>", html)
    if not inicio:
        raise ValueError(f"Conteúdo ausente em {nome}")
    cabeca, corpo = html[:inicio.start()], html[inicio.start():]
    cabeca = re.sub(r"(?:</head>\s*)?(?:<body>\s*)?$", "", cabeca).rstrip()
    if "<head>" not in cabeca:
        cabeca = re.sub(r"(<html\b[^>]*>)", r"\1<head>", cabeca, count=1)
    corpo = re.sub(r"\s*(?:</body>\s*)?</html>\s*$", "", corpo)
    titulo = re.search(r"<h1>(.*?)</h1>", corpo, re.S)
    if not titulo:
        raise ValueError(f"Título da página ausente em {nome}")
    titulo = titulo[1]
    if corpo.count("<main>") != 1 or corpo.count("</main>") != 1:
        raise ValueError(f"Estrutura principal inesperada em {nome}")
    corpo = corpo.replace("<main>", "", 1).replace("</main>", "", 1)
    topo = re.match(r"<header>(.*?)</header>", corpo, re.S)
    subtitulo, atalhos = "", ""
    if topo:
        depois = topo[1].split("</h1>", 1)[1]
        paragrafo = re.search(r"<p>(.*?)</p>", depois, re.S)
        if paragrafo:
            subtitulo = f'<p class="deck">{paragrafo[1]}</p>'
        atalhos = "".join(re.findall(r"<a\b[^>]*>.*?</a>", topo[1], re.S))
        corpo = corpo[topo.end():]
    else:
        corpo = corpo.replace(f"<h1>{titulo}</h1>", "", 1)
    # Os índices internos migram para a navegação lateral. Nos anexos que
    # abrem com links de retorno ou download, estes pertencem ao cabeçalho.
    capitulos = ""
    nav = re.search(r"<nav\b[^>]*>(.*?)</nav>", corpo, re.S)
    if nav and (nome in ("relatorio.html", "votos_vizinhas.html")
                or not corpo[:nav.start()].strip()):
        hrefs = re.findall(r'href=["\']([^"\']+)', nav[1])
        if hrefs and all(href.startswith("#") for href in hrefs):
            capitulos = nav[1]
        else:
            atalhos += nav[1]
        corpo = corpo[:nav.start()] + corpo[nav.end():]
    contexto = "Eleições presidenciais de 2026 · Brasil, excluído o exterior"
    if nome != "relatorio.html":
        contexto = f"Mesários · {PAGINAS[nome]}"
    cabeca += """
<meta name="theme-color" content="#f6f7f8">
<link rel="stylesheet" href="../assets/relatorio.css?v=coluna-perfis-1">
<link rel="stylesheet" href="../assets/mesarios.css?v=fichas-compactas-2">
<script defer src="../assets/indice-relatorio.js"></script>
<noscript><style>@media(max-width:760px){.mesarios .sidebar{display:block;position:static;width:100%;box-shadow:none}.mesarios .mobile-nav{display:none}.mesarios .sidebar .identity .perfis-autor{display:flex}}</style></noscript></head>"""
    nome_css = nome.removesuffix(".html").replace("_", "-")
    acoes = f'<div class="meta">{atalhos}</div>' if atalhos else ""
    return (cabeca + f'<body class="mesarios pagina-{nome_css}">' + _barra_lateral(nome, capitulos)
            + f'<main class="main" id="conteudo" tabindex="-1"><header class="masthead">'
            + '<div class="volta-ao-relatorio"><a href="../index.html#mesarios">'
            + '<span aria-hidden="true">← </span>Voltar ao relatório principal das eleições de 2026</a>'
            + '<button type="button" class="print-button" id="imprimir-mesarios">Imprimir página</button></div>'
            + f'<p class="eyebrow">{escape(contexto)}</p><h1>{titulo}</h1>{subtitulo}{acoes}'
            + '</header>' + corpo + '</main>' + MENU + '</body></html>\n')
