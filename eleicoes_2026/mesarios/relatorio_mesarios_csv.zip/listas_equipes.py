"""Listas completas de presença por caso, seção, turno, série de urna e etapa.

Execute este arquivo depois de extrair e comparar os logs. O CSV inclui uma
linha por confirmação. Para abertura ou encerramento sem presença confirmada
há uma linha de situação com o campo de título vazio. Cada caso tem sua própria
cópia das linhas das seções, para permitir o filtro pelo título repetido.
"""
import csv
import io
import os
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from tempfile import NamedTemporaryFile
from zipfile import ZipFile

from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify


SAIDA = BASE / "relatorio" / "listas_equipes_comparadas.csv"
EXEMPLOS_MESMO_LOCAL = (("1", "M-E0E650FA64F8"), ("1", "M-867C20A665E8"), ("2", "M-198A7EDC3C55"))
CAMPOS_MESA = ("turno", "uf", "codigo_municipio", "municipio", "zona", "secao", "local", "nome", "endereco",
               "arquivo", "sha256", "url_log")
CAMPOS = ("turno_caso", "titulo_repetido", "id_caso", *CAMPOS_MESA, "urna", "etapa", "situacao",
          "titulo_registrado", "data_hora", "membro", "linha", "linha_marcador",
          "eleitor_da_secao", "linha_eleitor_da_secao")


def casos_comparados():
    casos = defaultdict(dict)
    for nome in ("comparacao_secoes.csv", "revisao_comparacao_secoes.csv", "secoes_por_caso.csv"):
        exemplo = nome == "secoes_por_caso.csv"
        for r in linhas(nome):
            if exemplo and (r["turno"], r["id_caso"]) not in EXEMPLOS_MESMO_LOCAL:
                continue
            caso = (r["turno"], r["titulo"])
            turnos = (r["turno"],) if exemplo else ("1", "2")
            for turno in turnos:
                mesa = (turno, *identify(r)[1:])
                casos[caso][mesa] = r
    return casos


def enderecos_das_secoes(chaves):
    enderecos = {identify(r): r for r in linhas("enderecos.csv") if identify(r) in chaves}
    faltam = chaves - enderecos.keys()
    if not faltam:
        return enderecos
    # O recorte inicial não incluía o pacote complementar da revisão de Fartura.
    with ZipFile(BASE / "eleitorado_local_votacao_2026.zip") as z:
        for uf in sorted({k[1] for k in faltam}):
            with io.TextIOWrapper(z.open(f"eleitorado_local_votacao_2026_{uf}.csv"), encoding="latin-1") as f:
                for r in csv.DictReader(f, delimiter=";"):
                    k = (r["NR_TURNO"], uf, r["CD_MUNICIPIO"].zfill(5), r["NR_ZONA"], r["NR_SECAO"])
                    if k in faltam:
                        enderecos[k] = dict(local=r["NR_LOCAL_VOTACAO"], nome=r["NM_LOCAL_VOTACAO"],
                                            endereco=r["DS_ENDERECO"], bairro=r["NM_BAIRRO"], cep=r["NR_CEP"],
                                            latitude=r["NR_LATITUDE"], longitude=r["NR_LONGITUDE"])
    return enderecos


def insumos(chaves):
    fontes, cobertura, qualificados, equipes = {}, {}, {}, {}
    for pasta, manifesto in (("", "manifesto.csv"), ("revisao_extracao/", "revisao_manifesto.csv")):
        locais = {identify(r): r for r in linhas(manifesto) if identify(r) in chaves}
        for k, r in locais.items():
            if k in fontes and fontes[k]["sha256"] != r["sha256"]:
                raise ValueError(f"Manifestos divergentes em {k}")
            fontes[k] = r
        etapa = defaultdict(Counter)
        for r in linhas(pasta + "registros_qualificados.csv"):
            k = identify(r)
            if k in locais:
                evento = (r["titulo"], r["data_hora"], r["urna"], r["tipo"], r["membro"], int(r["linha"]))
                etapa[k][evento] += 1
        contagens = defaultdict(Counter)
        for r in linhas(pasta + "equipes.csv"):
            k = identify(r)
            if k in locais and int(r["registros"]):
                contagens[k][r["titulo"]] = int(r["registros"])
        for r in linhas(pasta + "cobertura_extracao.csv"):
            k = identify(r)
            if k in locais:
                if r["sha256"] != locais[k]["sha256"] or len(contagens[k]) != int(r["titulos_registrados"]):
                    raise ValueError(f"Divergência no índice do pacote {k}")
                if k in cobertura and (etapa[k] != qualificados[k] or contagens[k] != equipes[k]):
                    raise ValueError(f"Extração de revisão divergente em {k}")
                cobertura[k] = r
                qualificados[k] = etapa[k]
                equipes[k] = contagens[k]
    if fontes.keys() != cobertura.keys():
        raise ValueError("Falta o índice da extração oficial de um pacote")
    enderecos = enderecos_das_secoes(fontes.keys())
    return [(k, fontes[k], enderecos[k], qualificados[k], equipes[k]) for k in sorted(fontes)]


def ler_pacote(item):
    k, fonte, endereco, qualificados, esperado = item
    # ler_secao relê os marcadores no JEZ (por membro, série e data), verifica o
    # hash do arquivo e reconcilia as linhas com a extração de fase oficial.
    s = ler_secao(fonte, endereco, set(esperado), qualificados)
    if Counter(e["titulo"] for e in s["registros"]) != esperado:
        raise ValueError(f"Contagem de confirmações divergente em {k}")
    urnas = sorted({e[2] for e in qualificados})
    return k, {**{c: s[c] for c in CAMPOS_MESA}, "urnas": urnas, "registros": s["registros"], "disponivel": True}


def linhas_da_mesa(s):
    base = {c: s[c] for c in CAMPOS_MESA}
    etapas = defaultdict(set)
    for e in s["registros"]:
        etapas[e["urna"]].add(e["etapa"])
        yield {**base, **{c: e[c] for c in ("urna", "etapa", "data_hora", "membro", "linha", "linha_marcador",
                                            "eleitor_da_secao", "linha_eleitor_da_secao")},
               "titulo_registrado": e["titulo"], "situacao": "presença confirmada"}
    for urna in s["urnas"] or [""]:
        for etapa in ("abertura", "encerramento"):
            if etapa not in etapas[urna]:
                yield {**base, "urna": urna, "etapa": etapa,
                       "situacao": "sem registro de presença nesta etapa" if s["disponivel"] else "pacote indisponível"}


def gerar():
    casos = casos_comparados()
    pedidas = {k for mesas in casos.values() for k in mesas}
    jobs = insumos(pedidas)
    with ProcessPoolExecutor(max_workers=min(6, os.cpu_count() or 1)) as pool:
        lidas = dict(pool.map(ler_pacote, jobs, chunksize=8))
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile("w", dir=SAIDA.parent, encoding="utf-8-sig", newline="", delete=False) as f:
        tmp = f.name
        try:
            saida = csv.DictWriter(f, fieldnames=CAMPOS)
            saida.writeheader()
            n_eventos = 0
            n_linhas = 0
            for (turno, titulo), ss in sorted(casos.items()):
                for k, r in sorted(ss.items()):
                    s = lidas.get(k)
                    if k[0] == turno and (not s or sum(e["titulo"] == titulo for e in s["registros"]) != int(r["registros"])):
                        raise ValueError(f"Registros do título repetido divergem em {turno}/{titulo}/{k}")
                    if s is None:
                        s = dict.fromkeys(CAMPOS_MESA, "")
                        s.update(turno=k[0], uf=k[1], codigo_municipio=k[2], zona=k[3], secao=k[4],
                                 municipio=r["municipio"], registros=[], urnas=[], disponivel=False)
                    for ev in linhas_da_mesa(s):
                        saida.writerow(dict(turno_caso=turno, titulo_repetido=titulo, id_caso=r["id_caso"], **ev))
                        n_eventos += ev["situacao"] == "presença confirmada"
                        n_linhas += 1
        except BaseException:
            f.close()
            os.unlink(tmp)
            raise
    os.replace(tmp, SAIDA)
    return {"casos": len(casos), "pacotes": len(lidas), "pacotes_ausentes": len(pedidas)-len(lidas),
            "linhas_csv": n_linhas, "confirmacoes_por_caso": n_eventos,
            "confirmacoes_distintas": sum(len(s["registros"]) for s in lidas.values())}


def carregar_listas():
    """Indexa o CSV por (turno do caso, título repetido); devolve todas as mesas."""
    grupos = defaultdict(dict)
    with SAIDA.open(encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            mesas = grupos[r["turno_caso"], r["titulo_repetido"]]
            k = identify(r)
            if k not in mesas:
                mesas[k] = {c: r[c] for c in CAMPOS_MESA}
                mesas[k].update(id_caso=r["id_caso"], turno=int(r["turno"]), zona=int(r["zona"]), secao=int(r["secao"]),
                                urnas=[], registros=[], disponivel=r["situacao"] != "pacote indisponível")
            s = mesas[k]
            if r["urna"] and r["urna"] not in s["urnas"]:
                s["urnas"].append(r["urna"])
            if r["titulo_registrado"]:
                s["registros"].append(dict(titulo=r["titulo_registrado"], data_hora=r["data_hora"], urna=r["urna"],
                                           etapa=r["etapa"], membro=r["membro"], linha=int(r["linha"]),
                                           linha_marcador=int(r["linha_marcador"]) if r["linha_marcador"] else None,
                                           eleitor_da_secao=r.get("eleitor_da_secao", ""),
                                           linha_eleitor_da_secao=int(r["linha_eleitor_da_secao"])
                                           if r.get("linha_eleitor_da_secao") else None))
    return {caso: list(mesas.values()) for caso, mesas in grupos.items()}


if __name__ == "__main__":
    print(gerar())
