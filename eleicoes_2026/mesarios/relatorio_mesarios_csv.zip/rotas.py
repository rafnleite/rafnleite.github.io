"""Obtém matrizes rodoviárias do OSRM/FOSSGIS para as coordenadas dos locais."""
import argparse
import csv
import hashlib
import json
import time
from datetime import datetime, timezone
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from geografia import DADOS, ler_csv

SERVICO = "https://routing.openstreetmap.de/routed-{}/table/v1/driving/"


def ponto(r, lado):
    x,y = r["longitude_"+lado],r["latitude_"+lado]
    return (round(float(x),6),round(float(y),6)) if x and y else None


def formato(p):
    return ",".join(f"{x:.6f}" for x in p)


def coletar(modo):
    entradas=["deslocamentos.csv","deslocamentos_revisao.csv"]
    pares = {tuple(sorted([ponto(r,"a"),ponto(r,"b")])) for nome in entradas if (DADOS/nome).exists()
             for r in ler_csv(nome) if ponto(r,"a") and ponto(r,"b") and ponto(r,"a")!=ponto(r,"b")
             and (modo=="car" or float(r["distancia_km"])<=2)}
    arquivo_saida = "rotas.csv" if modo=="car" else "rotas_a_pe.csv"
    linhas=list(ler_csv(arquivo_saida)) if (DADOS/arquivo_saida).exists() else []
    conhecidas={(r["origem"],r["destino"]) for r in linhas}
    pares={p for p in pares if any((formato(a),formato(b)) not in conhecidas for a,b in (p,p[::-1]))}
    if not pares:
        return
    ordenados = sorted(pares,key=lambda par:(sum(p[1] for p in par),sum(p[0] for p in par),par))
    cache = DADOS / "osrm"
    cache.mkdir(exist_ok=True)
    for inicio in range(0,len(ordenados),12):
        lote = ordenados[inicio:inicio+12]
        pontos = list(dict.fromkeys(p for par in lote for p in par))
        url = SERVICO.format(modo)+";".join(map(formato,pontos))+"?annotations=duration,distance&generate_hints=false"
        ref = cache/(hashlib.sha256(url.encode()).hexdigest()[:20]+".json")
        if not ref.exists():
            for tentativa in range(3):
                try:
                    req = Request(url,headers={"User-Agent":"ConferenciaLocaisDeVotacao2026/1.0 (local research)"})
                    with urlopen(req,timeout=35) as resp:
                        resp_json = json.load(resp)
                    if resp_json["code"] != "Ok":
                        raise ValueError(resp_json["code"])
                    registro = {"url":url,"consulta_utc":datetime.now(timezone.utc).isoformat(),"dados":resp_json}
                    temporario = ref.with_suffix(".tmp")
                    temporario.write_text(json.dumps(registro,ensure_ascii=False),encoding="utf-8")
                    temporario.replace(ref)
                    time.sleep(1.2)
                    break
                except (OSError,ValueError) as err:
                    if tentativa==2 or isinstance(err,HTTPError) and 400<=err.code<500 and err.code!=429:
                        raise
                    time.sleep(5*(tentativa+1))
        item=json.loads(ref.read_text(encoding="utf-8"))
        dados=item["dados"]
        for a,b in lote:
            for origem,destino in ((a,b),(b,a)):
                i,j=pontos.index(origem),pontos.index(destino)
                linhas.append(dict(origem=formato(origem),destino=formato(destino),
                    tempo_s=dados["durations"][i][j],metros=dados["distances"][i][j],
                    acesso_origem_m=dados["sources"][i]["distance"],acesso_destino_m=dados["destinations"][j]["distance"],
                    versao_malha=dados.get("data_version",""),consulta_utc=item["consulta_utc"],resposta="osrm/"+ref.name))
        print(f"Rotas: {min(inicio+12,len(ordenados))}/{len(ordenados)} pares",flush=True)
    tmp=(DADOS/arquivo_saida).with_suffix(".tmp")
    with tmp.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=list(linhas[0]))
        w.writeheader()
        w.writerows(linhas)
    tmp.replace(DADOS/arquivo_saida)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--modo",choices=("car","foot","ambos"),default="ambos")
    modo=parser.parse_args().modo
    for perfil in (("car","foot") if modo=="ambos" else (modo,)):
        coletar(perfil)
