(() => {
    "use strict";
    const fonte = document.getElementById("equipes-para-previa");
    if (!fonte) return;

    const casos = JSON.parse(fonte.textContent);
    const seletor = "[data-equipe-prever]";
    let ativo = null;
    let fixo = false;
    let devolvendoFoco = false;
    let fecharDepois = 0;
    let quadroAgendado = 0;
    let ultimoPonteiro = "";

    const painel = document.createElement("div");
    painel.id = "previa-equipes";
    painel.setAttribute("role", "dialog");
    painel.setAttribute("aria-labelledby", "previa-equipes-titulo");
    painel.hidden = true;
    painel.innerHTML = '<div class="pe-cabecalho"><b id="previa-equipes-titulo">Equipes das urnas</b>' +
        '<code></code><button type="button" class="pe-fechar">Fechar</button></div><div class="pe-listas"></div>';
    const numero = painel.querySelector(".pe-cabecalho code");
    const botaoFechar = painel.querySelector(".pe-fechar");
    const listas = painel.querySelector(".pe-listas");
    document.body.append(painel);

    function acionador(no) {
        return no instanceof Element ? no.closest(seletor) : null;
    }

    function dedicado(alvo) {
        return alvo.matches("button.ver-equipe");
    }

    function indicar(alvo, aberto) {
        if (dedicado(alvo)) {
            alvo.setAttribute("aria-haspopup", "dialog");
            alvo.setAttribute("aria-controls", painel.id);
            alvo.setAttribute("aria-expanded", String(aberto));
        }
    }
    document.querySelectorAll("button.ver-equipe[data-equipe-prever]").forEach(alvo => indicar(alvo, false));

    function fechar(devolverFoco = false) {
        window.clearTimeout(fecharDepois);
        const anterior = ativo;
        if (anterior) indicar(anterior, false);
        ativo = null;
        fixo = false;
        painel.hidden = true;
        if (devolverFoco && anterior?.isConnected) {
            devolvendoFoco = true;
            anterior.focus({preventScroll: true});
            devolvendoFoco = false;
        }
    }

    function copiarQuadro(caso) {
        if (caso.html) {
            const molde = document.createElement("template");
            molde.innerHTML = caso.html;
            return molde.content.querySelector(".eq-quadro");
        }
        const origem = document.getElementById((caso.fonte || "").replace(/^#/, ""));
        const quadro = origem?.matches(".eq-quadro") ? origem : origem?.querySelector(".eq-quadro");
        return quadro?.cloneNode(true);
    }

    function filtrarMesa(quadro, filtro) {
        for (const card of quadro.querySelectorAll(".eq-urna")) {
            const u = card.dataset;
            if ((filtro.equipeUf && filtro.equipeUf !== u.uf) ||
                (filtro.equipeMunicipio && filtro.equipeMunicipio !== u.municipio) ||
                (filtro.equipeZona && Number(filtro.equipeZona) !== Number(u.zona)) ||
                (filtro.equipeSecao && Number(filtro.equipeSecao) !== Number(u.secao)) ||
                (filtro.equipeTurno && filtro.equipeTurno !== u.turno)) card.remove();
        }
        for (const grupo of quadro.querySelectorAll(".eq-urnas")) {
            if (grupo.querySelector(".eq-urna")) continue;
            const rotulo = grupo.previousElementSibling;
            if (rotulo?.matches(".eq-periodo")) rotulo.remove();
            grupo.remove();
        }
    }

    function posicionar() {
        if (!ativo) return;
        const alvo = ativo.getBoundingClientRect();
        const largura = document.documentElement.clientWidth;
        const altura = document.documentElement.clientHeight;
        if (!ativo.isConnected || !alvo.width || !alvo.height || alvo.bottom <= 0 || alvo.top >= altura ||
            alvo.right <= 0 || alvo.left >= largura) {
            fechar(painel.contains(document.activeElement));
            return;
        }
        const margem = 8;
        const folga = 4;
        const direita = largura - margem - alvo.right - folga;
        const esquerda = alvo.left - margem - folga;
        const lateral = Math.max(direita, esquerda) >= 790;
        painel.style.width = Math.min(largura - 2 * margem, 900, lateral ? Math.max(esquerda, direita) : largura) + "px";
        const abaixo = altura - margem - alvo.bottom - folga;
        const acima = alvo.top - margem - folga;
        const porBaixo = abaixo >= acima;
        const limite = lateral ? altura - 2 * margem : Math.max(acima, abaixo);
        painel.style.maxHeight = Math.min(altura - 2 * margem, 650, Math.max(125, limite)) + "px";
        const x = lateral ? (direita >= esquerda ? alvo.right + folga : alvo.left - folga - painel.offsetWidth) : alvo.left;
        const y = lateral ? alvo.top - 12 : (porBaixo ? alvo.bottom + folga : alvo.top - folga - painel.offsetHeight);
        painel.style.left = Math.max(margem, Math.min(x, largura - margem - painel.offsetWidth)) + "px";
        painel.style.top = Math.max(margem, Math.min(y, altura - margem - painel.offsetHeight)) + "px";
    }

    function abrir(alvo) {
        window.clearTimeout(fecharDepois);
        if (alvo === ativo) return;
        fechar();
        const caso = casos[alvo.dataset.equipePrever];
        if (!caso) return;
        const quadro = copiarQuadro(caso);
        if (!quadro) return;
        filtrarMesa(quadro, alvo.dataset);
        if (!quadro.querySelector(".eq-urna")) return;
        listas.replaceChildren(quadro);
        numero.textContent = caso.titulo;
        ativo = alvo;
        indicar(alvo, true);
        painel.hidden = false;
        listas.scrollTop = 0;
        posicionar();
    }

    document.addEventListener("pointerover", ev => {
        if (ev.pointerType === "touch") return;
        if (painel.contains(ev.target)) {
            window.clearTimeout(fecharDepois);
            return;
        }
        if (fixo || painel.contains(document.activeElement)) return;
        const alvo = acionador(ev.target);
        if (alvo && !alvo.contains(ev.relatedTarget)) abrir(alvo);
    });
    document.addEventListener("pointerout", ev => {
        if (!ativo || fixo || ev.pointerType === "touch") return;
        if (!ativo.contains(ev.target) && !painel.contains(ev.target)) return;
        if (ativo.contains(ev.relatedTarget) || painel.contains(ev.relatedTarget)) return;
        window.clearTimeout(fecharDepois);
        fecharDepois = window.setTimeout(() => {
            if (ativo && !fixo && !painel.contains(document.activeElement) &&
                !(document.activeElement === ativo && ativo.matches(":focus-visible"))) fechar();
        }, 260);
    });
    document.addEventListener("pointerdown", ev => {
        ultimoPonteiro = ev.pointerType;
        if (ativo && !ativo.contains(ev.target) && !painel.contains(ev.target)) fechar();
    }, true);
    document.addEventListener("focusin", ev => {
        if (devolvendoFoco) return;
        if (painel.contains(ev.target)) {
            window.clearTimeout(fecharDepois);
            return;
        }
        const alvo = acionador(ev.target);
        if (alvo && ultimoPonteiro !== "touch") abrir(alvo);
    });
    document.addEventListener("focusout", ev => {
        if (!ativo || (!ativo.contains(ev.target) && !painel.contains(ev.target))) return;
        if (ativo.contains(ev.relatedTarget) || painel.contains(ev.relatedTarget)) return;
        // Quando um dedo toca a área rolável, relatedTarget pode ser nulo.
        if (ev.relatedTarget || !fixo) fechar();
    });

    botaoFechar.addEventListener("click", () => fechar(true));
    document.addEventListener("click", ev => {
        const alvo = acionador(ev.target);
        if (!alvo || painel.contains(ev.target)) return;
        if (dedicado(alvo)) {
            if (fixo && ativo === alvo) fechar();
            else {
                abrir(alvo);
                fixo = ativo === alvo;
            }
        } else {
            // Os controles de ficha e os summaries continuam com a ação original.
            fechar();
        }
    });

    document.addEventListener("keydown", ev => {
        ultimoPonteiro = "";
        if (!ativo) return;
        if (ev.key === "Escape") {
            ev.preventDefault();
            fechar(painel.contains(document.activeElement));
            return;
        }
        if (ev.key === "Tab") {
            const foco = document.activeElement;
            if (!ev.shiftKey && ativo.contains(foco)) {
                ev.preventDefault();
                fixo = true;
                botaoFechar.focus({preventScroll: true});
            } else if (ev.shiftKey && foco === botaoFechar) {
                ev.preventDefault();
                fechar(true);
            } else if (!ev.shiftKey && painel.contains(foco)) {
                const links = listas.querySelectorAll("a[href]");
                if (foco === (links[links.length - 1] || botaoFechar)) {
                    // A partir da última fonte, Tab segue na página após o acionador.
                    fechar(true);
                }
            }
            return;
        }
        if ((!ativo.contains(document.activeElement) && !painel.contains(document.activeElement)) ||
            ev.ctrlKey || ev.altKey || ev.metaKey || listas.scrollHeight <= listas.clientHeight) return;
        const passo = {ArrowDown: 36, ArrowUp: -36, PageDown: listas.clientHeight * .85,
            PageUp: -listas.clientHeight * .85, Home: -listas.scrollHeight, End: listas.scrollHeight}[ev.key];
        if (passo !== undefined) {
            ev.preventDefault();
            listas.scrollTop += passo;
        }
    });

    function atualizarPosicao(ev) {
        if (!ativo || quadroAgendado || (ev.target instanceof Node && painel.contains(ev.target))) return;
        quadroAgendado = requestAnimationFrame(() => { quadroAgendado = 0; posicionar(); });
    }
    window.addEventListener("scroll", atualizarPosicao, {capture: true, passive: true});
    window.addEventListener("resize", atualizarPosicao);
    window.addEventListener("blur", () => fechar());
})();
