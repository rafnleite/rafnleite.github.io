"""Publica o teste de validade, os resultados por posição e a calculadora por título."""
import base64
import csv
import json
import subprocess
from pathlib import Path
from string import Template


RAIZ = Path(__file__).resolve().parent
DADOS = RAIZ / "dados" / "relatorio"
OPERACOES = {
    "substituicao_1": "Substituir um dígito",
    "substituicao_2": "Substituir dois dígitos",
    "transposicao": "Inverter dois dígitos vizinhos",
    "omissao": "Omitir um dígito e completar com zero à esquerda",
    "insercao": "Inserir um dígito e descartar o último original",
}


def pt(n):
    return f"{n:,}".replace(",", ".")


def percentual(r, condicional=False):
    den = int(r["tentativas"]) - (int(r["inalterado"]) if condicional else 0)
    return (f"{100 * int(r['outro_valido']) / den:.4f}".replace(".", ",") + "%") if den else "—"


def tabela(colunas, linhas):
    topo = "".join(f"<th scope='col'>{c}</th>" for c in colunas)
    corpo = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in linha) + "</tr>" for linha in linhas)
    return f"<div class='scroll'><table><thead><tr>{topo}</tr></thead><tbody>{corpo}</tbody></table></div>"


def ler_csv(nome):
    with (DADOS / nome).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def quadro_resumo(linhas):
    return tabela(["Operação nas 12 posições", "Outro título válido", "Entre as tentativas que mudam o número"],
                  ((OPERACOES[r["operacao"]], f"<strong>{percentual(r)}</strong>", percentual(r, True)) for r in linhas))


def calcular_nos_logs():
    with (RAIZ / "dados" / "todos_casos.csv").open(encoding="utf-8-sig", newline="") as f:
        titulos = sorted({r["titulo"] for r in csv.DictReader(f)})
    processo = subprocess.run(["node", str(RAIZ / "teste_dv_por_titulo.js")], input=json.dumps(titulos),
                              capture_output=True, text=True, check=True)
    resultados = []
    for op, r in zip(OPERACOES, json.loads(processo.stdout), strict=True):
        resultados.append(dict(operacao=op, titulos=len(titulos), **r,
                               invalido=r["tentativas"] - r["outro_valido"] - r["inalterado"]))
    with (DADOS / "teste_dv_titulos_dos_logs.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=resultados[0])
        writer.writeheader()
        writer.writerows(resultados)
    return len(titulos), resultados


def publicar():
    resumo = ler_csv("teste_dv_resumo.csv")
    posicoes = ler_csv("teste_dv_por_posicao.csv")
    n_logs, logs = calcular_nos_logs()
    linhas = []
    por_posicao = []
    for r, l in zip(resumo, logs, strict=True):
        op = r["operacao"]
        if op != l["operacao"]:
            raise ValueError("Ordem das operações divergente nas tabelas.")
        linhas.append((OPERACOES[op], pt(int(r["tentativas"])), pt(int(r["outro_valido"])),
                       pt(int(r["inalterado"])), pt(int(r["invalido"]))))
        detalhe = []
        for p in posicoes:
            if p["operacao"] == op:
                pos = p["posicao_1"] + (" e " + p["posicao_2"] if p["posicao_2"] else "")
                detalhe.append((pos, pt(int(p["tentativas"])), pt(int(p["outro_valido"])),
                                pt(int(p["inalterado"])), percentual(p)))
        corpo = tabela(["Posição (1 a 12)", "Tentativas", "Outro válido", "Mesmo número", "Chance de outro válido"], detalhe)
        por_posicao.append(f"<details><summary>{OPERACOES[op]} · {len(detalhe)} escolhas de posição</summary>{corpo}</details>")
    contagens = tabela(["Operação", "Tentativas", "Outro válido", "Mesmo número", "Inválido"], linhas)
    dados_logs = tabela(["Operação", "Tentativas nos títulos dos logs", "Outro válido nos logs", "Chance nos logs", "Chance no universo uniforme"],
                        [(OPERACOES[l["operacao"]], pt(l["tentativas"]), pt(l["outro_valido"]), percentual(l), percentual(r))
                         for l, r in zip(logs, resumo, strict=True)])
    csvs = {nome: base64.b64encode((DADOS / nome).read_bytes()).decode("ascii") for nome in
            ("teste_dv_resumo.csv", "teste_dv_por_posicao.csv", "teste_dv_titulos_dos_logs.csv")}
    pagina = Template((RAIZ / "modelo_teste_dv.html").read_text(encoding="utf-8")).substitute(
        RESUMO=quadro_resumo(resumo), CONTAGENS=contagens, POSICOES="".join(por_posicao), NLOGS=pt(n_logs),
        LOGS=dados_logs, CALCULO=(RAIZ / "teste_dv_por_titulo.js").read_text(encoding="utf-8"),
        ROTULOS=json.dumps(list(OPERACOES.values()), ensure_ascii=False), CSVS=json.dumps(csvs))
    (RAIZ / "teste_dv.html").write_text(pagina, encoding="utf-8")


if __name__ == "__main__":
    publicar()
