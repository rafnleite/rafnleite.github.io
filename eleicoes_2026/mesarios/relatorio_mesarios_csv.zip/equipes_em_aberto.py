"""Quantidade de títulos com registro de presença nas seções de cada caso.

Executar depois de gerar dados/relatorio/em_aberto.csv, ou chamar
analisar_equipes(chaves) com pares (turno, titulo). Os dois CSVs se ligam por
(turno, titulo). Uma seção-turno pode estar ligada a mais de um caso.
"""
import csv
import json
from collections import Counter, defaultdict
from itertools import groupby

from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify, team_scan


PASTA = BASE / "relatorio"
ABERTURA = "abertura"
ENCERRAMENTO = "encerramento"
DURANTE = "durante a votação"
MENU = "registro pelo menu de votação"
SECAO = ("turno", "uf", "codigo_municipio", "zona", "secao")


def juntar(valores):
    return " | ".join(str(x) for x in valores)


def mesa(s):
    return f"{s['municipio']}/{s['uf']} Z{s['zona']} S{s['secao']}"


def referencia(e):
    return (f"{e['titulo']} {e['data_hora']} {e['etapa']} "
            f"UE {e['urna']} {e['membro']} L{e['linha']} "
            f"(marcador L{e['linha_marcador'] or 'sem marcador'})")


def titulos_das_fichas(pedidas):
    """Localiza a seção em que foi documentado um título alternativo, inclusive no outro turno."""
    candidatos = {}
    for ficha in json.loads((BASE / "evidencia_fichas_digitacao.json").read_text(encoding="utf-8")):
        caso = str(ficha["turno"]), ficha["titulo"]
        if caso not in pedidas:
            continue
        for s in ficha["secoes"]:
            if s["mesa_alternativo"] and str(s["turno"]) == caso[0]:
                candidatos[(*caso, s["uf"], int(s["zona"]), int(s["secao"]))] = ficha["alternativo"]
    return candidatos


def conferir_secoes(chaves):
    fontes = {identify(r): r for r in linhas("manifesto.csv") if identify(r) in chaves}
    enderecos = {identify(r): r for r in linhas("enderecos.csv") if identify(r) in chaves}
    cobertura = {identify(r): r for r in linhas("cobertura_extracao.csv") if identify(r) in chaves}
    if set(fontes) != chaves or set(enderecos) != chaves or set(cobertura) != chaves:
        raise ValueError("Faltam pacotes, hashes ou endereços para as seções solicitadas")
    qualificados = defaultdict(Counter)
    for r in linhas("registros_qualificados.csv"):
        k = identify(r)
        if k in chaves:
            evento = (r["titulo"], r["data_hora"], r["urna"], r["tipo"], r["membro"], int(r["linha"]))
            qualificados[k][evento] += 1
    equipes = defaultdict(Counter)
    for r in linhas("equipes.csv"):
        k = identify(r)
        if k in chaves and int(r["registros"]):
            equipes[k][r["titulo"]] += int(r["registros"])
    secoes = {}
    for k in sorted(chaves):
        fonte = fontes[k]
        sha, _, eventos, _, _ = team_scan({**fonte, "_path": BASE / fonte["arquivo"]})
        if sha != cobertura[k]["sha256"] or Counter(eventos) != qualificados[k]:
            raise ValueError(f"As linhas oficiais reextraídas ou o hash diferem do índice: {k}")
        titulos = {ev[0] for ev in eventos if ev[3] == "registro"}
        s = ler_secao(fonte, enderecos[k], titulos, qualificados[k])
        if Counter(e["titulo"] for e in s["registros"]) != equipes[k] or s["sha256"] != sha:
            raise ValueError(f"A contagem de presenças difere do extrato de equipes: {k}")
        secoes[k] = s
    return secoes


def secao_no_caso(id_caso, titulo, s, alternativo):
    eventos = s["registros"]
    etapas = defaultdict(set)
    ciclos = defaultdict(dict)
    primeiros = {}
    for e in eventos:
        t = e["titulo"]
        etapas[e["etapa"]].add(t)
        primeiros.setdefault(t, e)
        if e["linha_marcador"] and e["etapa"] in (ABERTURA, ENCERRAMENTO, DURANTE, MENU):
            ciclo = (e["etapa"], e["data_hora"][:10], e["urna"], e["membro"], e["linha_marcador"])
            ciclos[ciclo].setdefault(t, None)
    if titulo not in primeiros:
        raise ValueError(f"Título do caso sem presença na seção {mesa(s)}: {titulo}")
    abertura, fecho = etapas[ABERTURA], etapas[ENCERRAMENTO]
    if len(abertura) != s["equipe_abertura"] or len(fecho) != s["equipe_encerramento"]:
        raise ValueError(f"Divergência na atribuição de etapas em {mesa(s)}")
    padrao = ""
    if abertura == fecho | {titulo} and len(fecho) >= 4 and titulo not in fecho:
        padrao = "Único título adicional na abertura; todos os títulos do encerramento também constam na abertura."
    elif fecho == abertura | {titulo} and len(abertura) >= 4 and titulo not in abertura:
        padrao = "Único título adicional no encerramento; todos os títulos da abertura também constam no encerramento."
    eventos_alvo = [e for e in eventos if e["titulo"] == titulo]
    if (not padrao and titulo not in abertura | fecho and len(abertura) >= 4 and abertura == fecho
            and set(primeiros) == abertura | {titulo}):
        padrao = "Único título adicional fora das listas de abertura e encerramento; a mesma equipe consta nas duas listas."
    max_ciclo = max(map(len, ciclos.values()), default=0)
    grande = lambda etapa: max((len(ts) for ciclo, ts in ciclos.items() if ciclo[0] == etapa), default=0)
    posicoes_por_etapa = defaultdict(list)
    for (etapa, *_), titulos in ciclos.items():
        if titulo in titulos:
            posicoes_por_etapa[etapa].append(list(titulos).index(titulo) + 1)
    return dict(id_caso=id_caso, titulo=titulo, turno=str(s["turno"]), uf=s["uf"],
                codigo_municipio=s["codigo_municipio"], municipio=s["municipio"], zona=s["zona"],
                secao=s["secao"], local=s["local"], nome=s["nome"], endereco=s["endereco"],
                linhas_positivas=len(eventos), titulos_no_turno=len(primeiros),
                posicao_do_primeiro_registro_do_repetido_no_turno=list(primeiros).index(titulo) + 1,
                maior_posicao_do_repetido_em_uma_abertura=max(posicoes_por_etapa[ABERTURA], default=0),
                maior_posicao_do_repetido_em_um_encerramento=max(posicoes_por_etapa[ENCERRAMENTO], default=0),
                mais_de_4_no_turno=int(len(primeiros) > 4), titulos_na_abertura=len(abertura),
                titulos_no_encerramento=len(fecho), titulos_no_marcador_durante=len(etapas[DURANTE]),
                titulos_no_marcador_menu=len(etapas[MENU]), maximo_no_mesmo_ciclo=max_ciclo,
                maximo_em_um_ciclo_de_abertura=grande(ABERTURA),
                maximo_em_um_ciclo_de_encerramento=grande(ENCERRAMENTO),
                titulo_alternativo_da_ficha_nesta_secao=alternativo,
                registros_do_alternativo_neste_turno=sum(e["titulo"]==alternativo for e in eventos) if alternativo else "",
                padrao_do_titulo_repetido=padrao, etapas_do_titulo=juntar(dict.fromkeys(e["etapa"] for e in eventos_alvo)),
                presencas_do_titulo=len(eventos_alvo), linhas_do_titulo=juntar(map(referencia, eventos_alvo)),
                quinto_titulo_do_dia=referencia(list(primeiros.values())[4]) if len(primeiros)>4 else "",
                titulos_distintos_no_turno=juntar(sorted(primeiros)),
                lista_da_abertura=juntar(sorted(abertura)), lista_do_encerramento=juntar(sorted(fecho)),
                presencas_com_etapa_e_linha=juntar(map(referencia, eventos)),
                arquivo=s["arquivo"], sha256=s["sha256"], url_log=s["url_log"])


def casos_por_secao(secoes):
    def por_caso(s):
        return s["turno"], s["titulo"]
    casos = []
    for (turno, titulo), grupo in groupby(sorted(secoes, key=por_caso), key=por_caso):
        ss = list(grupo)
        grandes = [s for s in ss if s["mais_de_4_no_turno"]]
        apos_quatro = [s for s in ss if s["posicao_do_primeiro_registro_do_repetido_no_turno"] > 4]
        casos.append(dict(turno=turno, titulo=titulo, id_caso=ss[0]["id_caso"], numero_secoes=len(ss),
                          numero_secoes_mais_de_4=len(grandes), alguma_secao_mais_de_4=int(bool(grandes)),
                          maximo_no_turno=max(s["titulos_no_turno"] for s in ss),
                          secoes_com_repetido_apos_quatro_no_turno=len(apos_quatro),
                          secoes_e_posicoes_do_repetido_apos_quatro=juntar(
                              f"{mesa(s)} ({s['posicao_do_primeiro_registro_do_repetido_no_turno']}º título distinto)"
                              for s in apos_quatro),
                          secoes_com_repetido_apos_quatro_na_abertura=sum(s["maior_posicao_do_repetido_em_uma_abertura"] > 4 for s in ss),
                          secoes_com_repetido_apos_quatro_no_encerramento=sum(s["maior_posicao_do_repetido_em_um_encerramento"] > 4 for s in ss),
                          secoes_mais_de_4=juntar(f"{mesa(s)} ({s['titulos_no_turno']})" for s in grandes),
                          secoes_mais_de_4_em_um_ciclo=sum(s["maximo_no_mesmo_ciclo"]>4 for s in ss),
                          secoes_mais_de_4_em_uma_abertura=sum(s["maximo_em_um_ciclo_de_abertura"]>4 for s in ss),
                          secoes_mais_de_4_em_um_encerramento=sum(s["maximo_em_um_ciclo_de_encerramento"]>4 for s in ss),
                          secoes_com_titulo_como_unico_adicional=juntar(
                              f"{mesa(s)}: {s['padrao_do_titulo_repetido']}" for s in grandes if s["padrao_do_titulo_repetido"]),
                          secoes_com_alternativo_na_ficha=juntar(
                              f"{mesa(s)} ({s['titulos_no_turno']} títulos; alternativo {s['titulo_alternativo_da_ficha_nesta_secao']})"
                              for s in ss if s["titulo_alternativo_da_ficha_nesta_secao"]),
                          todas_as_secoes=juntar(f"{mesa(s)} ({s['titulos_no_turno']})" for s in ss),
                          links_dos_logs=juntar(s["url_log"] for s in ss)))
    return casos


def analisar_equipes(chaves, gravar=True):
    """Cada caso conta uma vez, ainda que várias de suas seções superem quatro."""
    pedidas = {(str(int(turno)), titulo) for turno, titulo in chaves}
    associacoes = defaultdict(dict)
    for r in linhas("secoes_por_caso.csv"):
        caso = r["turno"], r["titulo"]
        if caso in pedidas:
            k = identify(r)
            if k in associacoes[caso]:
                raise ValueError(f"Seção duplicada no caso {caso}: {k}")
            associacoes[caso][k] = r
    if set(associacoes) != pedidas or any(len(ss)<2 for ss in associacoes.values()):
        raise ValueError("Há casos solicitados com menos de duas seções positivas")
    originais = conferir_secoes({k for ss in associacoes.values() for k in ss})
    candidatos = titulos_das_fichas(pedidas)
    secoes = []
    for (_, titulo), ss in sorted(associacoes.items()):
        for k, r in sorted(ss.items()):
            alternativo = candidatos.get((r["turno"], titulo, r["uf"], int(r["zona"]), int(r["secao"])), "")
            s = secao_no_caso(r["id_caso"], titulo, originais[k], alternativo)
            if s["presencas_do_titulo"] != int(r["registros"]):
                raise ValueError(f"Presenças diferentes do índice do caso: {titulo} {k}")
            secoes.append(s)
    casos = casos_por_secao(secoes)
    if gravar:
        for nome, dados in (("casos", casos), ("secoes", secoes)):
            with (PASTA / f"equipes_em_aberto_{nome}.csv").open("w", encoding="utf-8-sig", newline="") as f:
                if dados:
                    writer = csv.DictWriter(f, fieldnames=list(dados[0]))
                    writer.writeheader()
                    writer.writerows(dados)
    return casos, secoes


def resumo_equipes(casos, secoes):
    """Números gerais e por turno; deduplica as seções compartilhadas entre casos."""
    resumo = {}
    for turno in ("total", "1", "2"):
        cs = [c for c in casos if turno=="total" or c["turno"]==turno]
        ss = {tuple(s[k] for k in SECAO): s for s in secoes if turno=="total" or s["turno"]==turno}
        resumo[turno] = dict(casos=len(cs), casos_mais_de_4=sum(c["alguma_secao_mais_de_4"] for c in cs),
                             casos_com_repetido_apos_quatro_no_turno=sum(c["secoes_com_repetido_apos_quatro_no_turno"] > 0 for c in cs),
                             casos_com_repetido_apos_quatro_na_abertura=sum(c["secoes_com_repetido_apos_quatro_na_abertura"] > 0 for c in cs),
                             casos_com_repetido_apos_quatro_no_encerramento=sum(c["secoes_com_repetido_apos_quatro_no_encerramento"] > 0 for c in cs),
                             casos_mais_de_4_em_um_ciclo=sum(c["secoes_mais_de_4_em_um_ciclo"]>0 for c in cs),
                             casos_mais_de_4_na_abertura=sum(c["secoes_mais_de_4_em_uma_abertura"]>0 for c in cs),
                             casos_mais_de_4_no_encerramento=sum(c["secoes_mais_de_4_em_um_encerramento"]>0 for c in cs),
                             casos_com_titulo_como_unico_adicional=sum(bool(c["secoes_com_titulo_como_unico_adicional"]) for c in cs),
                             secoes_distintas=len(ss), secoes_distintas_mais_de_4=sum(s["mais_de_4_no_turno"] for s in ss.values()),
                             vinculos_caso_secao=sum(c["numero_secoes"] for c in cs),
                             vinculos_caso_secao_mais_de_4=sum(c["numero_secoes_mais_de_4"] for c in cs))
    return resumo


if __name__ == "__main__":
    registros = linhas("relatorio/em_aberto.csv")
    resultado = analisar_equipes((r["turno"], r["titulo"]) for r in registros)
    print(json.dumps(resumo_equipes(*resultado), ensure_ascii=False, indent=2))
