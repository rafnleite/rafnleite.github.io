"""Compara, em cada mesa, o número repetido aos demais números registrados.

Executar após fontes.py e extrair.py. Os CSVs locais conservam os 12 dígitos.
"""
import argparse
import csv
import hashlib
import io
import json
import re
from collections import Counter, defaultdict
from contextlib import ExitStack, contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


DADOS = Path(__file__).resolve().parent / "dados"
TITULO = re.compile(r"[0-9]{12}")
GEO = ("uf", "codigo_municipio", "municipio", "zona", "secao", "local", "nome")
ID = ("id_caso", "ids_arvor_possiveis", "turno", "titulo")
CASO = ID + ("classe", "secoes", "locais", "resultado", "candidatos_turno",
             "candidatos_so_outro_turno", "omissoes_turno", "omissoes_so_outro_turno",
             "secoes_com_outro_turno", "secoes_com_candidato_turno",
             "secoes_com_candidato_outro_turno", "suplementares_turno", "suplementares_so_outro_turno",
             "candidatos_com_contraste", "omissoes_com_contraste")
SECAO = ID + GEO + ("registros", "primeiro", "ultimo", "habilitacoes", "outro_turno_disponivel",
                   "repetido_tambem_no_outro_turno", "comparados_turno", "comparados_outro_turno",
                   "candidatos_turno", "candidatos_outro_turno",
                   "melhor_distancia_turno", "melhor_distancia_outro_turno")
COMPARACAO = ID + GEO + ("turno_fonte", "titulo_alternativo", "registros_alternativo",
                        "primeiro_alternativo", "ultimo_alternativo", "habilitacoes_alternativo",
                        "operacoes", "detalhe", "posicoes_omissao", "distancia_levenshtein",
                        "empata_menor_distancia", "alternativo_nos_dois_turnos",
                        "repetido_em_outra_ponta_no_outro_turno", "contraste_entre_turnos")
SUPLEMENTAR = ID + GEO + ("turno_fonte", "titulo_alternativo", "eventos", "primeiro",
                         "ultimo", "tipos", "membro", "linha", "operacoes", "detalhe", "posicoes_omissao",
                         "distancia_levenshtein", "empata_menor_distancia")
TODOS = ID + ("classe", "secoes", "locais", "vinculo_arvor", "referencias_secoes",
             "referencias_locais")
EXTRAS = ("id_local", "turno", "titulo", "classe", "referencias_secoes",
          "ids_publicados_nas_mesmas_secoes", "secao_do_contraste", "municipio",
          "titulos_dia_publicados", "titulos_abertura_publicados", "titulos_fechamento_publicados",
          "etapa_dos_registros", "eventos_da_secao", "urna", "membro", "linhas",
          "instantes", "arquivo", "sha256", "url_log")


def ler_csv(arquivo):
    with arquivo.open(encoding="utf-8-sig", newline="") as entrada:
        yield from csv.DictReader(entrada)


def saida(pasta, nome, campos, pilha):
    arquivo = pilha.enter_context((pasta / nome).open("w", encoding="utf-8-sig", newline=""))
    escritor = csv.DictWriter(arquivo, fieldnames=campos, extrasaction="ignore")
    escritor.writeheader()
    return escritor


@contextmanager
def saidas_temporarias(destino):
    """Conserva o resultado da execução anterior se a nova leitura falhar."""
    with TemporaryDirectory(prefix=".comparacao-", dir=destino) as nome:
        pasta = Path(nome)
        with ExitStack() as arquivos:
            yield pasta, arquivos
        for arquivo in pasta.iterdir():
            arquivo.replace(destino / arquivo.name)


def secao(linha):
    return (int(linha["turno"]), linha["uf"].upper(), int(linha["codigo_municipio"]),
            int(linha["zona"]), int(linha["secao"]))


def rotulo_secao(chave):
    _, uf, mun, zona, s = chave
    return f"{uf}/{mun:05}/Z{zona:04}/S{s:04}"


def id_local(numero):
    return "L-" + hashlib.sha256(numero.encode("ascii")).hexdigest()[:16].upper()


def valor(texto):
    return texto.lstrip("0") or "0"


def levenshtein(esquerda, direita):
    """Inserção, remoção e substituição custam um; zeros de preenchimento são ignorados."""
    anterior = list(range(len(direita) + 1))
    for i, x in enumerate(esquerda, 1):
        atual = [i]
        for j, y in enumerate(direita, 1):
            atual.append(min(atual[-1] + 1, anterior[j] + 1, anterior[j - 1] + (x != y)))
        anterior = atual
    return anterior[-1]


def posicoes_omitidas(origem, destino):
    return [i + 1 for i in range(len(origem)) if
            valor(origem[:i] + origem[i + 1:]) == valor(destino)]


def comparar(alternativo, repetido):
    """As operações sempre transformam o candidato no número efetivamente repetido."""
    if not TITULO.fullmatch(alternativo) or not TITULO.fullmatch(repetido) or alternativo == repetido:
        raise ValueError("A comparação requer dois títulos distintos de 12 dígitos.")
    operacoes, detalhes = [], []
    omitidas = posicoes_omitidas(alternativo, repetido)
    if omitidas:
        operacoes.append("omissao")
        detalhes.append("Excluir do alternativo " + " ou ".join(
            f"o {alternativo[i-1]} da posição {i}" for i in omitidas) + " e completar à esquerda.")
    inseridas = posicoes_omitidas(repetido, alternativo)
    if inseridas:
        operacoes.append("insercao")
        detalhes.append("O repetido contém um dígito adicional. Excluindo dele " + " ou ".join(
            f"o {repetido[i-1]} da posição {i}" for i in inseridas) + ", obtém-se o alternativo.")
    dif = [i for i in range(12) if alternativo[i] != repetido[i]]
    if len(dif) == 1:
        i = dif[0]
        operacoes.append("substituicao")
        detalhes.append(f"Trocar {alternativo[i]} por {repetido[i]} na posição {i+1}.")
    if len(dif) == 2:
        i, j = dif
        if alternativo[i] == repetido[j] and alternativo[j] == repetido[i]:
            operacoes.append("troca_adjacente" if j == i + 1 else "troca_nao_adjacente")
            detalhes.append(f"Trocar entre si as posições {i+1} e {j+1}.")
    return {
        "operacoes": " ".join(operacoes),
        "detalhe": " ".join(detalhes),
        "posicoes_omissao": " ".join(map(str, omitidas)),
        "distancia_levenshtein": levenshtein(valor(alternativo), valor(repetido)),
    }


def local_cadastrado(chave, locais):
    local = locais[chave]["local"]
    if not local or not local.isdigit():
        raise ValueError(f"Código de local ausente ou inválido em {chave!r}.")
    return chave[1:4] + (int(local),)


def classificar(secoes, locais):
    chaves = {local_cadastrado(k, locais) for k in secoes}
    if len({k[0] for k in chaves}) > 1:
        return "UFs distintas", len(chaves)
    if len({k[:2] for k in chaves}) > 1:
        return "Municípios distintos na mesma UF", len(chaves)
    if len(chaves) > 1:
        return "Locais distintos do mesmo município", len(chaves)
    return "Mesmo local cadastrado", 1


def carregar_equipes(arquivo):
    equipes = defaultdict(dict)
    incidencias = defaultdict(set)
    for r in ler_csv(arquivo):
        chave = secao(r)
        numero = r["titulo"]
        if not TITULO.fullmatch(numero) or numero in equipes[chave]:
            raise ValueError(f"Cadastro repetido ou título fora do formato em {chave!r}.")
        if int(r["registros"]) <= 0:
            raise ValueError(f"Título sem registro positivo em {chave!r}.")
        equipes[chave][numero] = r
        incidencias[chave[0], numero].add(chave)
    return equipes, incidencias


def carregar_suplementares(arquivo, equipes):
    adicionais = defaultdict(dict)
    for r in ler_csv(arquivo):
        chave = secao(r)
        numero = r["titulo"]
        if not TITULO.fullmatch(numero):
            raise ValueError(f"Alternativo fora do formato em {chave!r}.")
        if numero in equipes.get(chave, {}):
            continue
        if numero in adicionais[chave]:
            raise ValueError(f"Alternativo suplementar listado duas vezes em {chave!r}.")
        adicionais[chave][numero] = r
    return adicionais


def reconciliar_contingencias(pasta, equipes, incidencias, cobertura, por_id, locais):
    """Um excesso só é individualizado se o estágio do registro o excluir da equipe publicada."""
    grupos = defaultdict(set)
    for (turno, numero), secoes in incidencias.items():
        if len(secoes) > 1:
            grupos[tuple(sorted(secoes))].add(numero)
    ids_publicados = defaultdict(set)
    for (_, ident), chaves in por_id.items():
        observaveis = tuple(sorted(chaves & cobertura))
        if len(observaveis) > 1:
            ids_publicados[observaveis].add(ident)
    divergentes = {k: ns for k, ns in grupos.items() if len(ns) > len(ids_publicados[k])}
    if not divergentes:
        return {}, []
    necessarias = {k for ks in divergentes for k in ks}
    por_etapa = {}
    with ZipFile(pasta / "arvor.zip") as z, z.open("pares_de_secoes.csv") as arquivo:
        for r in csv.DictReader(io.TextIOWrapper(arquivo, encoding="utf-8-sig")):
            for lado in ("a", "b"):
                k = (int(r["turno"]), r["uf_" + lado].upper(), int(r["mun_" + lado]),
                     int(r["zona_" + lado]), int(r["secao_" + lado]))
                if k in necessarias:
                    contagens = tuple(int(r[c + "_" + lado]) for c in ("total", "abertura", "fechamento"))
                    if por_etapa.setdefault(k, contagens) != contagens:
                        raise ValueError(f"Contagens por etapa contraditórias em {k!r}.")
    registros = defaultdict(list)
    for r in ler_csv(pasta / "contexto_contingencias.csv"):
        k = secao(r)
        if k in necessarias and r["tipo"] == "registro":
            registros[k, r["titulo"]].append(r)
    resultados, pendentes = {}, []
    for secoes, numeros in divergentes.items():
        identificados = {}
        for numero in numeros:
            for k in secoes:
                total, abertura, fechamento = por_etapa.get(k, (0, 0, 0))
                eventos = registros.get((k, numero), [])
                if not eventos or len(eventos) != int(equipes[k][numero]["registros"]):
                    continue
                etapas = {r["etapa"] for r in eventos}
                if total == abertura > 0 and fechamento == 0 and etapas <= {"durante", "fechamento"}:
                    classe = (classificar(secoes, locais)[0] if all(locais[s]["local"] for s in secoes)
                              else "Código de local incompleto no cadastro usado")
                    identificados[numero] = dict(
                        id_local=id_local(numero), turno=k[0], titulo=numero, classe=classe,
                        referencias_secoes=" | ".join(map(rotulo_secao, secoes)),
                        ids_publicados_nas_mesmas_secoes=" ".join(sorted(ids_publicados[secoes])),
                        secao_do_contraste=rotulo_secao(k), municipio=locais[k]["municipio"],
                        titulos_dia_publicados=total, titulos_abertura_publicados=abertura,
                        titulos_fechamento_publicados=fechamento, etapa_dos_registros=" | ".join(sorted(etapas)),
                        eventos_da_secao=len(eventos), urna=" | ".join(sorted({r["urna"] for r in eventos})),
                        membro=" | ".join(sorted({r["membro"] for r in eventos})),
                        linhas=" | ".join(r["linha"] for r in eventos),
                        instantes=" | ".join(r["data_hora"] for r in eventos),
                        **{c: locais[k][c] for c in ("arquivo", "sha256", "url_log")})
                    break
        if len(identificados) == len(numeros) - len(ids_publicados[secoes]):
            resultados.update({(secoes[0][0], n): v for n, v in identificados.items()})
        else:
            pendentes.append(dict(secoes=[rotulo_secao(s) for s in secoes],
                                  turno=secoes[0][0], observados=len(numeros),
                                  publicados=len(ids_publicados[secoes]), por_etapa=len(identificados)))
    return resultados, pendentes


def vincular_ids(equipes, incidencias, referencias, cobertura):
    # As assinaturas usam os dois turnos. Apenas seções efetivamente auditadas e com
    # referência publicada podem dirimir um vínculo entre o ID e os 12 dígitos.
    publicadas = defaultdict(list)
    secoes_referenciadas = set()
    for r in ler_csv(referencias):
        chave = secao(r)
        if chave in cobertura:
            secoes_referenciadas.add(chave)
            publicadas[r["id"]].append((chave, int(r["registros"]), int(r["habilitacoes"])))
    ids_por_assinatura = defaultdict(list)
    ids_por_secoes = defaultdict(list)
    for nome, assinatura in publicadas.items():
        ids_por_assinatura[tuple(sorted(assinatura))].append(nome)
        ids_por_secoes[tuple(sorted(k for k, _, _ in assinatura))].append(nome)
    numeros = {n for (_, n), secoes in incidencias.items() if len(secoes) > 1}
    numeros_por_assinatura = defaultdict(list)
    numeros_por_secoes = defaultdict(list)
    for numero in numeros:
        assinatura = []
        for turno in (1, 2):
            for chave in incidencias.get((turno, numero), set()) & secoes_referenciadas:
                r = equipes[chave][numero]
                assinatura.append((chave, int(r["registros"]), int(r["habilitacoes"])))
        numeros_por_assinatura[tuple(sorted(assinatura))].append(numero)
        numeros_por_secoes[tuple(sorted(k for k, _, _ in assinatura))].append(numero)
    vinculos = {}
    for assinatura, grupo in numeros_por_assinatura.items():
        ids = sorted(ids_por_assinatura.get(assinatura, []))
        secoes = tuple(k for k, _, _ in assinatura)
        por_secoes = sorted(ids_por_secoes.get(secoes, []))
        for numero in grupo:
            if len(ids) == len(grupo) == 1:
                vinculos[numero] = (ids[0], ids, "único na assinatura")
            elif len(por_secoes) == len(numeros_por_secoes[secoes]) == 1:
                vinculos[numero] = (por_secoes[0], por_secoes, "único pelas seções; contagens divergentes")
            else:
                local_id = id_local(numero)
                if ids and len(grupo) == len(ids):
                    vinculos[numero] = (local_id, ids, "ambíguo")
                else:
                    vinculos[numero] = (local_id, por_secoes, "ambíguo pelas seções; contagens divergentes"
                                        if por_secoes else "sem assinatura correspondente")
    if len({v[0] for v in vinculos.values()}) != len(vinculos):
        raise ValueError("Colisão de identificadores locais.")
    return vinculos


def comparar_secao(base, chave, equipes, cobertura, numero):
    repetido = equipes[chave][numero]
    outra = (3 - chave[0], *chave[1:])
    detalhe = {**base, "outro_turno_disponivel": int(outra in cobertura), **repetido,
               "repetido_tambem_no_outro_turno": int(numero in equipes.get(outra, {}))
               if outra in cobertura else ""}
    resultados = []
    candidatos, omissoes = [set(), set()], [set(), set()]
    for idx, (grupo, fonte) in enumerate((("turno", chave), ("outro_turno", outra))):
        linhas = []
        for alternativo, registro in sorted(equipes.get(fonte, {}).items()):
            if alternativo == numero:
                continue
            dif = comparar(alternativo, numero)
            if dif["operacoes"]:
                candidatos[idx].add(alternativo)
            if dif["posicoes_omissao"]:
                omissoes[idx].add(alternativo)
            linhas.append({
                **base, **dif, "turno_fonte": fonte[0], "titulo_alternativo": alternativo,
                **{k + "_alternativo": registro[k] for k in ("registros", "primeiro", "ultimo", "habilitacoes")},
            })
        menor = min((r["distancia_levenshtein"] for r in linhas), default=None)
        detalhe["comparados_" + grupo] = len(linhas) if fonte in cobertura else ""
        detalhe["candidatos_" + grupo] = len(candidatos[idx]) if fonte in cobertura else ""
        detalhe["melhor_distancia_" + grupo] = menor
        for r in linhas:
            r["empata_menor_distancia"] = int(r["distancia_levenshtein"] == menor)
        resultados.extend(linhas)
    return detalhe, resultados, candidatos, omissoes


def comparar_suplementares(base, chave, adicionais, numero, escritor):
    candidatos = [set(), set()]
    for i, fonte in enumerate((chave, (3 - chave[0], *chave[1:]))):
        linhas = []
        for alternativo, registro in sorted(adicionais.get(fonte, {}).items()):
            if alternativo == numero:
                continue
            dif = comparar(alternativo, numero)
            if dif["operacoes"]:
                candidatos[i].add(alternativo)
            linhas.append({
                **base, **dif, "turno_fonte": fonte[0], "titulo_alternativo": alternativo,
                **{k: registro[k] for k in ("eventos", "primeiro", "ultimo", "tipos", "membro", "linha")},
            })
        minimo = min((r["distancia_levenshtein"] for r in linhas), default=None)
        for linha in linhas:
            linha["empata_menor_distancia"] = int(linha["distancia_levenshtein"] == minimo)
        escritor.writerows(linhas)
    return candidatos


def escrever_ficha(caso, chaves, locais, equipes, cobertura, adicionais, incidencias,
                   secoes, comparacoes, suplementares):
    turno, numero = int(caso["turno"]), caso["titulo"]
    base = {k: caso[k] for k in ID}
    total_comparados = total_suplementares = 0
    fontes_com_eq = 0
    com_cand = [0, 0]
    cands, oms = [set(), set()], [set(), set()]
    sups = [set(), set()]
    reforcados, om_reforcadas = set(), set()
    for chave in sorted(chaves):
        geo = {k: locais[chave][k] for k in GEO}
        detalhe, linhas, candidatos, omissoes = comparar_secao({**base, **geo}, chave, equipes, cobertura, numero)
        adicionais_proximos = comparar_suplementares({**base, **geo}, chave, adicionais, numero, suplementares)
        secoes.writerow(detalhe)
        outra = (3 - turno, *chave[1:])
        local = local_cadastrado(chave, locais)
        outras_pontas = {(3-turno, *k[1:]) for k in chaves if local_cadastrado(k, locais) != local}
        presente_em_outra = bool(outras_pontas & incidencias.get((3-turno, numero), set()))
        for r in linhas:
            n = r["titulo_alternativo"]
            dois_turnos = n in equipes.get(outra, {}) and n in equipes[chave]
            r["alternativo_nos_dois_turnos"] = int(dois_turnos) if outra in cobertura else ""
            r["repetido_em_outra_ponta_no_outro_turno"] = (
                int(presente_em_outra) if presente_em_outra or outras_pontas <= cobertura else "")
            contraste = (r["operacoes"] and dois_turnos and presente_em_outra
                         and numero not in equipes.get(outra, {}))
            r["contraste_entre_turnos"] = int(bool(contraste)) if outra in cobertura else ""
            if contraste:
                reforcados.add(n)
                if r["posicoes_omissao"]:
                    om_reforcadas.add(n)
        comparacoes.writerows(linhas)
        total_comparados += len(linhas)
        for fonte in (chave, outra):
            total_suplementares += len(adicionais.get(fonte, {}).keys() - {numero})
        fontes_com_eq += detalhe["outro_turno_disponivel"]
        for i in (0, 1):
            cands[i].update(candidatos[i])
            oms[i].update(omissoes[i])
            sups[i].update(adicionais_proximos[i])
            com_cand[i] += bool(candidatos[i])
    if oms[0]:
        resultado = "Omissão compatível no mesmo turno"
    elif cands[0]:
        resultado = "Outra operação compatível no mesmo turno"
    elif oms[1]:
        resultado = "Omissão compatível somente no outro turno"
    elif cands[1]:
        resultado = "Outra operação compatível somente no outro turno"
    else:
        resultado = "Nenhuma das operações testadas encontrou candidato"
    ficha = {
        **caso, "resultado": resultado, "secoes_com_outro_turno": fontes_com_eq,
        "candidatos_turno": len(cands[0]), "candidatos_so_outro_turno": len(cands[1] - cands[0]),
        "omissoes_turno": len(oms[0]), "omissoes_so_outro_turno": len(oms[1] - oms[0]),
        "secoes_com_candidato_turno": com_cand[0], "secoes_com_candidato_outro_turno": com_cand[1],
        "suplementares_turno": len(sups[0]), "suplementares_so_outro_turno": len(sups[1] - sups[0]),
        "candidatos_com_contraste": len(reforcados), "omissoes_com_contraste": len(om_reforcadas),
    }
    return ficha, total_comparados, total_suplementares


def gerar(pasta):
    locais = {secao(r): r for r in ler_csv(pasta / "manifesto.csv")}
    equipes, incidencias = carregar_equipes(pasta / "equipes.csv")
    adicionais = carregar_suplementares(pasta / "titulos_suplementares.csv", equipes)
    cobertura = {secao(r) for r in ler_csv(pasta / "cobertura_extracao.csv")}
    if not set(equipes) <= cobertura:
        raise ValueError("O cadastro de equipes contém seções ausentes da cobertura da extração.")
    totais = Counter()
    assinaturas_observadas = Counter()
    assinaturas_esperadas = Counter()
    por_id = defaultdict(set)
    for r in ler_csv(pasta / "vinculos.csv"):
        k = secao(r)
        por_id[k[0], r["id"]].add(k)
    extras, pendencias = reconciliar_contingencias(pasta, equipes, incidencias, cobertura, por_id, locais)
    principais = {k: {s for s in chaves if rotulo_secao(s) != extras[k]["secao_do_contraste"]}
                  if k in extras else chaves for k, chaves in incidencias.items()}
    vinculos = vincular_ids(equipes, principais, pasta / "vinculos.csv", cobertura)
    for chaves in por_id.values():
        if len(chaves) > 1:
            assinaturas_esperadas[tuple(sorted(chaves))] += 1
    classes_resultado = Counter()
    atribuicoes = Counter(v[2] for v in vinculos.values())
    total_comparados = total_suplementares = 0
    with saidas_temporarias(pasta) as (temporaria, pilha):
        todos = saida(temporaria, "todos_casos.csv", TODOS, pilha)
        casos = saida(temporaria, "comparacao_casos.csv", CASO, pilha)
        secoes = saida(temporaria, "comparacao_secoes.csv", SECAO, pilha)
        comparacoes = saida(temporaria, "comparacao_titulos.csv", COMPARACAO, pilha)
        suplementares = saida(temporaria, "comparacao_suplementar.csv", SUPLEMENTAR, pilha)
        adicionais_writer = saida(temporaria, "repeticoes_adicionais.csv", EXTRAS, pilha)
        adicionais_writer.writerows(extras[k] for k in sorted(extras))
        for (turno, numero), chaves in sorted(principais.items()):
            if len(chaves) < 2:
                continue
            assinaturas_observadas[tuple(sorted(chaves))] += 1
            classe, n_locais = classificar(chaves, locais)
            id_caso, possiveis, vinculo = vinculos[numero]
            base = dict(id_caso=id_caso, turno=turno, titulo=numero, ids_arvor_possiveis=" ".join(possiveis))
            caso = dict(**base, classe=classe, secoes=len(chaves), locais=n_locais)
            resumo_secoes = " | ".join(map(rotulo_secao, sorted(chaves)))
            chaves_locais = sorted({local_cadastrado(chave, locais) for chave in chaves})
            resumo_locais = " | ".join(
                f"{uf}/{mun:05}/Z{z:04}/L{local}" for uf, mun, z, local in chaves_locais)
            todos.writerow({**caso, "vinculo_arvor": vinculo, "referencias_secoes": resumo_secoes,
                            "referencias_locais": resumo_locais})
            totais[turno, classe] += 1
            if n_locais == 1:
                continue
            ficha, n_titulos, n_adicionais = escrever_ficha(caso, chaves, locais, equipes, cobertura,
                adicionais, incidencias, secoes, comparacoes, suplementares)
            casos.writerow(ficha)
            classes_resultado[ficha["resultado"]] += 1
            total_comparados += n_titulos
            total_suplementares += n_adicionais
    faltas = assinaturas_esperadas - assinaturas_observadas
    excedentes = assinaturas_observadas - assinaturas_esperadas
    controle = dict(
        pacotes_manifesto=len(locais), pacotes_lidos=len(cobertura),
        grupos_identificador_turno_esperados=sum(assinaturas_esperadas.values()),
        grupos_identificador_turno_observados=sum(assinaturas_observadas.values()),
        grupos_adicionais_verificados=len(extras),
        titulos_distintos_na_leitura_ampliada=len({n for (t, n), s in incidencias.items() if len(s) > 1}),
        conciliacoes_pendentes=pendencias,
        grupos_faltantes_por_conjunto_de_secoes=sum(faltas.values()),
        grupos_excedentes_por_conjunto_de_secoes=sum(excedentes.values()),
        vinculos_de_titulos_distintos_com_ids_publicos=atribuicoes,
        comparacoes_com_registro_positivo=total_comparados, comparacoes_suplementares=total_suplementares,
        casos_entre_locais_por_resultado=classes_resultado)
    (pasta / "controle_comparacao.json").write_text(
        json.dumps(controle, ensure_ascii=False, indent=2), encoding="utf-8")
    for (turno, classe), n in sorted(totais.items()):
        print(f"{turno}º turno | {classe} | {n}")
    if faltas or excedentes:
        print(f"Conjuntos de seções com divergências: {sum(faltas.values())} grupos faltantes e "
              f"{sum(excedentes.values())} excedentes em relação à Arvor.")


def gerar_revisao(pasta):
    """Examina casos do mesmo local que passam a locais distintos no cadastro posterior."""
    cadastro = {secao(r): r for r in ler_csv(pasta / "enderecos.csv")}
    rotulos = {(k[0], rotulo_secao(k)): k for k in cadastro}
    novos = []
    for caso in ler_csv(pasta / "todos_casos.csv"):
        if int(caso["locais"]) != 1:
            continue
        turno = int(caso["turno"])
        chaves = {rotulos[turno, chave] for chave in caso["referencias_secoes"].split(" | ")}
        classe, n_locais = classificar(chaves, cadastro)
        if n_locais > 1:
            novos.append(({**caso, "turno": turno, "classe": classe, "locais": n_locais}, chaves))

    revisao = pasta / "revisao_extracao"
    manifesto = {secao(r): r for r in ler_csv(pasta / "revisao_manifesto.csv")}
    locais = {k: {**r, **cadastro.get(k, {})} for k, r in manifesto.items()}
    equipes, incidencias = carregar_equipes(revisao / "equipes.csv")
    adicionais = carregar_suplementares(revisao / "titulos_suplementares.csv", equipes)
    cobertura = {secao(r) for r in ler_csv(revisao / "cobertura_extracao.csv")}
    esperadas = {(turno, *k[1:]) for _, grupo in novos for k in grupo for turno in (1, 2)}
    if not esperadas <= cobertura or not esperadas <= locais.keys():
        raise ValueError("Faltam pacotes ou cadastro de um dos turnos da revisão.")
    if any(int(manifesto[k]["prioridade"]) > 1 for k in esperadas):
        raise ValueError("A revisão requer a busca ampliada nas duas eleições.")
    with saidas_temporarias(pasta) as (temporaria, pilha):
        casos = saida(temporaria, "revisao_comparacao_casos.csv", CASO, pilha)
        secoes = saida(temporaria, "revisao_comparacao_secoes.csv", SECAO, pilha)
        comparacoes = saida(temporaria, "revisao_comparacao_titulos.csv", COMPARACAO, pilha)
        suplementares = saida(temporaria, "revisao_comparacao_suplementar.csv", SUPLEMENTAR, pilha)
        for caso, chaves in novos:
            if not chaves <= incidencias.get((caso["turno"], caso["titulo"]), set()):
                raise ValueError("O extrator não confirmou o título em todas as seções da revisão.")
            ficha, _, _ = escrever_ficha(caso, chaves, locais, equipes, cobertura, adicionais,
                                        incidencias, secoes, comparacoes, suplementares)
            casos.writerow(ficha)
    print(f"{len(novos)} caso(s) adicional(is) entre locais na edição de 25 de outubro.")


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--dados", type=Path, default=DADOS)
    cli.add_argument("--revisao-cadastro", action="store_true",
                     help="compara os casos adicionais no cadastro de locais de 25 de outubro")
    args = cli.parse_args()
    if args.revisao_cadastro:
        gerar_revisao(args.dados)
    else:
        gerar(args.dados)
