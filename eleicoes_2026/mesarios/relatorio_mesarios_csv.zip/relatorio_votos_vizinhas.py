"""Publica as medidas calculadas por votos_vizinhas.py no relatório dos mesários."""
import csv
import json
from collections import defaultdict
from html import escape
from pathlib import Path
from statistics import mean, median

RAIZ = Path(__file__).resolve().parent
DADOS = RAIZ / "dados" / "relatorio"
TSE = "https://dadosabertos.tse.jus.br/dataset/resultados-2026-boletim-de-urna"
CADASTRO = "https://cdn.tse.jus.br/estatistica/sead/odsele/eleitorado_locais_votacao/eleitorado_local_votacao_2026.zip"
RESOLUCAO_TSE = "https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026"
MANUAL_QR_BU = "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/manual-do-qr-code-no-boletim-de-urna/@@display-file/file/manual-do-qr-code-no-boletim-de-urna.pdf"
MARGEM_RELATORIO = 0.25
MEMORIAL = "dados/memorial_calculo_votos_vizinhas.pdf"
CRITERIO_COMPARECIMENTO = (
    "A seção analisada precisa ter pelo menos 100 eleitores que votaram e pelo menos três vizinhas "
    "sem repetição no mesmo local e turno, cada uma com pelo menos 100 eleitores que votaram. "
    "O corte usa o comparecimento do boletim de urna e inclui quem votou em branco ou nulo."
)


def num(x, casas=0):
    if x is None or x == "":
        return "—"
    return f"{float(x):,.{casas}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def pp(x, casas=2):
    return num(x, casas) + " p.p."


def pct(x, casas=1):
    return "—" if x is None or x == "" else num(x, casas) + "%"


def tabela(colunas, linhas, legenda=None):
    titulo = f"<caption>{escape(legenda)}</caption>" if legenda else ""
    cab = "".join(f"<th scope='col'>{c}</th>" for c in colunas)
    corpo = "".join("<tr>"+"".join(f"<td>{v}</td>" for v in linha)+"</tr>" for linha in linhas)
    return f"<div class='scroll'><table>{titulo}<thead><tr>{cab}</tr></thead><tbody>{corpo}</tbody></table></div>"


def resumo():
    return json.loads((DADOS / "votos_vizinhas_resumo.json").read_text(encoding="utf-8"))


def leitura_principal(rs):
    a, b = rs["1"], rs["2"]
    return ("<p class='lead'><strong>Em geral, as seções com repetição de títulos de mesário votaram de forma semelhante às vizinhas.</strong></p>"
            "<p>O perfil de votação mostra como os votos válidos se distribuem. A <strong>distância</strong> resume o quanto "
            "dois perfis diferem. Ela é medida em <strong>pontos percentuais (p.p.)</strong>. Por exemplo, entre 40% e 43% "
            "há uma diferença de 3 pontos percentuais. Quanto mais parecidos os perfis, menor a distância.</p>"
            "<p>Para saber quanto é habitual variar, a análise mede também como cada vizinha se compara com as outras urnas "
            "do mesmo conjunto. Essa é a <strong>referência local</strong>.</p>"
            f"<p>No primeiro turno, a distância média das seções com repetição em relação às vizinhas foi de "
            f"<strong>{pp(a['distancia']['media'])}</strong>. Na referência local, a média foi de {pp(a['referencia']['media'])}. "
            f"No segundo turno, as médias foram <strong>{pp(b['distancia']['media'])}</strong> nas seções com repetição "
            f"e {pp(b['referencia']['media'])} na referência.</p>")


def sinal(valor, casas=3):
    if valor is None:
        return "—"
    return ("+" if valor > 0 else "−" if valor < 0 else "") + num(abs(valor), casas)


def faixa(limites):
    return " a ".join(sinal(x) for x in limites) + " p.p."


def probabilidade(p):
    return "&lt; 0,0001" if p < .0001 else num(p, 4)


def teste_na_margem(grupo, margem):
    return next(t for t in grupo["tost"] if t["margem_pp"] == margem)


def equivalencia_simultanea(rs):
    return all(max(map(abs, r["equivalencia"]["principal"]["ic95_simultaneo_pp"])) < MARGEM_RELATORIO
               for r in rs.values())


def conclusao_equivalencia(rs):
    if equivalencia_simultanea(rs):
        return (f"As faixas usadas na avaliação conjunta dos turnos, com 95% de confiança, ficaram inteiramente dentro da margem de "
                f"<strong>±{pp(MARGEM_RELATORIO)}</strong>.")
    return "A faixa que considera os dois turnos em conjunto ultrapassou a margem adotada em pelo menos um deles."


def nota_biometria(rs):
    cobertura = []
    for turno, r in rs.items():
        bio = r["falha_biometria"]
        base = num(bio["n"])
        if bio["n"] < r["n_comparaveis"]:
            base += " das " + num(r["n_comparaveis"])
        cobertura.append(f"No {turno}º turno, a comparação abrangeu {base} seções com repetição "
                         f"e {num(bio['n_controles'])} vizinhas distintas.")
    return ("<p>A taxa mostra a parcela dos eleitores presentes que precisaram de liberação pelo mesário porque "
            "a urna não reconheceu sua digital cadastrada. O boletim registra "
            "esses eleitores na categoria de identificação biográfica. A contagem abrange as liberações de toda a mesa. "
            "Quem não tinha biometria cadastrada consta em outra categoria. "
            f"<a href='{RESOLUCAO_TSE}'>Resolução TSE nº 23.751/2026, arts. 134, 135 e 210, XII</a>.</p>"
            "<p>O percentual das vizinhas resulta da divisão do total de liberações pelo total de comparecimentos "
            "nas vizinhas com dados disponíveis no mesmo local. " + " ".join(cobertura) + " "
            "<a href='dados/relatorio/votos_vizinhas_biometria.csv' download>Baixar as contagens de biometria por seção (CSV)</a>.</p>")


def recorte_logistico(linhas):
    with (DADOS / "em_aberto.csv").open(encoding="utf-8-sig", newline="") as f:
        casos = {(r["turno"], r["id_caso"]): r for r in csv.DictReader(f)}
    por_caso, secoes = defaultdict(list), []
    for r in linhas:
        referentes = [(r["turno"], id_caso) for id_caso in r["casos"].split(" | ")
                      if (r["turno"], id_caso) in casos]
        if referentes:
            secoes.append(r)
            for k in referentes:
                por_caso[k].append(r)
    if por_caso.keys() != casos.keys():
        raise ValueError("Cobertura das fichas em aberto diverge")
    return casos, por_caso, secoes


def indicadores_do_recorte(secoes):
    linhas = []
    for turno in ("1", "2"):
        boas = [r for r in secoes if r["turno"] == turno and r["situacao"] == "comparavel"]
        for campo, nome in (("comparecimento", "Comparecimento"), ("brancos", "Votos em branco"),
                            ("nulos", "Votos nulos"), ("falha_biometria", "Liberações após falha de biometria")):
            pares = []
            for r in boas:
                if campo in ("brancos", "nulos"):
                    percentuais = []
                    for lado in ("secao", "vizinhas"):
                        votos = sum(int(r[f"{tipo}_{lado}"]) for tipo in ("validos", "brancos", "nulos"))
                        percentuais.append(100 * int(r[f"{campo}_{lado}"]) / votos)
                    pares.append(percentuais)
                elif r[f"{campo}_secao_pct"] != "" and r[f"{campo}_vizinhas_pct"] != "":
                    pares.append((float(r[f"{campo}_secao_pct"]), float(r[f"{campo}_vizinhas_pct"])))
            medias = [pct(mean(vals), 2) for vals in zip(*pares)] if pares else ["—", "—"]
            linhas.append((f"{turno}º", nome, num(len(pares)), *medias))
    return tabela(("Turno", "Indicador", "Seções comparáveis", "Com repetição", "Vizinhas do mesmo local"), linhas)


def quadro_comparacao_dos_turnos(rs):
    from boletins_vizinhas import NOMES_CANDIDATOS
    from estatistica_vizinhas import MIN_COMPARECIMENTO

    campos_local = ("turno", "uf", "codigo_municipio", "zona", "local")
    campos_secao = (*campos_local, "secao")
    candidaturas = {t: sorted(c for c in nomes if c != "28")
                    for t, nomes in NOMES_CANDIDATOS.items()}
    with (DADOS / "votos_vizinhas_secoes.csv").open(encoding="utf-8-sig", newline="") as f:
        comparaveis = {tuple(r[k] for k in campos_secao): r
                       for r in csv.DictReader(f) if r["situacao"] == "comparavel"}
    locais = {chave[:-1] for chave in comparaveis}
    focais, vizinhas = {}, defaultdict(list)
    with (DADOS / "votos_vizinhas_boletins.csv").open(encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            local = tuple(r[k] for k in campos_local)
            if local not in locais:
                continue
            chave = (*local, r["secao"])
            elegivel = (r["marcada"] == "0" and r["suplementar"] == "0"
                        and int(r["comparecimento"] or 0) >= MIN_COMPARECIMENTO
                        and int(r["validos_totalizacao"] or 0) > 0)
            if chave not in comparaveis and not elegivel:
                continue
            votos = tuple(int(r[f"votos_{c}"] or 0) for c in candidaturas[int(r["turno"])])
            if sum(votos) != int(r["validos_totalizacao"]):
                raise ValueError(f"Votos válidos e soma por candidatura divergentes: {chave}")
            if chave in comparaveis:
                focais[chave] = votos
            else:
                vizinhas[local].append(votos)

    totais_vizinhas = {local: tuple(map(sum, zip(*urnas))) for local, urnas in vizinhas.items()}
    pares = defaultdict(list)
    for chave, secao in comparaveis.items():
        local = chave[:-1]
        urna, grupo = focais[chave], totais_vizinhas[local]
        total_urna, total_grupo = int(secao["validos_secao"]), int(secao["validos_vizinhas"])
        if (sum(urna), sum(grupo), len(vizinhas[local])) != (
            total_urna, total_grupo, int(secao["n_controles_validos"])
        ):
            raise ValueError(f"Referência por candidatura diverge da comparação publicada: {chave}")
        pares[chave[0]].append((urna, grupo, total_urna, total_grupo))

    def linha(rotulo, medias, *, contagens=None, subitem=False):
        celulas = [pct(valor, 2) for valor in medias]
        if contagens is not None:
            celulas = [f"{valor} <small>{num(n)} votos</small>"
                       for valor, n in zip(celulas, contagens, strict=True)]
        diferenca = sinal(round(medias[0] - medias[1], 2), 2)
        classe = " class='subitem-voto'" if subitem else ""
        return (f"<tr><th scope='row'{classe}>{escape(rotulo)}</th>"
                f"<td>{celulas[0]}</td><td>{celulas[1]}</td><td>{diferenca}</td></tr>")

    blocos = []
    for turno in ("1", "2"):
        dados_turno = pares[turno]
        locais_turno = [local for local in locais if local[0] == turno]
        if (len(dados_turno), sum(len(vizinhas[local]) for local in locais_turno)) != (
            rs[turno]["n_comparaveis"], rs[turno]["n_controles_distintos"]
        ):
            raise ValueError(f"Cobertura por candidatura divergente no {turno}º turno")
        itens = []
        for i, codigo in enumerate(candidaturas[int(turno)]):
            contagens = (sum(urna[i] for urna, _, _, _ in dados_turno),
                         sum(totais_vizinhas[local][i] for local in locais_turno))
            medias = (mean(100 * urna[i] / total for urna, _, total, _ in dados_turno),
                      mean(100 * grupo[i] / total for _, grupo, _, total in dados_turno))
            itens.append((codigo, sum(contagens), contagens, medias))

        def medias_indicador(campo):
            return tuple(rs[turno][campo][f"media_{lado}_pct"] for lado in ("secao", "vizinhas"))

        total_validos = sum(item[1] for item in itens)
        principais = sorted((item for item in itens if item[1] * 100 > 2 * total_validos),
                             key=lambda item: -item[1])
        outros = [item for item in itens if item[1] * 100 <= 2 * total_validos]
        brancos, nulos = medias_indicador("brancos"), medias_indicador("nulos")
        validos = tuple(100 - b - n for b, n in zip(brancos, nulos, strict=True))
        linhas = [
            f"<tr class='turno-votos'><th scope='rowgroup' colspan='4'>{turno}º turno</th></tr>",
            linha("Válidos", validos, contagens=tuple(sum(item[2][l] for item in itens) for l in (0, 1))),
        ]
        for codigo, _, contagens, medias in principais:
            linhas.append(linha(NOMES_CANDIDATOS[int(turno)][codigo], medias, contagens=contagens, subitem=True))
        linhas.append(linha("Outros candidatos", tuple(sum(item[3][l] for item in outros) for l in (0, 1)),
                            contagens=tuple(sum(item[2][l] for item in outros) for l in (0, 1)), subitem=True))
        linhas.extend((
            linha("Abstenções", tuple(100 - v for v in medias_indicador("comparecimento"))),
            linha("Brancos", brancos),
            linha("Nulos", nulos),
            linha("Liberação após falha da digital", medias_indicador("falha_biometria")),
        ))
        blocos.append("<tbody>" + "".join(linhas) + "</tbody>")
    return ("<div id='votacao-por-candidatura' class='scroll votos-por-candidatura'>"
            "<table aria-labelledby='votos-para-presidente'><thead><tr>"
            "<th scope='col'>Indicador</th><th scope='col'>Urnas com repetição</th>"
            "<th scope='col'>Urnas vizinhas</th><th scope='col'>Diferença em p.p.</th></tr></thead>"
            + "".join(blocos) + "</table></div>")


def painel():
    rs = resumo()
    with (DADOS / "em_aberto.csv").open(encoding="utf-8-sig", newline="") as f:
        total_pendente = sum(1 for _ in csv.DictReader(f))
    cobertos = sum(r["n_comparaveis"] for r in rs.values())
    universo = sum(r["n_marcadas_universo"] for r in rs.values())
    conclusao = (
        "No conjunto analisado, a votação nas seções com repetição ficou, em média, dentro da variação habitual observada entre as vizinhas."
        if equivalencia_simultanea(rs) else
        "A análise completa apresenta a diferença média entre os grupos e os limites de incerteza da comparação."
    )
    return ("<section id='votos-vizinhas'><h2>5. Como votaram as seções com repetição de mesários?</h2>"
            "<p class='lead'>"
            f"A comparação abrange {num(cobertos)} das {num(universo)} seções-turno ({pct(100*cobertos/universo)}). "
            "Cada seção entra uma vez por turno, mesmo que nela apareçam vários títulos repetidos.</p>"
            f"<p>{CRITERIO_COMPARECIMENTO}</p>"
            "<h3 id='votos-para-presidente'>Votos para presidente nas urnas comparadas</h3>"
            "<p>Em cada turno, aparecem por nome as candidaturas com mais de 2% dos votos válidos na soma dos dois grupos de urnas. "
            "A ordem vai da maior para a menor contagem nessa soma. Os demais votos válidos ficam em “Outros candidatos”.</p>"
            + quadro_comparacao_dos_turnos(rs)
            + "<p class='fine' id='indicadores-da-secao'>Válidos, brancos e nulos são percentuais dos votos depositados. "
            "As linhas de candidaturas usam os votos válidos. Abstenções usam o total de eleitores aptos e liberações após falha da digital usam os votantes.</p>"
            "<p class='fine'>Cada seção com repetição e seu conjunto de vizinhas têm o mesmo peso nas médias. "
            "As contagens somam cada urna uma vez por turno. A última coluna subtrai o percentual das vizinhas "
            "do percentual das urnas com repetição antes do arredondamento. "
            "<a href='https://dadosabertos.tse.jus.br/pt_BR/dataset/resultados-2026/resource/01ea4ccd-f443-469c-9f29-c69ff97f7d4c'>Votos nominais por seção no TSE</a>.</p>"
            "<h4>Como os perfis de votação foram comparados?</h4>"
            "<p>O perfil de votação é a distribuição dos votos válidos em percentuais. O teste mede quanto esse perfil "
            "difere entre a seção com repetição e as vizinhas sem repetição. A referência mede quanto as urnas variam "
            "no próprio local.</p>"
            + nota_biometria(rs)
            + f"<p><a href='votos_vizinhas.html#casos'>Ver a cobertura e os indicadores nos "
            f"{num(total_pendente)} casos com deslocamento improvável que seguem sem explicação específica</a>.</p>"
            f"<p><strong>{conclusao}</strong></p>"
            "<p><a href='votos_vizinhas.html'>Abrir a análise completa das seções</a> · "
            f"<a href='{MEMORIAL}' download>Baixar o memorial de cálculo (PDF)</a> · "
            "<a href='dados/relatorio/votos_vizinhas_equivalencia.csv' download>Baixar os testes e intervalos (CSV)</a> · "
            "<a href='dados/relatorio/votos_vizinhas_secoes.csv' download>Baixar os dados por seção (CSV)</a></p></section>")


def curva(turno, dados):
    pontos = dados["distribuicao_acumulada"]
    def x(k): return 49 + k / 20 * 355
    def y(p): return 181 - p / 100 * 148
    grade = "".join(f"<line x1='49' x2='404' y1='{y(v)}' y2='{y(v)}' stroke='#dbe2dd'/>"
                    f"<text x='41' y='{y(v)+4}' text-anchor='end'>{v}%</text>" for v in (0,25,50,75,100))
    ticks = "".join(f"<text x='{x(k)}' y='202' text-anchor='middle'>{k}</text>" for k in (0,5,10,15,20))
    series = []
    for campo, cor, estilo in (("marcadas_pct","#0a6355",""),("referencia_pct","#a04419","stroke-dasharray='5 4'")):
        pts = " ".join(f"{x(v['limiar_pp']):.2f},{y(v[campo]):.2f}" for v in pontos)
        series.append(f"<polyline points='{pts}' fill='none' stroke='{cor}' stroke-width='2.7' {estilo}/>")
    return (f"<figure><figcaption><strong>{turno}º turno</strong></figcaption><svg viewBox='0 0 430 232' role='img' "
            f"aria-label='Percentual acumulado por distância, {turno}º turno. Valores resumidos na tabela seguinte.'>"
            f"{grade}{ticks}{''.join(series)}<text x='221' y='224' text-anchor='middle'>Distância até o limite indicado (p.p.)</text>"
            "</svg></figure>")


def cobertura(rs):
    linhas = []
    for t,r in rs.items():
        linhas.append((f"{t}º", num(r["n_casos"]), num(r["n_marcadas_universo"]), num(r["n_comparaveis"]),
                       num(r["n_controles_distintos"]), num(r["n_locais_comparaveis"]),
                       num(r["situacoes"].get("abaixo_minimo_comparecimento", 0)),
                       num(r["situacoes"].get("sem_controle", 0)),
                       num(r["n_sem_bu"]+r["situacoes"].get("sem_votos_validos",0))))
    return tabela(("Turno","Casos título–turno","Seções com repetição","Com vizinhas de referência","Vizinhas de referência distintas",
                   "Locais comparáveis","Menos de 100 eleitores que votaram",
                   "Menos de três vizinhas elegíveis","Sem BU ou sem voto válido"),linhas)


def distribuicao(rs):
    cab=("Turno","Medida","Com repetição","Referência local")
    linhas=[]
    for t,r in rs.items():
        for chave,rotulo in (("media","Média"),("mediana","Mediana"),("p90","Percentil 90"),("p95","Percentil 95")):
            linhas.append((f"{t}º",rotulo,pp(r["distancia"][chave]),pp(r["referencia"][chave])))
    extremos=tabela(("Turno","Corte do percentil 95 de referência","Com repetição acima do corte","% com repetição","% da referência acima"),
                    [(f"{t}º",pp(r["extremos"]["limiar_p95_ref_pp"]),num(r["extremos"]["n_acima"]),
                      pct(r["extremos"]["pct_acima"],2),pct(r["extremos"]["pct_referencia_acima"],2)) for t,r in rs.items()])
    return ("<div class='legenda'><span class='marcada'>Com repetição</span><span class='referencia'>Referência local</span></div>"
            "<div class='curvas'>"+ "".join(curva(t,r) for t,r in rs.items())+"</div>"
            + tabela(cab,linhas)+extremos)


def permutacao(rs):
    linhas = []
    for t,r in rs.items():
        p = r["permutacao"]
        linhas.append((f"{t}º",pp(p["observado_pp"],3),pp(p["esperado_pp"],3),pp(p["excesso_pp"],3),
                       f"{num(p['p025_pp'],3)} a {pp(p['p975_pp'],3)}",num(p["p_superior"],4)))
    return tabela(("Turno","Média observada","Média esperada","Observada − esperada","Faixa central dos sorteios (95%)","p para excesso"),linhas)


def grafico_equivalencia(rs):
    # O mesmo eixo representa os dois turnos e os limites de equivalência.
    grupos = [r["equivalencia"]["principal"] for r in rs.values()]
    escala = 1.20 * max(MARGEM_RELATORIO, *(abs(v) for g in grupos for v in g["ic95_simultaneo_pp"]))
    def x(v):
        return 210 + 145 * v / escala
    esquerda, direita = x(-MARGEM_RELATORIO), x(MARGEM_RELATORIO)
    desenho = [f"<rect x='{esquerda:.2f}' y='10' width='{direita-esquerda:.2f}' height='74' fill='#dceee5'/>"]
    for valor in (-MARGEM_RELATORIO, 0, MARGEM_RELATORIO):
        pos = x(valor)
        desenho.append(f"<path d='M{pos:.2f} 10v75' stroke='#688274' stroke-dasharray='3 3'/>"
                       f"<text x='{pos:.2f}' y='104' text-anchor='middle'>{sinal(valor,2) if valor else '0'}</text>")
    for (turno, _), g, y in zip(rs.items(), grupos, (30, 65), strict=True):
        a, b = map(x, g["ic95_simultaneo_pp"])
        desenho.append(f"<text x='4' y='{y+5}'>{turno}º turno</text>"
                       f"<path d='M{a:.2f} {y-5}v10 M{a:.2f} {y}H{b:.2f} M{b:.2f} {y-5}v10' stroke='#174a3c' stroke-width='2'/>"
                       f"<circle cx='{x(g['diferenca_pp']):.2f}' cy='{y}' r='4' fill='#174a3c'/>")
    return ("<figure class='intervalos'><figcaption>Diferença média em pontos percentuais</figcaption>"
            "<svg viewBox='0 0 375 113' role='img' aria-label='Estimativas e intervalos simultâneos de confiança de 95% dos dois turnos. Valores na tabela técnica abaixo.'>"
            + "".join(desenho) + "</svg><p class='nota'>O ponto marca a média, a linha mostra o intervalo de confiança "
            "e o fundo verde indica a margem adotada.</p></figure>")


def secao_equivalencia(rs):
    principal, sensibilidade, robustez = [], [], []
    for turno, r in rs.items():
        grupos = r["equivalencia"]
        g = grupos["principal"]
        teste = teste_na_margem(g, MARGEM_RELATORIO)
        principal.append((turno+"º", num(g["n_secoes"]), num(g["n_locais"]), sinal(g["diferenca_pp"])+" p.p.",
                          faixa(g["ic95_pp"]), faixa(g["ic95_simultaneo_pp"]), probabilidade(teste["p_tost"])))
        for t in g["tost"]:
            sensibilidade.append((turno+"º", "±"+pp(t["margem_pp"]), probabilidade(t["p_tost"]),
                                  "Sim" if t["equivalente_5pct"] else "Inconclusivo",
                                  "Sim" if max(map(abs, g["ic95_simultaneo_pp"])) < t["margem_pp"] else "Não"))
        for nome, rotulo in (("por_municipio","Agrupamento por município"),("independente","Referência só de controles")):
            k = grupos[nome]
            robustez.append((turno+"º",rotulo,num(k["n_conglomerados"]),num(k["n_secoes"]),
                             sinal(k["diferenca_pp"])+" p.p.",faixa(k["ic95_pp"]),
                             probabilidade(teste_na_margem(k,MARGEM_RELATORIO)["p_tost"])))
    return ("<section id='equivalencia'><h2>Quanto a votação pode destoar da variação habitual?</h2>"
            "<p>O teste subtrai a variação habitual da variação observada nas urnas com repetição. Uma diferença média de "
            "zero indica o mesmo grau de variação. Se for positiva, as urnas com repetição variaram mais que o habitual. "
            "Se for negativa, variaram menos.</p>"
            f"<p>A <strong>margem de equivalência</strong> é a faixa em que essa diferença média é considerada pequena "
            f"para a análise. Foi adotada uma margem exploratória de <strong>±{pp(MARGEM_RELATORIO)}</strong>, definida "
            "depois de observar as médias do conjunto mais amplo de seções.</p>"
            "<p>O <strong>intervalo de confiança</strong> mostra a incerteza em torno da diferença média. Se o cálculo "
            "fosse repetido em estudos comparáveis sob as mesmas condições, o procedimento de 95% incluiria a diferença "
            "média que se quer estimar em cerca de 95 de cada 100 estudos. Aqui, as faixas foram calculadas para avaliar os dois "
            "turnos em conjunto. Para essa conclusão de equivalência, ambas precisam caber inteiras na margem.</p>"
            f"<p>{conclusao_equivalencia(rs)}</p>"
            + grafico_equivalencia(rs)
            + "<details><summary>Ver as estimativas e os testes com outras margens</summary>"
            "<p>A tabela traz a faixa de confiança de cada turno e a faixa mais ampla usada para avaliar os dois juntos. "
            "O valor de <em>p</em> de equivalência resume a evidência de que a diferença média está dentro dos limites. "
            "Nesse teste, um valor abaixo de 0,05 sustenta a equivalência do turno na margem escolhida.</p>"
            + tabela(("Turno","Seções","Locais","Diferença média","IC de 95% do turno",
                      "IC simultâneo de 95% para os dois turnos","p de equivalência (±0,25 p.p.)"),principal)
            + "<p>Os intervalos simultâneos cobrem em conjunto as duas estimativas, uma para cada turno. "
            "O ajuste de Bonferroni admite dependência entre os turnos. O cálculo da incerteza agrupa as seções por local "
            "de votação porque elas podem compartilhar as mesmas vizinhas.</p>"
            "<p>O teste de equivalência usa dois testes unilaterais (TOST), ao nível de 5%. Para concluir pela equivalência, "
            "é preciso haver evidência tanto de que a diferença média excede o limite inferior quanto de que fica abaixo do superior. "
            "O p de equivalência é o maior dos dois valores de p. A conclusão requer p inferior a 0,05 e corresponde a um "
            "intervalo bilateral de 90% inteiramente dentro da margem para aquele turno. "
            "A última coluna abaixo aplica o critério mais exigente dos intervalos simultâneos mostrados no gráfico.</p>"
            + tabela(("Turno","Margem","p de equivalência","Equivalência pelo TOST a 5%","IC simultâneo inteiro na margem"),sensibilidade)
            + "<p>O erro-padrão robusto permite correlação entre seções do mesmo local e trata os locais como independentes. "
            "O cálculo usa a distribuição t com um grau de liberdade a menos que o número de grupos. Cada um dos dois intervalos "
            "simultâneos tem cobertura individual de 97,5%. A primeira verificação de sensibilidade agrupa as seções por município, "
            "para levar em conta relações entre locais próximos. A segunda compara a seção com repetição e uma vizinha com a mesma "
            "base de pelo menos três outras seções sem repetição.</p>"
            + tabela(("Turno","Verificação","Grupos","Seções","Diferença média","IC de 95% do turno","p (±0,25 p.p.)"),robustez)
            + "<p><a href='https://doi.org/10.1007/BF01068419'>Schuirmann, método TOST</a> · "
            "<a href='https://cameron.econ.ucdavis.edu/research/Cameron_Miller_JHR_2015_February.pdf'>Cameron e Miller, inferência por conglomerados</a>.</p></details>"
            "<p>Os boletins cobrem todas as seções comparáveis deste recorte. A média observada é conhecida. O intervalo expressa "
            "a incerteza sobre o padrão médio em locais comparáveis sob as hipóteses do modelo. Uma urna individual pode se afastar "
            "bem mais das vizinhas. A votação de um candidato e a margem de vitória são medidas diferentes da distância testada aqui.</p>"
            "<p><a href='dados/relatorio/votos_vizinhas_equivalencia.csv' download>Baixar estimativas, intervalos e testes para as três margens (CSV)</a></p></section>")


def linha_grupo(nome,turno,linhas):
    boas=[r for r in linhas if r["situacao"]=="comparavel"]
    valores=[float(r["distancia_pp"]) for r in boas]
    return (nome,f"{turno}º",num(len(linhas)),num(len(boas)),pp(mean(valores)) if boas else "—",
            pp(mean(float(r["referencia_media_pp"]) for r in boas)) if boas else "—",
            pp(median(valores)) if boas else "—")


def recortes(linhas, casos, abertos):
    grupos,ufs=defaultdict(list),defaultdict(list)
    for r in linhas:
        for g in r["grupos"].split(" | "): grupos[g,r["turno"]].append(r)
        ufs[r["uf"],r["turno"]].append(r)
    medidas=("Grupo","Turno","Seções com repetição","Comparáveis","Distância média","Referência média","Mediana da distância")
    quadro=tabela(medidas[:4], [(g, t+"º", num(len(rs)), num(sum(r["situacao"] == "comparavel" for r in rs)))
                                for (g,t),rs in sorted(grupos.items())])
    regioes=tabela(("UF",*medidas[1:]),[linha_grupo(uf,t,rs) for (uf,t),rs in sorted(ufs.items())])
    casos_linhas=[]
    for chave,d in casos.items():
        ident=d["id_caso"]
        rs=abertos[chave]; boas=[r for r in rs if r["situacao"]=="comparavel"]
        casos_linhas.append((f"<a href='relatorio.html#listas-f-{d['turno']}-{ident.lower()}'>{escape(d['municipios'])}</a>",
                             d["titulo"],d["turno"]+"º",num(len(boas))+" de "+num(len(rs))))
    return (quadro+"<details><summary>Resultados nas 27 unidades da Federação, por turno</summary>"+regioes+"</details>",
            f"<details><summary>Consultar os {num(len(casos))} casos sem explicação específica</summary>"+tabela(
                ("Municípios","Título repetido","Turno","Seções comparáveis"),casos_linhas)+"</details>")


def identificar(r):
    return f"{escape(r['municipio'].title())}/{r['uf']} · Z{r['zona']} S{r['secao']}"


def extremos(linhas):
    resultado=[]
    for t in ("1","2"):
        grupo=sorted((r for r in linhas if r["turno"]==t and r["situacao"]=="comparavel"),
                     key=lambda r:(-float(r["distancia_pp"]),r["uf"],r["secao"]))[:5]
        for r in grupo:
            fonte=f"<a href='{escape(r['url_bu'],quote=True)}'>BU oficial</a>"
            resultado.append((t+"º",identificar(r),escape(r["estabelecimento"].title()),num(r["validos_secao"]),
                              num(r["n_controles_validos"]),num(r["validos_vizinhas"]),pp(r["distancia_pp"]),fonte))
    return tabela(("Turno","Seção","Local","Válidos na seção","Vizinhas","Válidos nas vizinhas","Distância","Fonte"),resultado)


ESTILO = """
:root{--ink:#19322c;--muted:#465e56;--rule:#cbd9d1;--paper:#fbfcf8;--verde:#075d50}
*{box-sizing:border-box}body{margin:0;font:16px/1.57 'Segoe UI',Arial,sans-serif;color:var(--ink);background:var(--paper)}
header{background:#163f38;color:white}main,header>div,footer{max-width:1120px;margin:auto;padding:1.4rem clamp(1rem,4.5vw,3.75rem)}
header>div{padding-block:2rem}header a{color:#daeee3}h1,h2,h3{font-family:Georgia,serif;font-weight:normal;line-height:1.14;letter-spacing:-.02em}
h1{font-size:clamp(2.1rem,4.7vw,3.6rem);margin:.65rem 0 .3rem;max-width:26ch}h2{font-size:clamp(1.65rem,3vw,2.35rem);margin:0 0 .75rem}h3{font-size:1.4rem;margin:1.4rem 0 .5rem}
p,li{max-width:88ch}p{margin:.5rem 0 .8rem}a,summary{color:var(--verde);text-underline-offset:3px}
section{border-top:1px solid var(--rule);padding:1.65rem 0}.lead{font-size:1.16rem}section:first-of-type{border-top:0}
nav,footer{display:flex;flex-wrap:wrap;gap:.35rem 1.2rem}nav{font-size:.94rem;padding:.35rem 0 .8rem}aside{background:#edf3ec;border-left:3px solid #47785e;padding:.65rem 1rem;margin:1.1rem 0}
.scroll{max-width:100%;overflow-x:auto;margin:.9rem 0 1.2rem}table{width:100%;border-collapse:collapse;font-size:.92rem;font-variant-numeric:tabular-nums}
td,th{text-align:left;vertical-align:top;padding:.47rem .56rem;border-bottom:1px solid var(--rule)}th{font-weight:650;background:#eef3ed}
.comparacao-candidaturas caption{text-align:left;font-weight:650;padding:.4rem 0}
.comparacao-candidaturas :is(td,th):not(:first-child){text-align:right}
details{margin:1rem 0}summary{cursor:pointer;font-weight:600}.curvas{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.4rem}
figure{margin:0}figure svg{width:100%;height:auto;display:block}figure svg text{font:12px 'Segoe UI',Arial,sans-serif;fill:var(--muted)}
.intervalos{max-width:570px;margin:1rem auto}.intervalos figcaption{font-weight:600}.intervalos svg text{font-size:14px}
.legenda{display:flex;flex-wrap:wrap;gap:1.3rem;margin:1.15rem 0 .6rem}.legenda span:before{content:'';display:inline-block;width:2rem;border-top:3px solid #0a6355;vertical-align:middle;margin-right:.4rem}
.legenda .referencia:before{border-color:#a04419;border-top-style:dashed}
.nota{color:var(--muted);font-size:.93rem;padding:9px 15px;border-left:3px solid #47785e;background:#edf3ec}
code{font-variant-numeric:tabular-nums}
.nota-bu-biometria{display:grid;gap:.55rem;padding:.85rem 1rem}
.nota-bu-biometria p{margin:0}
.nota-bu-biometria :is(code,a){overflow-wrap:anywhere}
@media(max-width:620px){.curvas{grid-template-columns:1fr}figure svg text{font-size:16px}td,th{padding:.36rem}.lead{font-size:1.06rem}}@media print{nav,footer{display:none}.scroll{overflow:visible}section{break-inside:auto}figure{break-inside:avoid}}
"""


def gerar():
    rs=resumo()
    with (DADOS/"votos_vizinhas_secoes.csv").open(encoding="utf-8-sig", newline="") as f:
        linhas=list(csv.DictReader(f))
    casos, por_caso, abertas = recorte_logistico(linhas)
    grupos, tabela_casos=recortes(linhas, casos, por_caso)
    incluidos=sum(r["n_comparaveis"] for r in rs.values())
    universo=sum(r["n_marcadas_universo"] for r in rs.values())
    independente=tabela(("Turno","Seções com repetição","Locais","Distância da seção com repetição","Distância da vizinha à mesma base","Diferença"),
                        [(t+"º",num(c["n_marcadas"]),num(c["n_locais"]),pp(c["media_marcadas_pp"]),pp(c["media_controles_pp"]),pp(c["diferenca_pp"]))
                         for t,r in rs.items() for c in [r["controles_independentes"]]])
    comparaveis_abertas=[r for r in abertas if r["situacao"]=="comparavel"]
    cobertos=sum(any(r["situacao"] == "comparavel" for r in lista) for lista in por_caso.values())
    por_turno=[]
    for t in ("1","2"):
        sub=[r for r in comparaveis_abertas if r["turno"]==t]
        por_turno.append(f"{len(sub)} de {sum(r['turno'] == t for r in abertas)} seções no {t}º turno")
    fonte_final = DADOS / "votos_vizinhas_conferencia.json"
    verificacao = ""
    if fonte_final.exists():
        ver = json.loads(fonte_final.read_text(encoding="utf-8"))
        if ver.get("texto_relatorio"):
            verificacao = (f"<p>{escape(ver['texto_relatorio'])} <a href='{escape(ver['pagina_recurso_votacao_secao_tse'],quote=True)}'>"
                           f"Votação por seção do TSE</a> · <a href='dados/relatorio/{fonte_final.name}'>Conferência das fontes</a>.</p>")
    pagina=f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Votos nas seções com repetição de mesários · Eleições presidenciais de 2026</title><style>{ESTILO}
main p,main figcaption,footer p{{text-align:justify;hyphens:auto}}
</style></head><body>
<header><div><a href="relatorio.html#votos-vizinhas">Relatório dos títulos de mesário repetidos</a><h1>Como votaram as seções com repetição de mesários?</h1>
<p>Eleições presidenciais de 2026 · Primeiro e segundo turnos · Brasil, excluído o exterior</p></div></header>
<main><nav aria-label="Conteúdo"><a href="#resultado">Resultado geral</a><a href="#equivalencia">Teste de equivalência</a><a href="#abrangencia">Cobertura</a><a href="#distribuicao">Distribuição</a>
<a href="#chapas">Indicadores da votação</a><a href="#robustez">Testes de robustez</a><a href="#casos">Casos em aberto</a><a href="#fontes">Dados e fontes</a></nav>
<section id="resultado"><h2>O resultado geral</h2>
{leitura_principal(rs)}
<p><a class="download" href="{MEMORIAL}" download>Baixar o memorial de cálculo (PDF)</a></p>
<h3>Quais seções foram comparadas?</h3>
<p>O ponto de partida são as <strong>{num(universo)} seções-turno</strong> em que pelo menos um título de mesário também foi registrado em outra seção no mesmo turno. Cada seção é contada uma vez por turno, mesmo que nela apareçam vários títulos repetidos.</p>
<p>{CRITERIO_COMPARECIMENTO} Para calcular o perfil de votação, também foi preciso ter o boletim de cada urna usada e pelo menos um voto válido para presidente em cada boletim.</p>
<p>Atenderam aos critérios <strong>{num(incluidos)} de {num(universo)} seções-turno ({pct(100*incluidos/universo)})</strong>. Foram {num(rs['1']['n_comparaveis'])} de {num(rs['1']['n_marcadas_universo'])} no 1º turno e {num(rs['2']['n_comparaveis'])} de {num(rs['2']['n_marcadas_universo'])} no 2º. <a href="#abrangencia">Ver a cobertura e os motivos de exclusão</a>.</p>
<h3>Quantas seções ficaram acima da faixa de referência?</h3>
<p>Organizando as distâncias da referência local da menor para a maior, o <strong>percentil 95</strong> é o valor que abrange 95% da distribuição. Esse limite foi calculado para cada turno. Ficaram acima dele <strong>{pct(rs['1']['extremos']['pct_acima'])} das seções comparáveis com repetição no 1º turno</strong> e <strong>{pct(rs['2']['extremos']['pct_acima'])} no 2º</strong>. <a href="#distribuicao">Ver como o corte foi calculado</a> · <a href="#fontes">Consultar os dados por seção</a>.</p></section>
{secao_equivalencia(rs)}
<section id="abrangencia"><h2>Quais urnas entram na comparação?</h2>
<p>O relatório de origem reúne 11.866 pares de título e turno. Uma seção integra o grupo com repetição quando algum título registrado na sua equipe de mesários também aparece na equipe de outra seção no mesmo turno. Cada seção entra uma vez, mesmo quando há vários títulos repetidos.
As vizinhas pertencem ao mesmo estabelecimento no cadastro do TSE para o turno e compartilham UF, município, zona e código de local.</p>
<p>{CRITERIO_COMPARECIMENTO} O cálculo do perfil de votação também requer ao menos um voto válido em cada boletim usado. <a href="{MANUAL_QR_BU}">Manual do boletim de urna do TSE</a>.</p>
{cobertura(rs)}
<p>O boletim de cada seção principal entra uma única vez e já inclui as seções agregadas. Os registros das urnas de contingência mostram outras 13 repetições. Uma seção adicional do primeiro turno aparece apenas nessa lista e fica fora do grupo de controle.</p></section>
<section id="distribuicao"><h2>Quanto variam as urnas de um mesmo local?</h2>
<p>Primeiro, são somados os votos válidos de todas as vizinhas elegíveis. A distância mede a diferença entre o perfil desse conjunto e o da urna com repetição. Para obter uma referência, cada vizinha é comparada com as outras urnas do conjunto, incluindo a urna com repetição. Isso deixa o mesmo número de urnas do outro lado de cada comparação.</p>
<details><summary>Como a distância e a referência são calculadas</summary>
<p>A <strong>distância de variação total</strong> é a metade da soma das diferenças absolutas, em pontos percentuais, entre as parcelas dos dois perfis. Ela varia de 0 a 100 p.p. Na referência, as distâncias das vizinhas de cada seção com repetição são reunidas com o mesmo peso total que a distância daquela seção.</p></details>
<p>As curvas mostram quantas seções, em percentual, ficaram até a distância indicada no eixo horizontal. A mediana é o ponto que abrange metade da distribuição. Os percentis 90 e 95 abrangem 90% e 95%, respectivamente.</p>
{distribuicao(rs)}<p class="nota">O percentil 95 é um corte descritivo. Mesmo entre seções de referência há resultados acima dele.</p></section>
<section id="chapas"><h2>Comparecimento, brancos, nulos e falhas de biometria</h2>
<p>O quadro mostra médias por turno para seções com repetição e suas vizinhas elegíveis. Cada seção comparada tem o mesmo peso na média. O perfil usa os votos válidos publicados na totalização. Brancos e nulos têm como base o total de votos depositados. O comparecimento é o percentual de eleitores aptos que votaram. As liberações após falha de biometria aparecem como percentual dos eleitores que votaram.
<a href="https://cdn.tse.jus.br/estatistica/sead/odsele/relatorio_resultado_totalizacao/Relatorio_Resultado_Totalizacao_2026_BR.zip">Relatório de totalização do TSE, 1º turno, pp. 3–4</a>.</p>
{tabela(("Turno", "Indicador", "Seções com repetição", "Vizinhas do mesmo local"),
        [(f"{t}º", rotulo, pct(r[campo]["media_secao_pct"], 2), pct(r[campo]["media_vizinhas_pct"], 2))
         for t, r in rs.items()
         for campo, rotulo in (("comparecimento", "Comparecimento"), ("brancos", "Votos em branco"),
                               ("nulos", "Votos nulos"), ("falha_biometria", "Liberações após falha de biometria"))])}
{nota_biometria(rs)}
<aside class="nota nota-bu-biometria" aria-label="Campos de biometria no boletim de urna">
<p>Na base de boletins do TSE, a coluna <code>QT_ELEI_BIOM_SEM_HABILITACAO</code> informa quantos eleitores com biometria cadastrada votaram sem reconhecimento da digital.</p>
<p>No QR Code do boletim, a contagem de liberações após falha corresponde ao campo <code>HBBG</code>. Ele conta cada eleitor habilitado pelo ano de nascimento após falha no reconhecimento da digital.</p>
<p>O campo <code>HBSB</code> reúne os eleitores sem biometria cadastrada.</p>
<p><a href="{TSE}">Base e dicionário de dados dos boletins</a> · <a href="{MANUAL_QR_BU}#page=16">Manual do QR Code do boletim de urna, p. 16</a>.</p>
</aside></section>
<section id="robustez"><h2>O que acontece se a marcação mudar de seção?</h2>
<p>Outro teste, chamado <strong>permutação</strong>, simula o que aconteceria se a marcação de repetição fosse atribuída ao acaso. O cálculo mede a distância de cada seção em relação ao conjunto das demais urnas elegíveis do local. Em seguida, distribui a marcação entre essas urnas em {num(rs['1']['permutacao']['n_permutacoes'])} sorteios por turno. A cada sorteio, o número de seções marcadas em cada local permanece o mesmo.</p>
<p>A média observada usa as marcações reais. A média esperada representa o que se obteria, em média, nos sorteios. A faixa central reúne cerca de 95% das médias simuladas. O valor de <em>p</em> do sorteio é calculado a partir da proporção de sorteios em que a média foi igual ou maior que a observada. Ele indica quão comum seria alcançar esse resultado se as marcações fossem atribuídas ao acaso.</p>
{permutacao(rs)}
<h3>Uma referência inteiramente independente das seções com repetição</h3>
<p>Nos locais com pelo menos quatro vizinhas elegíveis sem repetição, uma delas forma um par com a seção com repetição. As duas integrantes do par são comparadas com <strong>as mesmas três ou mais vizinhas restantes</strong>. A média de cada seção reúne os resultados de todos os seus pares. A média do turno reúne as médias dessas seções.</p>{independente}</section>
<section id="casos"><h2>Os casos sem explicação específica</h2>
<p>Dos {num(len(casos))} casos sem explicação específica sob o critério de cinco minutos entre os relógios, {num(cobertos)} têm pelo menos uma seção que atende ao corte de comparecimento e tem três vizinhas elegíveis.
São {num(len(comparaveis_abertas))} seções-turno comparáveis entre as {num(len(abertas))} envolvidas ({' e '.join(por_turno)}).</p>
{indicadores_do_recorte(abertas)}
<p>Uma seção vinculada a casos de categorias diferentes aparece em cada categoria pertinente. No resultado geral, ela conta uma única vez.</p>
{grupos}{tabela_casos}</section>
<section id="extremos"><h2>Onde estavam as maiores diferenças?</h2>
<p>A tabela apresenta as cinco maiores distâncias de cada turno entre as seções com vizinhas de referência. O número de votos ajuda a interpretar os extremos. O CSV traz todas as seções e a distância entre os perfis. Uma diferença isolada pode ter várias causas.</p>
{extremos(linhas)}
<p>O controle pelo local reduz diferenças entre regiões, mas seções do mesmo estabelecimento podem reunir perfis distintos de eleitores. A comparação detecta diferenças relativas entre seções do mesmo local. Uma alteração comum a todas elas não seria distinguida por este método. Os boletins são agregados e preservam o sigilo do voto.</p></section>
<section id="fontes"><h2>Dados, fontes e reprodução</h2>
<ul><li><a href="dados/relatorio/votos_vizinhas_secoes.csv" download>Uma linha por seção com repetição e turno</a>, com os casos, a situação da comparação, os indicadores e a distância entre os perfis das seções elegíveis.</li>
<li><a href="dados/relatorio/votos_vizinhas_boletins.csv" download>Boletins de todas as seções dos locais estudados</a>, com contagens, chave de local, URL do BU original e SHA-256.</li>
<li><a href="dados/relatorio/votos_vizinhas_biometria.csv" download>Liberações após falha de biometria por seção</a> e <a href="biometria_vizinhas.py">script de extração</a>. Quando o boletim conserva o código do estabelecimento de origem, o cadastro do TSE identifica o local vigente da seção naquele turno, usado para selecionar as vizinhas.</li>
<li><a href="dados/relatorio/votos_vizinhas_equivalencia.csv" download>Teste de equivalência em CSV</a>, com as estimativas, os intervalos e os valores de p de cada teste.</li>
<li><a href="dados/relatorio/votos_vizinhas_resumo.json" download>Indicadores, percentis, sorteios e teste de equivalência em JSON</a>.</li></ul>
<p>As fontes da análise são os boletins oficiais da eleição presidencial de 2026, o cadastro de locais por turno e a lista de repetições do relatório da Arvor, conferida nos logs desta auditoria.
<a href="{TSE}">Boletins de urna do TSE</a> · <a href="{CADASTRO}">Cadastro de locais do TSE</a> · <a href="https://brasil.arvor.co/auditoria-2026/mesarios/relatorio.html">Relatório de origem</a>.</p>
{verificacao}
<p>Na pasta do relatório extraído, execute <code>python votos_vizinhas.py</code> com Python 3.12 para reproduzir os resultados a partir dos boletins incluídos. Para recalcular apenas o teste a partir do CSV por seção, execute <code>python equivalencia_vizinhas.py</code>.
<a href="../relatorio_mesarios_csv.zip" download>Baixar o pacote com os CSVs e os scripts</a> · <a href="votos_vizinhas.py">Cruzamento e exportação</a> · <a href="equivalencia_vizinhas.py">Teste de equivalência</a> · <a href="estatistica_vizinhas.py">Cálculos e permutação</a> · <a href="universo_vizinhas.py">Universo de seções</a> · <a href="boletins_vizinhas.py">Extração dos boletins</a>.</p></section>
</main><footer><a href="relatorio.html#votos-vizinhas">Voltar ao relatório principal</a></footer></body></html>"""
    (RAIZ/"votos_vizinhas.html").write_text(pagina,encoding="utf-8")


if __name__ == "__main__":
    gerar()
