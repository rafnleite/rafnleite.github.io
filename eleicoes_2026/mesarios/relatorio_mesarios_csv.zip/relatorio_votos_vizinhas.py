"""Publica as medidas calculadas por votos_vizinhas.py no relatório dos mesários."""
import csv
import json
from collections import defaultdict
from html import escape
from math import ceil
from pathlib import Path
from statistics import mean, median

RAIZ = Path(__file__).resolve().parent
DADOS = RAIZ / "dados" / "relatorio"
TSE = "https://dadosabertos.tse.jus.br/dataset/resultados-2026-boletim-de-urna"
CADASTRO = "https://cdn.tse.jus.br/estatistica/sead/odsele/eleitorado_locais_votacao/eleitorado_local_votacao_2026.zip"
RESOLUCAO_TSE = "https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026"
MANUAL_QR_BU = "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/manual-do-qr-code-no-boletim-de-urna/@@display-file/file/manual-do-qr-code-no-boletim-de-urna.pdf"
MARGEM_RELATORIO = 0.25


def num(x, casas=0):
    if x is None or x == "":
        return "—"
    return f"{float(x):,.{casas}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def pp(x, casas=2):
    return num(x, casas) + " p.p."


def pct(x, casas=1):
    return "—" if x is None or x == "" else num(x, casas) + "%"


def tabela(colunas, linhas, legenda=None):
    titulo = f"<caption>{escape(legenda)}</caption>" if legenda else ""
    cab = "".join(f"<th scope='col'>{c}</th>" for c in colunas)
    corpo = "".join("<tr>"+"".join(f"<td>{v}</td>" for v in linha)+"</tr>" for linha in linhas)
    return f"<div class='scroll'><table>{titulo}<thead><tr>{cab}</tr></thead><tbody>{corpo}</tbody></table></div>"


def resumo():
    return json.loads((DADOS / "votos_vizinhas_resumo.json").read_text(encoding="utf-8"))


def leitura_principal(rs):
    a, b = rs["1"], rs["2"]
    return (f"<p class='lead'><strong>Em geral, as seções com repetição de títulos de mesário votaram de forma semelhante às vizinhas.</strong> "
            "Entre as seções com repetição que tinham vizinhas de comparação, "
            f"<strong>{pct(100-a['extremos']['pct_acima'])} no primeiro turno e {pct(100-b['extremos']['pct_acima'])} "
            "no segundo</strong> ficaram dentro da faixa que abrange 95% das diferenças observadas entre as vizinhas de referência.</p>"
            f"<p>No primeiro turno, a distância média entre os percentuais de votos das seções com repetição e os de suas vizinhas "
            f"foi de <strong>{pp(a['distancia']['media'])}</strong>. Entre as seções de referência, a média foi de {pp(a['referencia']['media'])}. "
            f"No segundo turno, as médias foram <strong>{pp(b['distancia']['media'])}</strong> e {pp(b['referencia']['media'])}, respectivamente.</p>")


def sinal(valor, casas=3):
    if valor is None:
        return "—"
    return ("+" if valor > 0 else "−" if valor < 0 else "") + num(abs(valor), casas)


def faixa(limites):
    return " a ".join(sinal(x) for x in limites) + " p.p."


def probabilidade(p):
    return "&lt; 0,0001" if p < .0001 else num(p, 4)


def teste_na_margem(grupo, margem):
    return next(t for t in grupo["tost"] if t["margem_pp"] == margem)


def conclusao_equivalencia(rs):
    grupos = [r["equivalencia"]["principal"] for r in rs.values()]
    dentro = all(max(map(abs, g["ic95_simultaneo_pp"])) < MARGEM_RELATORIO for g in grupos)
    if dentro:
        return (f"Com 95% de confiança para os dois turnos em conjunto, a diferença entre as médias "
                f"ficou dentro da margem de equivalência de <strong>±{pp(MARGEM_RELATORIO)}</strong>.")
    return "Os intervalos simultâneos de 95% ultrapassam a margem adotada em pelo menos um turno."


def nota_biometria(rs):
    cobertura = []
    for turno, r in rs.items():
        bio = r["falha_biometria"]
        base = num(bio["n"])
        if bio["n"] < r["n_comparaveis"]:
            base += " das " + num(r["n_comparaveis"])
        cobertura.append(f"No {turno}º turno, a comparação abrangeu {base} seções com repetição "
                         f"e {num(bio['n_controles'])} vizinhas distintas.")
    return ("<p>A taxa mostra a parcela dos eleitores presentes que precisaram de liberação pelo mesário porque "
            "a urna não reconheceu sua digital cadastrada. O boletim registra "
            "esses eleitores na categoria de identificação biográfica. A contagem abrange as liberações de toda a mesa. "
            "Quem não tinha biometria cadastrada consta em outra categoria. "
            f"<a href='{RESOLUCAO_TSE}'>Resolução TSE nº 23.751/2026, arts. 134, 135 e 210, XII</a>.</p>"
            "<p>O percentual das vizinhas resulta da divisão do total de liberações pelo total de comparecimentos "
            "nas vizinhas com dados disponíveis no mesmo local. " + " ".join(cobertura) + " "
            "<a href='dados/relatorio/votos_vizinhas_biometria.csv' download>Baixar as contagens de biometria por seção (CSV)</a>.</p>")


def recorte_logistico(linhas):
    with (DADOS / "em_aberto.csv").open(encoding="utf-8-sig", newline="") as f:
        casos = {(r["turno"], r["id_caso"]): r for r in csv.DictReader(f)}
    por_caso, secoes = defaultdict(list), []
    for r in linhas:
        referentes = [(r["turno"], id_caso) for id_caso in r["casos"].split(" | ")
                      if (r["turno"], id_caso) in casos]
        if referentes:
            secoes.append(r)
            for k in referentes:
                por_caso[k].append(r)
    if por_caso.keys() != casos.keys():
        raise ValueError("Cobertura das fichas em aberto diverge")
    return casos, por_caso, secoes


def indicadores_do_recorte(secoes):
    linhas = []
    for turno in ("1", "2"):
        boas = [r for r in secoes if r["turno"] == turno and r["situacao"] == "comparavel"]
        for campo, nome in (("comparecimento", "Comparecimento"), ("brancos", "Votos em branco"),
                            ("nulos", "Votos nulos"), ("falha_biometria", "Liberações após falha de biometria")):
            pares = []
            for r in boas:
                if campo in ("brancos", "nulos"):
                    percentuais = []
                    for lado in ("secao", "vizinhas"):
                        votos = sum(int(r[f"{tipo}_{lado}"]) for tipo in ("validos", "brancos", "nulos"))
                        percentuais.append(100 * int(r[f"{campo}_{lado}"]) / votos)
                    pares.append(percentuais)
                elif r[f"{campo}_secao_pct"] != "" and r[f"{campo}_vizinhas_pct"] != "":
                    pares.append((float(r[f"{campo}_secao_pct"]), float(r[f"{campo}_vizinhas_pct"])))
            medias = [pct(mean(vals), 2) for vals in zip(*pares)] if pares else ["—", "—"]
            linhas.append((f"{turno}º", nome, num(len(pares)), *medias))
    return tabela(("Turno", "Indicador", "Seções comparáveis", "Com repetição", "Vizinhas do mesmo local"), linhas)


def painel():
    rs = resumo()
    with (DADOS / "em_aberto.csv").open(encoding="utf-8-sig", newline="") as f:
        total_pendente = sum(1 for _ in csv.DictReader(f))
    comparacao = []
    indicadores = []
    for turno, r in rs.items():
        g = r["equivalencia"]["principal"]
        comparacao.append((turno + "º", f"{num(g['n_secoes'])} de {num(r['n_marcadas_universo'])}",
                           pp(r["distancia"]["media"]), pp(r["referencia"]["media"]),
                           sinal(g["diferenca_pp"]) + " p.p.", faixa(g["ic95_simultaneo_pp"])))
    for chave, nome in (("comparecimento", "Comparecimento"), ("brancos", "Votos em branco"), ("nulos", "Votos nulos"),
                        ("falha_biometria", "Liberações após falha de biometria")):
        linha = [nome]
        for turno in ("1", "2"):
            dados = rs[turno][chave]
            linha.extend([pct(dados["media_secao_pct"], 2), pct(dados["media_vizinhas_pct"], 2)])
        indicadores.append(linha)
    cobertos = sum(r["n_comparaveis"] for r in rs.values())
    universo = sum(r["n_marcadas_universo"] for r in rs.values())
    abertos = [r["equivalencia"]["em_aberto"] for r in rs.values()]
    return ("<section id='votos-vizinhas'><h2>6. Como votaram as seções com repetição de mesários?</h2>"
            "<p class='lead'><strong>A votação presidencial dessas seções acompanhou, em média, a variação habitual entre as urnas do mesmo local.</strong> "
            f"A comparação abrange {num(cobertos)} das {num(universo)} seções-turno ({pct(100*cobertos/universo)}). "
            "Cada seção entra uma vez por turno, mesmo que nela apareçam vários títulos repetidos.</p>"
            "<h3 id='votacao-por-candidatura'>Como se compara a votação de cada candidatura?</h3>"
            "<p>Para cada seção com repetição, a comparação coloca lado a lado o percentual de votos válidos da candidatura "
            "nessa seção e o percentual obtido somando os votos das urnas sem repetição no mesmo local e turno. "
            "As tabelas mostram as médias desses pares, com o mesmo peso para cada seção com repetição. "
            "Uma diferença positiva indica participação maior nas seções com repetição.</p>"
            + por_candidato(rs, incluir_indicadores=False)
            + "<p class='fine'>A diferença em pontos percentuais é calculada antes do arredondamento. No primeiro turno, "
            "os votos no número 28 integram os nulos técnicos da totalização. "
            "<a href='https://dadosabertos.tse.jus.br/pt_BR/dataset/resultados-2026/resource/01ea4ccd-f443-469c-9f29-c69ff97f7d4c'>Votação por seção do TSE</a>.</p>"
            "<h3>Quanto a votação se afastou das vizinhas?</h3>"
            "<p>A distância indica quanto os percentuais de votos válidos por candidatura diferem entre cada seção com repetição "
            "e suas vizinhas sem repetição no mesmo local e turno. "
            "A referência local mede quanto as próprias vizinhas se afastam quando avaliadas da mesma forma. "
            "A diferença entre essas duas médias indica quanto a seção com repetição destoou a mais (+) ou a menos (−), em pontos percentuais.</p>"
            + tabela(("Turno", "Seções comparáveis", "Distância média com repetição", "Referência local", "Diferença média", "Intervalo simultâneo de 95%"), comparacao)
            + f"<p>{conclusao_equivalencia(rs)} Escolhi essa margem depois de conhecer as médias. "
            "Com a margem mais exigente de ±0,10 p.p., a conclusão do primeiro turno depende da referência usada. "
            "<a href='votos_vizinhas.html#equivalencia'>Método e teste de equivalência</a>.</p>"
            f"<p>O corte que abrange 95% das diferenças de referência foi ultrapassado por {num(rs['1']['extremos']['n_acima'])} seções "
            f"no primeiro turno ({pct(rs['1']['extremos']['pct_acima'])}) e por {num(rs['2']['extremos']['n_acima'])} no segundo "
            f"({pct(rs['2']['extremos']['pct_acima'])}).</p>"
            "<h3 id='indicadores-da-secao'>Comparecimento, votos em branco, votos nulos e liberações após falha de biometria</h3>"
            "<p>A tabela abaixo apresenta o comparecimento, os votos em branco, os votos nulos e as liberações após falha de biometria "
            "nas seções com repetição e nas vizinhas do mesmo local, por turno. O comparecimento é o percentual de eleitores aptos que "
            "estiveram presentes. Brancos e nulos são percentuais do total de votos depositados. As liberações são expressas como percentual "
            "dos eleitores que compareceram. Cada seção comparável com repetição tem o mesmo peso nas médias.</p>"
            + tabela(("Indicador", "1º turno · com repetição", "1º turno · vizinhas", "2º turno · com repetição", "2º turno · vizinhas"), indicadores)
            + nota_biometria(rs)
            + f"<p><a href='votos_vizinhas.html#casos'>Ver a cobertura e os quatro indicadores nos "
            f"{num(total_pendente)} casos com deslocamento improvável que seguem sem explicação específica</a>.</p>"
            + "<h3>Subconjunto do teste de votação</h3><p>O teste exploratório usou a amostra de 37 casos sem explicação "
            "com margem de dez minutos entre os relógios. Das 70 seções-turno dessa amostra, "
            f"{num(abertos[0]['n_secoes'])} seções no primeiro turno e {num(abertos[1]['n_secoes'])} no segundo tinham referência local. "
            f"Os intervalos individuais de 95% para a diferença média foram de {faixa(abertos[0]['ic95_pp'])} e {faixa(abertos[1]['ic95_pp'])}, respectivamente. "
            f"<strong>A equivalência ficou inconclusiva nesse grupo</strong> para a margem de ±{pp(MARGEM_RELATORIO)}.</p>"
            "<p><a href='votos_vizinhas.html'>Abrir a análise completa das seções</a> · "
            "<a href='dados/relatorio/votos_vizinhas_equivalencia.csv' download>Baixar os testes e intervalos (CSV)</a> · "
            "<a href='dados/relatorio/votos_vizinhas_secoes.csv' download>Baixar os dados por seção (CSV)</a></p></section>")


def curva(turno, dados):
    pontos = dados["distribuicao_acumulada"]
    def x(k): return 49 + k / 20 * 355
    def y(p): return 181 - p / 100 * 148
    grade = "".join(f"<line x1='49' x2='404' y1='{y(v)}' y2='{y(v)}' stroke='#dbe2dd'/>"
                    f"<text x='41' y='{y(v)+4}' text-anchor='end'>{v}%</text>" for v in (0,25,50,75,100))
    ticks = "".join(f"<text x='{x(k)}' y='202' text-anchor='middle'>{k}</text>" for k in (0,5,10,15,20))
    series = []
    for campo, cor, estilo in (("marcadas_pct","#0a6355",""),("referencia_pct","#a04419","stroke-dasharray='5 4'")):
        pts = " ".join(f"{x(v['limiar_pp']):.2f},{y(v[campo]):.2f}" for v in pontos)
        series.append(f"<polyline points='{pts}' fill='none' stroke='{cor}' stroke-width='2.7' {estilo}/>")
    return (f"<figure><figcaption><strong>{turno}º turno</strong></figcaption><svg viewBox='0 0 430 232' role='img' "
            f"aria-label='Percentual acumulado por distância, {turno}º turno. Valores resumidos na tabela seguinte.'>"
            f"{grade}{ticks}{''.join(series)}<text x='221' y='224' text-anchor='middle'>Distância até o limite indicado (p.p.)</text>"
            "</svg></figure>")


def cobertura(rs):
    linhas = []
    for t,r in rs.items():
        linhas.append((f"{t}º", num(r["n_casos"]), num(r["n_marcadas_universo"]), num(r["n_comparaveis"]),
                       num(r["n_controles_distintos"]), num(r["n_locais_comparaveis"]), num(r["apenas_outras_marcadas"]["n"]),
                       num(r["n_sem_vizinha_elegivel"]), num(r["n_sem_bu"]+r["situacoes"].get("sem_votos_validos",0))))
    return tabela(("Turno","Casos título–turno","Seções com repetição","Com vizinhas de referência","Vizinhas de referência distintas",
                   "Locais comparáveis","Só há outras seções com repetição","Sem vizinha elegível","Sem BU ou sem voto válido"),linhas)


def distribuicao(rs):
    cab=("Turno","Medida","Com repetição","Referência local")
    linhas=[]
    for t,r in rs.items():
        for chave,rotulo in (("media","Média"),("mediana","Mediana"),("p90","Percentil 90"),("p95","Percentil 95")):
            linhas.append((f"{t}º",rotulo,pp(r["distancia"][chave]),pp(r["referencia"][chave])))
    extremos=tabela(("Turno","Corte do percentil 95 de referência","Com repetição acima do corte","% com repetição","% da referência acima"),
                    [(f"{t}º",pp(r["extremos"]["limiar_p95_ref_pp"]),num(r["extremos"]["n_acima"]),
                      pct(r["extremos"]["pct_acima"],2),pct(r["extremos"]["pct_referencia_acima"],2)) for t,r in rs.items()])
    return ("<div class='legenda'><span class='marcada'>Com repetição</span><span class='referencia'>Referência local</span></div>"
            "<div class='curvas'>"+ "".join(curva(t,r) for t,r in rs.items())+"</div>"
            + tabela(cab,linhas)+extremos)


def por_candidato(rs, incluir_indicadores=True):
    from boletins_vizinhas import NOMES_CANDIDATOS
    tabelas = []
    colunas = ("Candidatura ou indicador" if incluir_indicadores else "Candidatura",
               "Seções com repetição", "Vizinhas do mesmo local", "Diferença (p.p.)")
    for turno, r in rs.items():
        grupos = [(f"{numero} · {escape(NOMES_CANDIDATOS[int(turno)][numero])}", medidas)
                  for numero, medidas in r["candidatos"].items()]
        grupos.sort(key=lambda item: -item[1]["media_secao_pct"])
        if incluir_indicadores:
            grupos.extend((("Brancos", r["brancos"]), ("Nulos", r["nulos"]), ("Comparecimento", r["comparecimento"]),
                           ("Liberações após falha de biometria", r["falha_biometria"])))
        linhas = [(nome, pct(m["media_secao_pct"], 4), pct(m["media_vizinhas_pct"], 4), sinal(m["diferenca_media_pp"], 4))
                  for nome, m in grupos]
        tabelas.append(tabela(colunas, linhas, legenda=f"{turno}º turno · {num(r['n_comparaveis'])} seções comparáveis"))
    return "<div class='comparacao-candidaturas'>" + "".join(tabelas) + "</div>"


def permutacao(rs):
    linhas = []
    for t,r in rs.items():
        p = r["permutacao"]
        linhas.append((f"{t}º",pp(p["observado_pp"],3),pp(p["esperado_pp"],3),pp(p["excesso_pp"],3),
                       f"{num(p['p025_pp'],3)} a {pp(p['p975_pp'],3)}",num(p["p_superior"],4)))
    return tabela(("Turno","Média observada","Média esperada","Observada − esperada","Faixa central dos sorteios (95%)","p para excesso"),linhas)


def grafico_equivalencia(rs):
    # O mesmo eixo representa os dois turnos e os limites de equivalência.
    grupos = [r["equivalencia"]["principal"] for r in rs.values()]
    escala = 1.20 * max(MARGEM_RELATORIO, *(abs(v) for g in grupos for v in g["ic95_simultaneo_pp"]))
    def x(v):
        return 210 + 145 * v / escala
    esquerda, direita = x(-MARGEM_RELATORIO), x(MARGEM_RELATORIO)
    desenho = [f"<rect x='{esquerda:.2f}' y='10' width='{direita-esquerda:.2f}' height='74' fill='#dceee5'/>"]
    for valor in (-MARGEM_RELATORIO, 0, MARGEM_RELATORIO):
        pos = x(valor)
        desenho.append(f"<path d='M{pos:.2f} 10v75' stroke='#688274' stroke-dasharray='3 3'/>"
                       f"<text x='{pos:.2f}' y='104' text-anchor='middle'>{sinal(valor,2) if valor else '0'}</text>")
    for (turno, _), g, y in zip(rs.items(), grupos, (30, 65), strict=True):
        a, b = map(x, g["ic95_simultaneo_pp"])
        desenho.append(f"<text x='4' y='{y+5}'>{turno}º turno</text>"
                       f"<path d='M{a:.2f} {y-5}v10 M{a:.2f} {y}H{b:.2f} M{b:.2f} {y-5}v10' stroke='#174a3c' stroke-width='2'/>"
                       f"<circle cx='{x(g['diferenca_pp']):.2f}' cy='{y}' r='4' fill='#174a3c'/>")
    return ("<figure class='intervalos'><figcaption>Diferença média em pontos percentuais</figcaption>"
            "<svg viewBox='0 0 375 113' role='img' aria-label='Estimativas e intervalos simultâneos de confiança de 95% dos dois turnos. Valores na tabela seguinte.'>"
            + "".join(desenho) + "</svg><p class='nota'>O ponto marca a média, a linha mostra o intervalo de confiança "
            "e o fundo verde indica a margem adotada.</p></figure>")


def secao_equivalencia(rs):
    principal, sensibilidade, robustez = [], [], []
    for turno, r in rs.items():
        grupos = r["equivalencia"]
        g = grupos["principal"]
        teste = teste_na_margem(g, MARGEM_RELATORIO)
        principal.append((turno+"º", num(g["n_secoes"]), num(g["n_locais"]), sinal(g["diferenca_pp"])+" p.p.",
                          faixa(g["ic95_pp"]), faixa(g["ic95_simultaneo_pp"]), probabilidade(teste["p_tost"])))
        for t in g["tost"]:
            sensibilidade.append((turno+"º", "±"+pp(t["margem_pp"]), probabilidade(t["p_tost"]),
                                  "Sim" if t["equivalente_5pct"] else "Inconclusivo",
                                  "Sim" if max(map(abs, g["ic95_simultaneo_pp"])) < t["margem_pp"] else "Não"))
        for nome, rotulo in (("por_municipio","Agrupamento por município"),("independente","Referência só de controles")):
            k = grupos[nome]
            robustez.append((turno+"º",rotulo,num(k["n_conglomerados"]),num(k["n_secoes"]),
                             sinal(k["diferenca_pp"])+" p.p.",faixa(k["ic95_pp"]),
                             probabilidade(teste_na_margem(k,MARGEM_RELATORIO)["p_tost"])))
    limites = " e ".join(f"{pp(ceil(100*r['equivalencia']['principal']['ic95_simultaneo_pp'][1])/100)} no {t}º turno"
                         for t,r in rs.items())
    return ("<section id='equivalencia'><h2>Quanto a votação pode destoar da variação habitual?</h2>"
            "<p>Para cada seção com repetição, o teste mede a diferença entre sua distância às vizinhas e a distância média "
            "observada quando uma vizinha ocupa seu lugar. Zero indica o mesmo grau de variação. Um valor positivo indica que as seções "
            "com repetição destoaram mais, em média. A unidade é o ponto percentual da distância entre os perfis de votação.</p>"
            f"<p>Escolhi a margem de equivalência de <strong>±{pp(MARGEM_RELATORIO)}</strong> após conhecer as médias descritivas. "
            "Essa margem admite até um quarto de ponto percentual de diferença na distância média, diante de uma variação habitual "
            "de cerca de 3 a 5 pontos. A tabela de sensibilidade mostra o resultado com outras margens.</p>"
            f"<p>{conclusao_equivalencia(rs)} O limite superior para quanto as seções com repetição destoaram a mais, "
            f"em média, ficou abaixo de <strong>{limites}</strong>.</p>"
            + grafico_equivalencia(rs)
            + tabela(("Turno","Seções","Locais","Diferença média","IC de 95% do turno",
                      "IC simultâneo de 95% para os dois turnos","p de equivalência (±0,25 p.p.)"),principal)
            + "<p>Os intervalos simultâneos cobrem em conjunto as duas estimativas, uma para cada turno. "
            "O ajuste de Bonferroni admite dependência entre os turnos. O cálculo da incerteza agrupa as seções por local "
            "de votação porque elas podem compartilhar as mesmas vizinhas.</p>"
            "<details><summary>Como funciona o teste e o que muda com outra margem</summary>"
            "<p>O teste de equivalência usa dois testes unilaterais (TOST), ao nível de 5%. Para concluir pela equivalência, "
            "é preciso haver evidência tanto de que a diferença média excede o limite inferior quanto de que fica abaixo do superior. "
            "O p de equivalência é o maior dos dois valores de p. A conclusão requer p inferior a 0,05 e corresponde a um "
            "intervalo bilateral de 90% inteiramente dentro da margem para aquele turno. "
            "A última coluna abaixo aplica o critério mais exigente dos intervalos simultâneos mostrados no gráfico.</p>"
            + tabela(("Turno","Margem","p de equivalência","Equivalência pelo TOST a 5%","IC simultâneo inteiro na margem"),sensibilidade)
            + "<p>Com a margem de ±0,10 p.p., o primeiro turno fica perto do limite. O TOST principal indica equivalência, "
            "mas o intervalo simultâneo ultrapassa +0,10 p.p. e o TOST com a referência formada só por controles é inconclusivo nessa margem.</p>"
            "<p>O erro-padrão robusto permite correlação entre seções do mesmo local e trata os locais como independentes. "
            "O cálculo usa a distribuição t com um grau de liberdade a menos que o número de grupos. Cada um dos dois intervalos "
            "simultâneos tem cobertura individual de 97,5%. A primeira verificação de sensibilidade agrupa as seções por município, "
            "para levar em conta relações entre locais próximos. A segunda compara a seção com repetição e uma vizinha com a mesma "
            "base de outras seções sem repetição. Nos dois turnos, ambas as verificações sustentam a margem de ±0,25 p.p.</p>"
            + tabela(("Turno","Verificação","Grupos","Seções","Diferença média","IC de 95% do turno","p (±0,25 p.p.)"),robustez)
            + "<p><a href='https://doi.org/10.1007/BF01068419'>Schuirmann, método TOST</a> · "
            "<a href='https://cameron.econ.ucdavis.edu/research/Cameron_Miller_JHR_2015_February.pdf'>Cameron e Miller, inferência por conglomerados</a>.</p></details>"
            "<p>Os boletins cobrem todas as seções comparáveis deste recorte. A média observada é conhecida. O intervalo expressa "
            "a incerteza sobre o padrão médio em locais comparáveis sob as hipóteses do modelo. Uma urna individual pode se afastar "
            "bem mais das vizinhas. A votação de um candidato e a margem de vitória são medidas diferentes da distância testada aqui.</p>"
            "<p><a href='dados/relatorio/votos_vizinhas_equivalencia.csv' download>Baixar estimativas, intervalos e testes para as três margens (CSV)</a></p></section>")


def sensibilidade(rs):
    return tabela(("Turno","Seções com repetição comparáveis","Média com repetição","Média de referência","Acima do P95 de referência"),
                  [(f"{t}º",num(s["n_comparaveis"]),pp(s["distancia"]["media"]),pp(s["referencia"]["media"]),pct(s["extremos"]["pct_acima"]))
                   for t,r in rs.items() for s in [r["sensibilidade_100"]]])


def linha_grupo(nome,turno,linhas):
    boas=[r for r in linhas if r["situacao"]=="comparavel"]
    valores=[float(r["distancia_pp"]) for r in boas]
    return (nome,f"{turno}º",num(len(linhas)),num(len(boas)),pp(mean(valores)) if boas else "—",
            pp(mean(float(r["referencia_media_pp"]) for r in boas)) if boas else "—",
            pp(median(valores)) if boas else "—")


def recortes(linhas, casos, abertos):
    grupos,ufs=defaultdict(list),defaultdict(list)
    obrigatorios = {"M-D811615A470E","M-9E8E183333B2"}
    for r in linhas:
        for g in r["grupos"].split(" | "): grupos[g,r["turno"]].append(r)
        ufs[r["uf"],r["turno"]].append(r)
    medidas=("Grupo","Turno","Seções com repetição","Comparáveis","Distância média","Referência média","Mediana da distância")
    quadro=tabela(medidas[:4], [(g, t+"º", num(len(rs)), num(sum(r["situacao"] == "comparavel" for r in rs)))
                                for (g,t),rs in sorted(grupos.items())])
    regioes=tabela(("UF",*medidas[1:]),[linha_grupo(uf,t,rs) for (uf,t),rs in sorted(ufs.items())])
    casos_linhas, destaques=[],[]
    for chave,d in casos.items():
        ident=d["id_caso"]
        rs=abertos[chave]; boas=[r for r in rs if r["situacao"]=="comparavel"]
        casos_linhas.append((f"<a href='relatorio.html#listas-f-{d['turno']}-{ident.lower()}'>{escape(d['municipios'])}</a>",
                             d["titulo"],d["turno"]+"º",num(len(boas))+" de "+num(len(rs))))
        if ident in obrigatorios:
            for r in rs:
                ok=r["situacao"]=="comparavel"
                validos=int(r["validos_secao"] or 0)
                pct_local=100*int(r["votos_13_secao"])/validos if validos else None
                destaques.append((identificar(r),r["turno"]+"º",r["n_controles_validos"],pct(pct_local) if validos else "—",
                                  pct(r["pct_principal_vizinhas"]) if ok else "—",pp(r["distancia_pp"]) if ok else "—",
                                  pp(r["referencia_media_pp"]) if ok else "—"))
    return (quadro+"<details><summary>Resultados nas 27 unidades da Federação, por turno</summary>"+regioes+"</details>",
            tabela(("Seção","Turno","Vizinhas","Lula na seção","Lula nas vizinhas","Distância (todas as chapas)","Referência local"),destaques)
            +f"<details><summary>Consultar os {num(len(casos))} casos sem explicação específica</summary>"+tabela(
                ("Municípios","Título repetido","Turno","Seções comparáveis"),casos_linhas)+"</details>")


def identificar(r):
    return f"{escape(r['municipio'].title())}/{r['uf']} · Z{r['zona']} S{r['secao']}"


def extremos(linhas):
    resultado=[]
    for t in ("1","2"):
        grupo=sorted((r for r in linhas if r["turno"]==t and r["situacao"]=="comparavel"),
                     key=lambda r:(-float(r["distancia_pp"]),r["uf"],r["secao"]))[:5]
        for r in grupo:
            fonte=f"<a href='{escape(r['url_bu'],quote=True)}'>BU oficial</a>"
            resultado.append((t+"º",identificar(r),escape(r["estabelecimento"].title()),num(r["validos_secao"]),
                              num(r["n_controles_validos"]),num(r["validos_vizinhas"]),pp(r["distancia_pp"]),fonte))
    return tabela(("Turno","Seção","Local","Válidos na seção","Vizinhas","Válidos nas vizinhas","Distância","Fonte"),resultado)


ESTILO = """
:root{--ink:#19322c;--muted:#465e56;--rule:#cbd9d1;--paper:#fbfcf8;--verde:#075d50}
*{box-sizing:border-box}body{margin:0;font:16px/1.57 'Segoe UI',Arial,sans-serif;color:var(--ink);background:var(--paper)}
header{background:#163f38;color:white}main,header>div,footer{max-width:1120px;margin:auto;padding:1.4rem clamp(1rem,4.5vw,3.75rem)}
header>div{padding-block:2rem}header a{color:#daeee3}h1,h2,h3{font-family:Georgia,serif;font-weight:normal;line-height:1.14;letter-spacing:-.02em}
h1{font-size:clamp(2.1rem,4.7vw,3.6rem);margin:.65rem 0 .3rem;max-width:26ch}h2{font-size:clamp(1.65rem,3vw,2.35rem);margin:0 0 .75rem}h3{font-size:1.4rem;margin:1.4rem 0 .5rem}
p,li{max-width:88ch}p{margin:.5rem 0 .8rem}a,summary{color:var(--verde);text-underline-offset:3px}
section{border-top:1px solid var(--rule);padding:1.65rem 0}.lead{font-size:1.16rem}section:first-of-type{border-top:0}
nav,footer{display:flex;flex-wrap:wrap;gap:.35rem 1.2rem}nav{font-size:.94rem;padding:.35rem 0 .8rem}aside{background:#edf3ec;border-left:3px solid #47785e;padding:.65rem 1rem;margin:1.1rem 0}
.scroll{max-width:100%;overflow-x:auto;margin:.9rem 0 1.2rem}table{width:100%;border-collapse:collapse;font-size:.92rem;font-variant-numeric:tabular-nums}
td,th{text-align:left;vertical-align:top;padding:.47rem .56rem;border-bottom:1px solid var(--rule)}th{font-weight:650;background:#eef3ed}
.comparacao-candidaturas caption{text-align:left;font-weight:650;padding:.4rem 0}
.comparacao-candidaturas :is(td,th):not(:first-child){text-align:right}
details{margin:1rem 0}summary{cursor:pointer;font-weight:600}.curvas{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.4rem}
figure{margin:0}figure svg{width:100%;height:auto;display:block}figure svg text{font:12px 'Segoe UI',Arial,sans-serif;fill:var(--muted)}
.intervalos{max-width:570px;margin:1rem 0}.intervalos figcaption{font-weight:600}.intervalos svg text{font-size:14px}
.legenda{display:flex;flex-wrap:wrap;gap:1.3rem;margin:1.15rem 0 .6rem}.legenda span:before{content:'';display:inline-block;width:2rem;border-top:3px solid #0a6355;vertical-align:middle;margin-right:.4rem}
.legenda .referencia:before{border-color:#a04419;border-top-style:dashed}.nota{color:var(--muted);font-size:.93rem}code{font-variant-numeric:tabular-nums}
@media(max-width:620px){.curvas{grid-template-columns:1fr}figure svg text{font-size:16px}td,th{padding:.36rem}.lead{font-size:1.06rem}}@media print{nav,footer{display:none}.scroll{overflow:visible}section{break-inside:auto}figure{break-inside:avoid}}
"""


def gerar():
    rs=resumo()
    with (DADOS/"votos_vizinhas_secoes.csv").open(encoding="utf-8-sig", newline="") as f:
        linhas=list(csv.DictReader(f))
    casos, por_caso, abertas = recorte_logistico(linhas)
    grupos, especiais=recortes(linhas, casos, por_caso)
    incluidos=sum(r["n_comparaveis"] for r in rs.values())
    universo=sum(r["n_marcadas_universo"] for r in rs.values())
    pares=[]
    for t,r in rs.items():
        boas=[l for l in linhas if l["turno"]==t and l["situacao"]=="comparavel"]
        mais_de_uma=[l for l in boas if int(l["n_controles_validos"])>=2]
        pares.append((t+"º",num(len(boas)-len(mais_de_uma)),num(len(mais_de_uma)),
                      pp(mean(float(l["distancia_pp"]) for l in mais_de_uma)),
                      pp(mean(float(l["referencia_media_pp"]) for l in mais_de_uma))))
    uma_vizinha=tabela(("Turno","Com uma única vizinha","Com duas ou mais","Média com duas ou mais","Referência com duas ou mais"),pares)
    independente=tabela(("Turno","Seções com repetição","Locais","Distância da seção com repetição","Distância da vizinha à mesma base","Diferença"),
                        [(t+"º",num(c["n_marcadas"]),num(c["n_locais"]),pp(c["media_marcadas_pp"]),pp(c["media_controles_pp"]),pp(c["diferenca_pp"]))
                         for t,r in rs.items() for c in [r["controles_independentes"]]])
    comparaveis_abertas=[r for r in abertas if r["situacao"]=="comparavel"]
    cobertos=sum(any(r["situacao"] == "comparavel" for r in lista) for lista in por_caso.values())
    por_turno=[]
    perm_abertas=[]
    for t in ("1","2"):
        sub=[r for r in comparaveis_abertas if r["turno"]==t]
        por_turno.append(f"{len(sub)} de {sum(r['turno'] == t for r in abertas)} seções no {t}º turno")
        perm_abertas.append(f"{num(rs[t]['casos_em_aberto']['permutacao']['p_superior'],4)} no {t}º turno")
    ic_abertos = " e ".join(f"{faixa(r['equivalencia']['em_aberto']['ic95_pp'])} no {t}º turno" for t,r in rs.items())
    medias_supl=" e ".join(f"{num(r['apenas_outras_marcadas']['n'])} seções no {t}º turno, com média de {pp(r['apenas_outras_marcadas']['media'])}" for t,r in rs.items())
    fonte_final = DADOS / "votos_vizinhas_conferencia.json"
    verificacao = ""
    if fonte_final.exists():
        ver = json.loads(fonte_final.read_text(encoding="utf-8"))
        if ver.get("texto_relatorio"):
            verificacao = (f"<p>{escape(ver['texto_relatorio'])} <a href='{escape(ver['pagina_recurso_votacao_secao_tse'],quote=True)}'>"
                           f"Votação por seção do TSE</a> · <a href='dados/relatorio/{fonte_final.name}'>Conferência das fontes</a>.</p>")
    pagina=f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Votos nas seções com repetição de mesários · Eleições presidenciais de 2026</title><style>{ESTILO}</style></head><body>
<header><div><a href="relatorio.html#votos-vizinhas">Relatório dos títulos de mesário repetidos</a><h1>Como votaram as seções com repetição de mesários?</h1>
<p>Eleições presidenciais de 2026 · Primeiro e segundo turnos · Brasil, excluído o exterior</p></div></header>
<main><nav aria-label="Conteúdo"><a href="#resultado">Resultado geral</a><a href="#equivalencia">Teste de equivalência</a><a href="#abrangencia">Cobertura</a><a href="#distribuicao">Distribuição</a>
<a href="#chapas">Votos por candidato</a><a href="#robustez">Testes de robustez</a><a href="#casos">Casos em aberto</a><a href="#fontes">Dados e fontes</a></nav>
<section id="resultado"><h2>O resultado geral</h2>
{leitura_principal(rs)}
<p>A comparação direta cobriu <strong>{num(incluidos)} de {num(universo)} seções-turno ({pct(100*incluidos/universo)})</strong>.
Uma unidade é uma seção em um turno. A mesma seção em outra data conta novamente, com o boletim e os controles daquele dia.</p>
<p>Houve exceções nos dois turnos. Elas representaram {pct(rs['1']['extremos']['pct_acima'])} e {pct(rs['2']['extremos']['pct_acima'])} das seções comparáveis, perto dos 5% esperados pelo corte descritivo. A lista completa permite identificar cada uma e conferir o respectivo boletim.</p></section>
{secao_equivalencia(rs)}
<section id="abrangencia"><h2>Quais urnas entram na comparação?</h2>
<p>O relatório de origem reúne 11.866 pares de título e turno. Uma seção integra o grupo com repetição quando algum título registrado na sua equipe de mesários também aparece na equipe de outra seção no mesmo turno. Cada seção entra uma vez, mesmo quando há vários títulos repetidos.
As vizinhas pertencem ao mesmo estabelecimento no cadastro do TSE para o turno e compartilham UF, município, zona e código de local. A referência principal reúne vizinhas sem repetição conhecida e com votos para candidatos no boletim.</p>
{cobertura(rs)}
<p>O boletim de cada seção principal entra uma única vez e já inclui as seções agregadas. Os registros das urnas de contingência mostram outras 13 repetições. Uma seção adicional do primeiro turno aparece apenas nessa lista e fica fora do grupo de controle.</p>
<p>Nos locais em que todas as seções elegíveis apresentavam repetição, a distância foi calculada entre as próprias seções com repetição ({medias_supl}).
Ali é possível comparar vizinhas entre si. Falta, porém, a referência de uma seção do mesmo local sem repetição, necessária para relacionar a diferença à marcação.</p></section>
<section id="distribuicao"><h2>Quanto variam as urnas de um mesmo local?</h2>
<p>O percentual de cada chapa nas vizinhas corresponde à soma de seus votos nessas urnas dividida pelo total de votos válidos do conjunto. A <strong>distância de variação total</strong> é a metade da soma das diferenças absolutas entre os percentuais de cada chapa na seção com repetição e nas vizinhas. Ela varia de 0 a 100 pontos percentuais (p.p.). No segundo turno, coincide com a diferença absoluta de participação de qualquer um dos dois candidatos. No primeiro, leva em conta as 12 chapas com votos válidos na totalização.</p>
<p>Para medir a variação habitual no local, cada vizinha ocupa, por sua vez, o lugar da seção com repetição. Nesse cálculo, a comparação inclui todas as outras seções do conjunto, inclusive a que tem repetição. A seção com repetição e cada vizinha têm, assim, o mesmo número de seções de comparação. A média das referências de cada seção com repetição tem o mesmo peso que a distância observada nessa seção.</p>
<p>As curvas mostram a parcela das seções cuja distância ficou até o valor do eixo horizontal. Quanto mais próximas as curvas, mais parecidas são as duas distribuições.</p>
{distribuicao(rs)}<p class="nota">O percentil 95 é um corte descritivo. Mesmo entre seções de referência há resultados acima dele.</p></section>
<section id="chapas"><h2>As diferenças favorecem algum candidato?</h2>
<p>As tabelas mostram, por turno, a média dos percentuais de cada candidatura nas seções com repetição e a média dos percentuais nas respectivas vizinhas. Cada seção com repetição tem o mesmo peso nas duas colunas. Um valor positivo na última coluna indica participação média maior nas seções com repetição.</p>
<p>Os percentuais das candidaturas têm como base os votos válidos. No primeiro turno, os boletins trazem 13 números de candidatos. Os votos no número 28 integram os nulos técnicos na totalização do TSE e entram na contagem de nulos das tabelas. Brancos e nulos têm como base o total de votos depositados. O comparecimento é o percentual de eleitores aptos que compareceram. As liberações após falha de biometria aparecem como percentual dos eleitores presentes. O CSV de boletins conserva os números originais da urna.
<a href="https://cdn.tse.jus.br/estatistica/sead/odsele/relatorio_resultado_totalizacao/Relatorio_Resultado_Totalizacao_2026_BR.zip">Relatório de totalização do TSE, 1º turno, pp. 3–4</a>.</p>
{por_candidato(rs)}
{nota_biometria(rs)}
<p class="nota">Na base de boletins do TSE, a coluna <code>QT_ELEI_BIOM_SEM_HABILITACAO</code> informa quantos eleitores com biometria cadastrada votaram sem reconhecimento da digital.
No QR Code do boletim, a contagem de liberações após falha corresponde ao campo <code>HBBG</code>.
Ele conta cada eleitor habilitado pelo ano de nascimento após falha no reconhecimento da digital.
O campo <code>HBSB</code> reúne os eleitores sem biometria cadastrada.
<a href="{TSE}">Base e dicionário de dados dos boletins</a> · <a href="{MANUAL_QR_BU}#page=16">Manual do QR Code do boletim de urna, p. 16</a>.</p></section>
<section id="robustez"><h2>O que acontece se a marcação mudar de seção?</h2>
<p>Em cada local, o sorteio redistribui a marcação de repetição entre as seções. A quantidade de seções marcadas e os votos de cada urna permanecem os mesmos. O teste mede a distância de cada seção ao conjunto de <em>todas</em> as demais do local, inclusive outras marcadas. A comparação principal usa como referência as vizinhas sem repetição.</p>
{permutacao(rs)}
<p>Nos dois turnos, a média observada ficou dentro da faixa central de 95% das simulações. O teste não apontou excesso geral de discrepância ao nível de 5%. Ele também não demonstra igualdade exata das distribuições. O tamanho das diferenças está expresso em pontos percentuais no quadro.</p>
<p>A simulação compreende {num(rs['1']['permutacao']['n_permutacoes'])} sorteios por turno. O valor de p é unilateral para <em>excesso</em> de distância, com correção de uma unidade no numerador e no denominador. A faixa de 95% é a distribuição das médias simuladas sob troca dos rótulos dentro do local. A designação de mesários e a distribuição dos eleitores entre seções seguem processos próprios. Esse teste mede compatibilidade com a referência simulada e não estabelece causalidade.</p>
<h3>Seções com pelo menos 100 votos em candidatos</h3>
<p>A tabela inclui apenas seções com repetição e vizinhas que tiveram ao menos 100 votos válidos cada. Esse recorte permite verificar o resultado entre urnas em que um voto individual tem menos peso no percentual.</p>{sensibilidade(rs)}
<p>No primeiro turno, também é possível comparar as seções incluindo os votos do número 28 entre os nominais, conforme aparecem nos boletins. Com os 13 números nominais, a distância média passa de {pp(rs['1']['distancia']['media'],3)} para {pp(rs['1']['todos_nominais_bu']['distancia']['media'],3)} nas seções com repetição e de {pp(rs['1']['referencia']['media'],3)} para {pp(rs['1']['todos_nominais_bu']['referencia']['media'],3)} na referência.</p>
<h3>Locais com pelo menos duas vizinhas de referência</h3>
<p>Com uma só vizinha, a distância do par é a mesma nos dois sentidos. O quadro mostra o resultado quando há pelo menos duas vizinhas sem repetição.</p>{uma_vizinha}
<h3>Uma referência inteiramente independente das seções com repetição</h3>
<p>Nos locais com pelo menos duas vizinhas sem repetição, cada uma delas forma um par com a seção com repetição. As duas integrantes do par têm <strong>a mesma base</strong> de comparação, formada pelas demais urnas sem repetição. A média de cada seção reúne os resultados de todos os seus pares. A média do turno reúne as médias dessas seções.</p>{independente}</section>
<section id="casos"><h2>Os casos sem explicação específica</h2>
<p>Dos {num(len(casos))} casos com deslocamento improvável que seguem sem explicação específica, {num(cobertos)} têm pelo menos uma seção com vizinhas de referência.
São {num(len(comparaveis_abertas))} seções-turno comparáveis entre as {num(len(abertas))} envolvidas ({' e '.join(por_turno)}).</p>
{indicadores_do_recorte(abertas)}
<h3>Subconjunto do teste de votação</h3>
<p>O teste exploratório de equivalência usou a amostra de 37 casos sem explicação com margem de dez minutos entre os relógios. Essa amostra reuniu 70 seções-turno. A equivalência da votação ficou inconclusiva nesse grupo. Os intervalos individuais de confiança de 95% foram de {ic_abertos}. Os valores de p do sorteio para excesso de distância foram {' e '.join(perm_abertas)}. <a href="dados/relatorio/votos_vizinhas_amostra_teste.csv" download>Casos que compõem a amostra do teste (CSV)</a>.</p>
<p>Uma seção vinculada a casos de categorias diferentes aparece em cada categoria pertinente. No resultado geral, ela conta uma única vez.</p>
{grupos}<h3>Os dois casos interestaduais</h3><p>As quatro linhas referem-se ao turno em que cada duplicidade foi registrada. Em Barrocas, a seção 276 era a única seção principal do seu local. O próprio boletim permite calcular a votação, mas falta uma vizinha para medir a distância naquele estabelecimento.</p>{especiais}</section>
<section id="extremos"><h2>Onde estavam as maiores diferenças?</h2>
<p>A tabela apresenta as cinco maiores distâncias de cada turno entre as seções com vizinhas de referência. O número de votos ajuda a interpretar os extremos. O CSV traz todas as seções e a diferença de cada candidato. Com milhares de comparações, posições extremas são esperadas mesmo quando os resultados gerais são semelhantes. Uma diferença de porcentagem, isoladamente, não identifica sua causa.</p>
{extremos(linhas)}
<p>O controle pelo local reduz diferenças entre regiões, mas seções do mesmo estabelecimento podem reunir perfis distintos de eleitores. A comparação detecta diferenças relativas entre seções do mesmo local. Uma alteração comum a todas elas não seria distinguida por este método. Os boletins são agregados e preservam o sigilo do voto.</p></section>
<section id="fontes"><h2>Dados, fontes e reprodução</h2>
<ul><li><a href="dados/relatorio/votos_vizinhas_secoes.csv" download>Uma linha por seção com repetição e turno</a>, com os casos, a situação da comparação, os votos por chapa e, quando só havia outras seções marcadas, a distância descritiva disponível.</li>
<li><a href="dados/relatorio/votos_vizinhas_boletins.csv" download>Boletins de todas as seções dos locais estudados</a>, com contagens, chave de local, URL do BU original e SHA-256.</li>
<li><a href="dados/relatorio/votos_vizinhas_biometria.csv" download>Liberações após falha de biometria por seção</a> e <a href="biometria_vizinhas.py">script de extração</a>. Quando o boletim conserva o código do estabelecimento de origem, o cadastro do TSE identifica o local vigente da seção naquele turno, usado para selecionar as vizinhas.</li>
<li><a href="dados/relatorio/votos_vizinhas_equivalencia.csv" download>Teste de equivalência em CSV</a>, com as estimativas, os intervalos e os valores de p de cada teste.</li>
<li><a href="dados/relatorio/votos_vizinhas_resumo.json" download>Indicadores, percentis, sorteios e teste de equivalência em JSON</a>.</li></ul>
<p>As fontes da análise são os boletins oficiais da eleição presidencial de 2026, o cadastro de locais por turno e a lista de repetições do relatório da Arvor, conferida nos logs desta auditoria.
<a href="{TSE}">Boletins de urna do TSE</a> · <a href="{CADASTRO}">Cadastro de locais do TSE</a> · <a href="https://brasil.arvor.co/auditoria-2026/mesarios/relatorio.html">Relatório de origem</a>.</p>
{verificacao}
<p>Na pasta do relatório extraído, execute <code>python votos_vizinhas.py</code> com Python 3.12 para reproduzir os resultados a partir dos boletins incluídos. Para recalcular apenas o teste a partir do CSV por seção, execute <code>python equivalencia_vizinhas.py</code>.
<a href="../relatorio_mesarios_csv.zip" download>Baixar o pacote com os CSVs e os scripts</a> · <a href="votos_vizinhas.py">Cruzamento e exportação</a> · <a href="equivalencia_vizinhas.py">Teste de equivalência</a> · <a href="estatistica_vizinhas.py">Cálculos e permutação</a> · <a href="universo_vizinhas.py">Universo de seções</a> · <a href="boletins_vizinhas.py">Extração dos boletins</a>.</p></section>
</main><footer><a href="relatorio.html#votos-vizinhas">Voltar ao relatório principal</a></footer></body></html>"""
    (RAIZ/"votos_vizinhas.html").write_text(pagina,encoding="utf-8")


if __name__ == "__main__":
    gerar()
