"""Documenta o cadastro adicional de Barrocas no segundo turno."""
from html import escape

from exemplos_ilustrados import linhas


def painel_bahia_patrocinio():
    secoes = {("BA", "30775", "150", "276"): "Barrocas",
              ("SP", "68276", "46", "385"): "Patrocínio Paulista"}
    fontes = {}
    for r in linhas("manifesto.csv"):
        secao = tuple(r[c] for c in ("uf", "codigo_municipio", "zona", "secao"))
        if secao in secoes:
            fontes[secoes[secao], r["turno"]] = r["url_log"]
    links = []
    for cidade in secoes.values():
        for turno in ("1", "2"):
            url = escape(fontes[cidade, turno], quote=True)
            links.append(f'<a href="{url}">{cidade} · {turno}º turno</a>')
    imagem = "dados/registro_mesarios_bahia.png"

    return f"""
<article id="caso-barrocas-patrocinio">
<h4>Barrocas/BA e Patrocínio Paulista/SP · o quinto título na abertura</h4>
<p>Na seção 276 da zona 150 de Barrocas, os quatro primeiros títulos cadastrados na abertura de 25 de outubro
foram exatamente os quatro que voltaram no encerramento. Depois de registrar essa equipe, a urna aceitou um
quinto título, <code>033935570124</code>. Na seção 385 da zona 46 de Patrocínio Paulista, esse mesmo título
consta nos registros de abertura e de encerramento dos dois turnos.</p>
<div class="scroll"><table><thead><tr><th scope="col">Horário em Barrocas</th>
<th scope="col">O que a urna registrou no 2º turno</th><th scope="col">Linhas do log</th></tr></thead><tbody>
<tr><td>08:04:26–08:06:42</td><td>Cadastro de <code>160530110531</code>, <code>171826300523</code>,
<code>097277480574</code> e <code>118385740574</code>, nessa ordem.</td><td>5974–5992</td></tr>
<tr><td>08:07:00–08:08:50</td><td>Quatro entradas de título inválido e uma tentativa de repetir o último
mesário cadastrado.</td><td>5995–5999</td></tr>
<tr><td><strong>08:09:49</strong></td><td>A urna informou que <code>033935570124</code> não era eleitor
da seção e aceitou o número como <strong>quinto cadastro de mesário</strong>.</td><td>6001–6002</td></tr>
<tr><td>08:10:03–08:13:29</td><td>Mais sete entradas de título inválido e três tentativas de repetir
os outros três mesários já cadastrados.</td><td>6005–6014</td></tr>
<tr><td>17:01:23–17:02:57</td><td>No encerramento voltaram apenas os quatro primeiros títulos.
O quinto apareceu uma única vez como registro de mesário em Barrocas.</td><td>8803–8828</td></tr>
</tbody></table></div>
<figure>
<button type="button" class="captura-miniatura" aria-haspopup="dialog" aria-controls="captura-barrocas" aria-label="Ampliar a captura do log de Barrocas">
<img src="{imagem}" width="1889" height="881" loading="lazy"
alt="Log da urna 01768925 na abertura. A linha 6002 registra o quinto título, entre os alertas de título inválido e as tentativas de repetir mesários descritos na tabela."></button>
<figcaption>Barrocas, urna 01768925, linhas 5968–6016 de <code>logd.dat</code>. <button type="button" class="captura-ampliar" aria-haspopup="dialog" aria-controls="captura-barrocas">Ampliar a captura</button></figcaption>
</figure>
<dialog id="captura-barrocas" aria-labelledby="titulo-captura-barrocas">
<div class="captura-barra"><strong id="titulo-captura-barrocas">Log de Barrocas · abertura do 2º turno</strong>
<form method="dialog"><button type="submit" autofocus>Fechar</button></form></div>
<div class="captura-rolagem" tabindex="0" role="region" aria-label="Captura ampliada do log">
<img src="{imagem}" width="1889" height="881" loading="lazy" alt="Linhas 5968 a 6016 do log da urna 01768925. A linha 6002 registra o quinto título após os quatro cadastros iniciais.">
</div>
</dialog>
<p>Considero essa sequência evidência de mau uso da função de cadastro de mesários em Barrocas. O número
que também constava na equipe paulista entrou depois dos quatro títulos confirmados no encerramento, em meio a
11 entradas inválidas e quatro tentativas de repetir mesários. O uso indevido do título é a explicação
mais provável para esse quinto cadastro. Os registros deixam em aberto quem digitou o número e com que intenção. No segundo turno, nenhuma das
duas urnas atribuiu a esse título uma habilitação de eleitor.</p>
<p>Logs originais do TSE · {" · ".join(links)}.</p>
</article>"""
