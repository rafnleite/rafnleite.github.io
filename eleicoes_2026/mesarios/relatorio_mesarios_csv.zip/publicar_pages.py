"""Prepara a seção mesarios/ do site e os downloads distribuídos pelo GitHub.

python publicar_pages.py dados DIRETORIO_DO_ACERVO
python publicar_pages.py site DIRETORIO_ELEICOES_2026 --revisao SHA_DO_ACERVO [--acervo DIRETORIO_GIT]

A entrada é o ZIP portátil já conferido por empacotar_relatorio.py. O site leva
o próprio ZIP e os downloads novos ou alterados. Downloads idênticos aos blobs
do commit indicado podem ser servidos pelo acervo. Sem cópia Git desse commit,
os downloads são copiados do ZIP para o site.
"""
import argparse
import hashlib
import os
import posixpath
import re
import shutil
import subprocess
import tempfile
from html import escape, unescape
from pathlib import Path
from urllib.parse import quote, urlsplit
from zipfile import ZipFile

from empacotar_relatorio import ATRIBUTO, Navegacao, PAGINAS as PAGINAS_DO_PACOTE, PORTATIL, destino_local


REPOSITORIO = "rafnleite/rafnleite.github.io"
ARQUIVOS_LOCAIS = {"teste_dv_por_titulo.js", "dados/registro_mesarios_bahia.png"}
LIMITE_ARQUIVO = 100 * 1024 * 1024
LINK_PORTATIL = '<a href="relatorio.html#arquivos">Ver os CSVs incluídos neste pacote</a>'


def recursos(pacote):
    arquivos = set()
    for pagina in PAGINAS_DO_PACOTE:
        for link in Navegacao(pacote.read(pagina)).links:
            local = destino_local(pagina, link)
            if local and local[0] not in PAGINAS_DO_PACOTE:
                arquivos.add(local[0])
    return arquivos


def copiar(pacote, nome, destino):
    arquivo = destino / nome
    arquivo.parent.mkdir(parents=True, exist_ok=True)
    with pacote.open(nome) as fonte, arquivo.open("wb") as saida:
        shutil.copyfileobj(fonte, saida)


def gerar_acervo(pacote, destino):
    (destino / ".gitattributes").write_text("* -text\n", encoding="ascii")
    for nome in sorted(recursos(pacote) - ARQUIVOS_LOCAIS):
        copiar(pacote, nome, destino)
    shutil.copyfile(PORTATIL, destino / PORTATIL.name)
    (destino / "README.md").write_text(
        "# Títulos de mesário repetidos nas urnas de 2026\n\n"
        "Downloads do [relatório de Rafael Leite](https://rafnleite.github.io/eleicoes_2026/mesarios/relatorio.html). "
        "Os CSVs por seção, as fontes e os scripts também estão reunidos no pacote "
        "[relatorio_mesarios_csv.zip](relatorio_mesarios_csv.zip), que inclui as seis páginas para leitura offline.\n",
        encoding="utf-8")


def blobs_do_acervo(revisao, repositorios):
    for repo in repositorios:
        if not repo.is_dir():
            continue
        try:
            arvore = subprocess.run(
                ["git", "-C", str(repo), "ls-tree", "-rz", "--full-tree", revisao],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=True,
            ).stdout
        except (FileNotFoundError, subprocess.CalledProcessError):
            continue
        blobs = {}
        for item in arvore.split(b"\0"):
            if item:
                cabecalho, nome = item.split(b"\t", 1)
                _, tipo, blob = cabecalho.split()
                if tipo == b"blob":
                    blobs[nome.decode("utf-8")] = blob.decode("ascii")
        return blobs
    return {}


def mesmo_blob(pacote, nome, esperado):
    if not esperado:
        return False
    tamanho = pacote.getinfo(nome).file_size
    hash_git = hashlib.sha1(f"blob {tamanho}\0".encode("ascii"))
    with pacote.open(nome) as entrada:
        while bloco := entrada.read(1024 * 1024):
            hash_git.update(bloco)
    return hash_git.hexdigest() == esperado


def distribuir_downloads(pacote, pasta, blobs):
    from relogios import CSV_CASOS, CSV_TRECHOS

    resultados = {"dados/relatorio/desfechos.csv", "dados/relatorio/" + CSV_CASOS.name,
                  "dados/relatorio/" + CSV_TRECHOS.name}
    locais = ARQUIVOS_LOCAIS | resultados
    links = recursos(pacote)
    remotos = {nome for nome in links - locais if mesmo_blob(pacote, nome, blobs.get(nome))}
    locais |= links - remotos
    origem_zip = Path(pacote.filename)
    tamanhos = {nome: pacote.getinfo(nome).file_size for nome in locais}
    tamanhos[PORTATIL.name] = origem_zip.stat().st_size
    grandes = [nome for nome, tamanho in tamanhos.items() if tamanho > LIMITE_ARQUIVO]
    if grandes:
        raise ValueError("Downloads acima de 100 MiB para o GitHub Pages: " + ", ".join(grandes))
    for nome in sorted(locais):
        copiar(pacote, nome, pasta)
    with tempfile.NamedTemporaryFile(dir=pasta, suffix=".tmp", delete=False) as temporario:
        arq = Path(temporario.name)
    try:
        shutil.copyfile(origem_zip, arq)
        os.replace(arq, pasta / PORTATIL.name)
    finally:
        arq.unlink(missing_ok=True)
    return remotos


def gerar_site(pacote, destino, revisao, acervo=None):
    from compactar_pages import destinos_dos_casos, integrar_fichas, preparar_web
    from sankey_pages import ajustar_sankey
    from tema_pages import PAGINAS, aplicar_tema

    if not re.fullmatch("[0-9a-f]{40}", revisao or ""):
        raise ValueError("Informe o SHA completo do commit do acervo.")
    if not (destino / "assets/relatorio.css").is_file():
        raise ValueError("O diretório deve ser a edição eleicoes_2026 do GitHub Pages.")
    base = f"https://raw.githubusercontent.com/{REPOSITORIO}/{revisao}/"
    pasta = destino / "mesarios"
    pasta.mkdir(exist_ok=True)
    destinos = destinos_dos_casos(pacote.read("relatorio.html").decode("utf-8-sig"))
    repositorios = [acervo] if acervo is not None else [Path(__file__).resolve().parent.parent / "acervo-mesarios-pages", destino]
    remotos = distribuir_downloads(pacote, pasta, blobs_do_acervo(revisao, repositorios))
    for nome in PAGINAS:
        def link_acervo(m):
            url = urlsplit(unescape(m[3]))
            alvo = posixpath.normpath(url.path)
            if url.scheme or url.netloc or alvo not in remotos:
                return m[0]
            link = base + quote(alvo)
            if url.fragment:
                link += "#" + quote(url.fragment)
            return m[1] + m[2] + escape(link, quote=True) + m[2]

        html = pacote.read(nome).decode("utf-8-sig").replace(
            LINK_PORTATIL, f'<a href="{PORTATIL.name}" download>Baixar o relatório, os dados e os scripts (ZIP)</a>')
        if nome == "relatorio.html":
            html = integrar_fichas(html, destinos)
        elif nome == "sankey_turnos.html":
            html = ajustar_sankey(html, destinos, pacote)
        if "relatorio_tecnico.html" in html or "casos_em_aberto.html" in html:
            raise ValueError(f"Referência a página descontinuada em {nome}")
        html = ATRIBUTO.sub(link_acervo, html)
        html = preparar_web(nome, html, pasta)
        html = aplicar_tema(nome, html)
        html = html.replace("</body>", '<script defer src="../assets/mesarios-download.js"></script></body>', 1)
        html = re.sub(r"^[ \t]+$", "", html, flags=re.M)
        (pasta / nome).write_text(html, encoding="utf-8")
    for legado in ("relatorio_tecnico.html", "casos_em_aberto.html",
                   "blocos/fichas.html.gz", "blocos/casos-em-aberto-equipes.json.gz"):
        (pasta / legado).unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("modo", choices=("dados", "site"))
    parser.add_argument("diretorio", type=Path)
    parser.add_argument("--revisao")
    parser.add_argument("--acervo", type=Path, help="Repositório Git local que contém o commit indicado em --revisao")
    args = parser.parse_args()
    with ZipFile(PORTATIL) as pacote:
        if args.modo == "dados":
            args.diretorio.mkdir(parents=True, exist_ok=True)
            gerar_acervo(pacote, args.diretorio)
        else:
            gerar_site(pacote, args.diretorio, args.revisao, args.acervo)
