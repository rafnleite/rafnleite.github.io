"""Incorpora as equipes dos controles da página para consulta local, inclusive sem rede."""
from html import escape
import json
from pathlib import Path

from quadro_equipes import ESTILO, renderizar

RAIZ = Path(__file__).resolve().parent


def atributo(caso):
    chave = f"{caso['turno']}-{caso['id_caso'].lower()}"
    return f"data-equipe-prever='{escape(chave, quote=True)}'"


def botao(caso, texto, destino):
    return (f"<button type='button' class='ver-equipe' aria-haspopup='dialog' {atributo(caso)}>{escape(texto)}</button>"
            f"<noscript><a href='{escape(destino, quote=True)}'>{escape(texto)}</a></noscript>")


def componentes(listas, chaves=None, fontes=None):
    fichas = json.loads((RAIZ / "dados" / "evidencia_fichas_digitacao.json").read_bytes())
    candidatos = {(str(f["turno"]), f["titulo"]): f["alternativo"] for f in fichas}
    previas = {}
    for turno, titulo in sorted(listas if chaves is None else set(chaves)):
        mesas = listas[str(turno), titulo]
        ident = mesas[0]["id_caso"].lower()
        chave = f"{turno}-{ident}"
        if chave in previas or any(m["id_caso"].lower() != ident for m in mesas):
            raise ValueError(f"Referência ambígua para as equipes do caso {chave}")
        alternativo = candidatos.get((str(turno), titulo), "")
        fonte = fontes.get((str(turno), titulo), "") if fontes else ""
        previas[chave] = dict(turno=str(turno), titulo=titulo, alternativo=alternativo, fonte=fonte,
                              html="" if fonte else renderizar(mesas, titulo, alternativo, turno_do_caso=turno))
    dados = json.dumps(previas, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    css = (RAIZ / "tooltip_equipes.css").read_text(encoding="utf-8")
    js = (RAIZ / "tooltip_equipes.js").read_text(encoding="utf-8")
    return (f"<style>{ESTILO}{css}</style><noscript><style>.ver-equipe{{display:none}}</style></noscript>",
            f'<script type="application/json" id="equipes-para-previa">{dados}</script><script>{js}</script>')
