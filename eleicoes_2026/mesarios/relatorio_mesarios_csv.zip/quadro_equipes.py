"""Quadros de presença por turno, seção, urna e etapa, a partir dos registros confirmados."""
from collections import defaultdict
from html import escape


ESTILO = """
.eq-quadro{margin:.6rem 0 1.3rem;max-width:100%;color:#1c302e}
.eq-periodo{margin:1rem 0 .45rem;font-weight:700}
.eq-urnas{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,23rem),1fr));gap:.8rem;align-items:start}
.eq-urna{min-width:0;overflow-wrap:anywhere;border:1px solid #c4d3cb;border-radius:5px;background:#fff}
.eq-cab{padding:.55rem .7rem;background:#f1f5f0;border-bottom:1px solid #c4d3cb}
.eq-cab b,.eq-cab small{display:block}.eq-cab b{font-size:.94rem;line-height:1.3}
.eq-quadro small{font-size:.76rem;line-height:1.35;color:#405953}
.eq-quadro table{width:100%;table-layout:fixed;border-collapse:collapse;margin:0}
.eq-quadro th,.eq-quadro td{padding:.38rem .55rem;vertical-align:top;text-align:left;border:0}
.eq-quadro th{background:#fff;color:#304a41;border-bottom:1px solid #d7e1db;font-size:.83rem}
.eq-quadro td+td,.eq-quadro th+th{border-left:1px solid #d7e1db}
.eq-frente col.eq-col-par{width:2.4rem}
.eq-frente .eq-par{text-align:center;vertical-align:middle;padding-inline:.15rem}
.eq-frente td.eq-par{color:#146147;font-weight:700}
.eq-quadro tbody tr+tr td{border-top:1px solid #e5ebe7}.eq-frente small{display:block}
.eq-frente .eq-falta{color:#577067}.eq-quadro .eq-troca{background:#faf5e9}
.eq-quadro ul{list-style:none;padding:0;margin:0}.eq-quadro li{margin:0 0 .36rem;line-height:1.3}
.eq-quadro li:last-child{margin-bottom:0}.eq-quadro li small{display:block}
.eq-quadro code{font:.88rem/1.35 Consolas,"Courier New",monospace;white-space:nowrap;letter-spacing:0}
.eq-quadro .eq-repetido,.eq-quadro .eq-comparado{font-weight:700;padding:0 .12em;border-radius:2px}
.eq-quadro .eq-repetido{color:#124c3c;background:#dbeee2}.eq-quadro .eq-comparado{color:#593603;background:#f9e9c9}
.eq-eleitor{display:inline-block;padding:.03em .38em;border:1px solid #adc6d2;border-radius:3px;background:#eef5f8;color:#234e63;font:.72rem/1.35 "Segoe UI",Arial,sans-serif}
.eq-extra{padding:.45rem .6rem;border-top:1px solid #d7e1db}.eq-extra>b{font-size:.82rem}
.eq-extra ul{margin-top:.2rem}.eq-quadro .eq-vazio{padding:.15em 0;display:block}
@media(max-width:440px){.eq-quadro th,.eq-quadro td{padding:.32rem .35rem}.eq-quadro code{font-size:.82rem}}
@media print{.eq-urnas{display:block}.eq-urna{break-inside:avoid;margin-bottom:.6em}.eq-periodo{break-after:avoid}}
"""


def h(valor):
    return escape(str(valor), quote=True)


def indicador_eleitor(evento):
    if evento.get("eleitor_da_secao") != "sim":
        return ""
    linha = evento["linha_eleitor_da_secao"]
    return f" <span class='eq-eleitor' title='Vínculo informado pela urna na linha {h(linha)} do log'>Eleitor da seção</span>"


def titulos_da_etapa(eventos, titulo, alternativo, varios_dias, varios_membros):
    por_titulo = defaultdict(list)
    marcadores = {(e["data_hora"][:10], e["membro"], e["linha_marcador"]) for e in eventos}
    for evento in eventos:
        por_titulo[evento["titulo"]].append(evento)
    itens = {}
    for numero, registros in por_titulo.items():
        destaque = ""
        rotulo = ""
        if numero == titulo:
            destaque, rotulo = " class='eq-repetido'", "Título repetido"
        elif numero == alternativo:
            destaque, rotulo = " class='eq-comparado'", "Título alternativo"
        fontes = []
        for e in registros:
            hora = e["data_hora"] if varios_dias else e["data_hora"][11:]
            membro = h(e["membro"]) + " · " if varios_membros else ""
            fonte = f"{h(hora)} · {membro}L{h(e['linha'])}"
            if len(marcadores) > 1 and e["linha_marcador"]:
                fonte += f" · marcador L{h(e['linha_marcador'])}"
            fontes.append(fonte + indicador_eleitor(e))
        etiqueta = f"<small>{rotulo}</small>" if rotulo else ""
        itens[numero] = f"<code{destaque}>{h(numero)}</code>{etiqueta}<small>{'<br>'.join(fontes)}</small>"
    return itens


def linhas_das_equipes(abertura, encerramento, titulo, alternativo):
    falta = "<span class='eq-falta' aria-label='Sem registro nesta etapa'>—</span>"
    def linha(a, b, classe=""):
        marca = "<span role='img' aria-label='Mesmo título nas duas etapas'>✓</span>" if a is not None and a == b else ""
        return (f"<tr{classe}><td>{abertura.get(a, falta)}</td>"
                f"<td class='eq-par'>{marca}</td><td>{encerramento.get(b, falta)}</td></tr>")
    comuns = [n for n in abertura if n in encerramento]
    antes = [n for n in abertura if n not in encerramento]
    depois = [n for n in encerramento if n not in abertura]
    pares = [linha(n, n) for n in comuns]
    for sai, entra in ((alternativo, titulo), (titulo, alternativo)):
        if sai in antes and entra in depois:
            pares.append(linha(sai, entra, " class='eq-troca'"))
            antes.remove(sai)
            depois.remove(entra)
            break
    pares.extend(linha(n, None) for n in antes)
    pares.extend(linha(None, n) for n in depois)
    return "".join(pares) or "<tr><td colspan='3'>Sem presença registrada na abertura ou no encerramento.</td></tr>"


def cartao(mesa, serie, eventos, dias, titulo, alternativo):
    local = f"{h(mesa['municipio'].title())}/{h(mesa['uf'])} · Zona {h(mesa['zona'])} · Seção {h(mesa['secao'])}"
    nome = h(mesa["nome"])
    arquivo = f"<a href='{h(mesa['url_log'])}'>Log do TSE</a>" if mesa.get("url_log") else ""
    membros = sorted({e["membro"] for e in eventos})
    referencia = [f"Urna {h(serie)}"] if serie else []
    if len(membros) == 1:
        referencia.append(h(membros[0]))
    if arquivo:
        referencia.append(arquivo)
    cab = (f"<div class='eq-cab'><b>{local}</b><small>{nome}</small>"
           f"<small>{' · '.join(referencia)}</small></div>")
    cartao_html = (f"<div class='eq-urna' data-uf='{h(mesa['uf'])}' data-municipio='{h(mesa['codigo_municipio'])}' "
                   f"data-zona='{h(mesa['zona'])}' data-secao='{h(mesa['secao'])}' data-turno='{h(mesa['turno'])}' "
                   f"data-serie='{h(serie)}'>{cab}")
    if not mesa.get("disponivel", True):
        return cartao_html+"<div class='eq-extra'>Arquivo de urna indisponível no acervo consultado.</div></div>"
    if not eventos:
        return cartao_html+"<div class='eq-extra'>O arquivo consultado não contém registro confirmado de presença para esta urna.</div></div>"
    etapas = defaultdict(list)
    for e in eventos:
        etapas[e["etapa"]].append(e)
    varios_dias = len(dias) > 1
    varios_membros = len(membros) > 1
    def lista(etapa):
        return titulos_da_etapa(etapas.get(etapa, ()), titulo, alternativo, varios_dias, varios_membros)
    titulos = ("abertura", "encerramento")
    colunas = ("<th scope='col'>Abertura</th>"
               "<th scope='col' class='eq-par' title='Mesmo título na abertura e no encerramento'>Par</th>"
               "<th scope='col'>Encerramento</th>")
    linhas = linhas_das_equipes(lista("abertura"), lista("encerramento"), titulo, alternativo)
    outras = []
    for etapa in etapas:
        if etapa in titulos:
            continue
        rotulo = "Etapa sem marcador identificado" if etapa == "indeterminada" else etapa.capitalize()
        itens = "".join(f"<li>{item}</li>" for item in lista(etapa).values())
        outras.append(f"<div class='eq-extra'><b>{h(rotulo)}</b><ul>{itens}</ul></div>")
    return (f"{cartao_html}<table class='eq-frente'><colgroup><col><col class='eq-col-par'><col></colgroup>"
            f"<thead><tr>{colunas}</tr></thead><tbody>{linhas}"
            f"</tbody></table>{''.join(outras)}</div>")


def renderizar(grupos, titulo, alternativo=None, *, turno_do_caso=None):
    """Compara mesas no formato de listas_equipes.carregar_listas(), sem dependência de JavaScript."""
    por_turno = defaultdict(list)
    for mesa in grupos:
        por_turno[int(mesa["turno"])].append(mesa)
    turno_caso = int(turno_do_caso) if turno_do_caso is not None else None
    blocos = []
    for turno in sorted(por_turno, key=lambda t: (t != turno_caso, t)):
        mesas = sorted(por_turno[turno], key=lambda s: (s["uf"], s["municipio"], int(s["zona"]), int(s["secao"])))
        dias = sorted({e["data_hora"][:10] for mesa in mesas for e in mesa["registros"]})
        rotulo = f"{turno}º turno"
        if dias:
            rotulo += " · " + " e ".join(h(dia) for dia in dias)
        if turno_caso is not None and len(por_turno) > 1:
            rotulo += " · Turno do caso" if turno == turno_caso else " · Turno de comparação"
        cartoes = []
        for mesa in mesas:
            por_serie = defaultdict(list)
            for e in sorted(mesa["registros"], key=lambda ev: (ev["data_hora"], ev["membro"], int(ev["linha"]))):
                por_serie[e["urna"]].append(e)
            series = sorted(set(mesa["urnas"]) | por_serie.keys()) or [""]
            for serie in series:
                cartoes.append(cartao(mesa, serie, por_serie[serie], dias, titulo, alternativo))
        blocos.append(f"<div class='eq-periodo'>{rotulo}</div><div class='eq-urnas'>{''.join(cartoes)}</div>")
    return "<div class='eq-quadro'>" + "".join(blocos) + "</div>"
