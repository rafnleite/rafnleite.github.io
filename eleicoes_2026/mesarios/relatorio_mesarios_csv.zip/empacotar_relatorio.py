"""Gera o ZIP portátil e atualiza o ZIP de arquivo, preservando os JEZ do acervo anterior."""
import argparse
import copy
import csv
import hashlib
import json
import os
import posixpath
import re
import shutil
import tempfile
from functools import lru_cache
from html import escape, unescape
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
from zipfile import ZIP_DEFLATED, ZIP_STORED, BadZipFile, ZipFile


RAIZ = Path(__file__).resolve().parent
PUBLICA = RAIZ.parent
PORTATIL = PUBLICA / "relatorio_mesarios_csv.zip"
COMPLETO = PUBLICA / "auditoria_mesarios_2026.zip"
BASE = PUBLICA / ".auditoria_mesarios_2026.base.tmp"
PAGINAS = ("relatorio.html", "relatorio_tecnico.html", "sankey_turnos.html", "casos_em_aberto.html", "teste_dv.html", "votos_vizinhas.html")
RECURSOS_WEB = {
    "teste_dv_por_titulo.js", "tooltip_equipes.js", "tooltip_equipes.css", "dados/registro_mesarios_bahia.png",
    "dados/memorial_calculo_votos_vizinhas.pdf",
}
PREFIXO = RAIZ.name + "/"
AUTO = "../" + PORTATIL.name
ATRIBUTO = re.compile(r"""(?<![\w.:-])((?:href|src)\s*=\s*)(["'])([^"']*)\2""", re.I)
RAIZ_DADOS = (RAIZ / "dados").resolve()


def temporario():
    f = tempfile.NamedTemporaryFile(dir=PUBLICA, prefix=".mesarios-", suffix=".tmp", delete=False)
    f.close()
    return Path(f.name)


def sha(arquivo):
    with arquivo.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def texto(data):
    return data.decode("utf-8-sig")


def destino_local(pagina, href):
    url = urlsplit(href)
    if url.scheme in ("https","http","mailto","data") or url.netloc:
        return None
    caminho=unquote(url.path)
    if url.scheme or caminho.startswith(("/", "\\")) or "\\" in caminho:
        raise ValueError(f"Destino inesperado em {pagina}: {href}")
    relativo = posixpath.normpath(posixpath.join(posixpath.dirname(pagina), caminho)) if caminho else pagina
    if relativo.startswith("../") or relativo == "..":
        if relativo == AUTO:
            return (AUTO, "")
        raise ValueError(f"Destino externo ao relatório em {pagina}: {href}")
    return relativo, unquote(url.fragment)


@lru_cache(maxsize=1)
def fontes_jez():
    fontes = {}
    for nome in ("downloads", "revisao_manifesto"):
        with (RAIZ_DADOS / (nome+".csv")).open(encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                chave = "dados/" + r["arquivo"].replace("\\", "/")
                url = r["url_log"]
                if (not chave.startswith("dados/logs/") or not chave.endswith(".jez")
                        or urlsplit(url).hostname != "resultados.tse.jus.br"
                        or urlsplit(url).scheme != "https" or not urlsplit(url).path.endswith("/"+PurePosixPath(chave).name)):
                    raise ValueError(f"Referência JEZ incompatível: {chave}")
                item = (url, r["sha256"].lower())
                if chave in fontes and fontes[chave] != item:
                    raise ValueError(f"Manifestos divergentes para {chave}")
                fontes[chave] = item
    if len(fontes) != 24218 or len({PurePosixPath(x).name for x in fontes}) != len(fontes):
        raise ValueError("Rever a cobertura e a unicidade dos 24.218 JEZ")
    return fontes


def html_portatil(nome):
    fonte = (RAIZ / nome).read_text(encoding="utf-8-sig")
    auto_link = re.compile(r"""<a\b([^>]*?)\bhref\s*=\s*(["'])""" + re.escape(AUTO)
                           + r"""\2([^>]*)>.*?</a>""", re.I | re.S)
    # O leitor já tem esse ZIP. Um atributo download aqui faria baixar a própria página.
    fonte = auto_link.sub('<a href="relatorio.html#arquivos">Ver os CSVs incluídos neste pacote</a>', fonte)
    originais = fontes_jez()
    arquivos = {PurePosixPath(r).name:url for r,(url,_) in originais.items()}
    def converter(m):
        href=unescape(m[3])
        local = destino_local(nome, href)
        if local is None:
            return m[0]
        alvo, _ = local
        if alvo == AUTO:
            novo = "relatorio.html#arquivos"
        elif alvo.lower().endswith(".jez"):
            if alvo not in originais and not alvo.startswith("dados/revisao_extracao/"):
                raise ValueError(f"JEZ sem chave no manifesto: {alvo}")
            novo = arquivos[PurePosixPath(alvo).name]
        else:
            return m[0]
        return m[1]+m[2]+escape(novo, quote=True)+m[2]
    return ATRIBUTO.sub(converter, fonte).encode("utf-8")


class Navegacao(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.ids=set()
        self.links=set()
        self.feed(texto(html))
        self.close()

    def handle_starttag(self, tag, attrs):
        for k,v in attrs:
            if k=="id" and v:
                self.ids.add(v)
            if k in ("href","src") and v:
                self.links.add(v)


def dados_publicaveis():
    itens=set()
    for pasta in (RAIZ_DADOS, RAIZ_DADOS/"revisao_extracao", RAIZ_DADOS/"relatorio"):
        for p in pasta.glob("*"):
            if p.is_file() and p.suffix in (".csv", ".json"):
                itens.add(p.relative_to(RAIZ).as_posix())
    return itens


def versoes_atuais():
    return dados_publicaveis() | {p.name for glob in ("*.py","*.html") for p in RAIZ.glob(glob)} | RECURSOS_WEB


def validar_pagina_sankey(html, navegacoes):
    s=texto(html)
    dados=re.search(r'<script type="application/json" id="dados">(.*?)</script>', s, re.S)
    if not dados:
        raise ValueError("Modelo de dados do Sankey não reconhecido")
    _, linhas=json.loads(dados[1])
    padrao=re.search(r"""\.href\s*=\s*['"]([\w.-]+\.html)#f-""",s)
    if not padrao or padrao[1] not in navegacoes:
        raise ValueError("Destino das fichas do Sankey ausente")
    ids=navegacoes[padrao[1]].ids
    for r in linhas:
        if r[4] and f"f-{r[0]}-{r[2].lower()}" not in ids:
            raise ValueError(f"Ficha não encontrada para o ramo do Sankey: {r[2]}")


def validar_links(paginas, membros, permitir_pacote):
    info={p:Navegacao(dados) for p,dados in paginas.items()}
    for pagina,meta in info.items():
        for href in meta.links:
            local=destino_local(pagina,href)
            if local is None:
                continue
            alvo,ancora=local
            if alvo==AUTO and permitir_pacote:
                continue
            if alvo not in membros or (ancora and alvo in info and ancora not in info[alvo].ids):
                raise ValueError(f"Destino ausente em {pagina}: {href}")
    validar_pagina_sankey(paginas["sankey_turnos.html"],info)


def gravar_disco(z, nome, origem):
    compressao=ZIP_STORED if PurePosixPath(nome).suffix in (".gz",".zip",".jez") else ZIP_DEFLATED
    z.write(origem,nome,compress_type=compressao)


def montar_portatil(arquivo):
    paginas={nome:html_portatil(nome) for nome in PAGINAS}
    disponiveis=dados_publicaveis() | {p.name for p in RAIZ.glob("*.py")} | RECURSOS_WEB
    auxiliares={"dados/arvor.zip","dados/mencoes.csv.gz","dados/revisao_extracao/mencoes.csv.gz"}
    # HTMLs só entram pela lista fechada. Dos auxiliares binários, só os que as páginas citam.
    membros=set(paginas) | disponiveis
    for nome,html in paginas.items():
        for href in Navegacao(html).links:
            local=destino_local(nome,href)
            if local and local[0] in auxiliares:
                membros.add(local[0])
    validar_links(paginas,membros,False)
    with ZipFile(arquivo,"w",ZIP_DEFLATED,compresslevel=5) as z:
        for nome,html in paginas.items():
            z.writestr(nome,html)
        for nome in sorted(membros-set(paginas)):
            gravar_disco(z,nome,RAIZ/nome)
    with ZipFile(arquivo) as z:
        if z.testzip() or set(z.namelist())!=membros:
            raise ValueError("Falha na conferência do ZIP portátil")
        for nome in membros:
            esperado = hashlib.sha256(paginas[nome]).hexdigest() if nome in paginas else sha(RAIZ/nome)
            with z.open(nome) as f:
                if hashlib.file_digest(f,"sha256").hexdigest()!=esperado:
                    raise ValueError(f"SHA-256 divergente no portátil: {nome}")
    return len(membros)


def assinatura_base():
    # Impede usar a cópia parcial contra outra versão concorrente do arquivo completo.
    st=COMPLETO.stat()
    return f"mesarios-base-v1 {st.st_size} {st.st_mtime_ns}".encode("ascii")


def preparar_base(forcar=False):
    assinatura=assinatura_base()
    if BASE.exists() and not forcar:
        try:
            with ZipFile(BASE) as z:
                if z.comment==assinatura:
                    return
        except BadZipFile:
            pass  # Uma cópia temporária interrompida pode ser refeita a partir do acervo original.
    temp=temporario()
    try:
        atuais={PREFIXO+r for r in versoes_atuais()}
        fontes={PREFIXO+k:v[1] for k,v in fontes_jez().items()}
        with ZipFile(COMPLETO) as entrada, ZipFile(temp,"w",allowZip64=True) as saida:
            nomes=entrada.namelist()
            if len(set(nomes))!=len(nomes) or {n for n in nomes if n.lower().endswith(".jez")}!=set(fontes):
                raise ValueError("O arquivo anterior não contém exatamente os 24.218 JEZ esperados")
            for membro in entrada.infolist():
                nome=membro.filename
                if nome in atuais or nome==PORTATIL.name:
                    continue
                with entrada.open(membro) as src, saida.open(copy.copy(membro),"w") as dst:
                    if nome in fontes:
                        digest=hashlib.sha256()
                        while bloco:=src.read(1024*1024):
                            digest.update(bloco)
                            dst.write(bloco)
                        if digest.hexdigest()!=fontes[nome]:
                            raise ValueError(f"JEZ diverge do SHA-256 no manifesto: {nome}")
                    else:
                        shutil.copyfileobj(src,dst,1024*1024)
            saida.comment=assinatura
        if assinatura!=assinatura_base():
            raise RuntimeError("O ZIP de origem mudou durante a cópia")
        os.replace(temp,BASE)
    finally:
        temp.unlink(missing_ok=True)


def montar_completo(portatil):
    preparar_base()
    assinatura=assinatura_base()
    with ZipFile(COMPLETO) as original:
        anteriores=set(original.namelist())
    atuais=versoes_atuais()
    with ZipFile(BASE) as z:
        estaveis=set(z.namelist())
    atualizaveis={PREFIXO+p for p in atuais}
    if estaveis & atualizaveis or anteriores-estaveis-atualizaveis-{PORTATIL.name}:
        preparar_base(forcar=True)
    with ZipFile(BASE,"a",ZIP_DEFLATED,compresslevel=5) as z:
        # Marca a base como consumida imediatamente, para impedir reuso após uma falha.
        z.comment=b""
        for nome in sorted(atuais):
            gravar_disco(z,PREFIXO+nome,RAIZ/nome)
        gravar_disco(z,PORTATIL.name,portatil)
    with ZipFile(BASE) as z:
        nomes=z.namelist()
        membros=set(nomes)
        if not anteriores<=membros or len(membros)!=len(nomes) or z.testzip():
            raise ValueError("Falha de integridade ou perda de membro do acervo")
        internos={n.removeprefix(PREFIXO) for n in membros if n.startswith(PREFIXO)}
        validar_links({p:z.read(PREFIXO+p) for p in PAGINAS},internos,True)
        for nome in atuais:
            with z.open(PREFIXO+nome) as f:
                if hashlib.file_digest(f,"sha256").hexdigest()!=sha(RAIZ/nome):
                    raise ValueError(f"Cópia incompleta ou arquivo alterado durante a montagem: {nome}")
        with z.open(PORTATIL.name) as f:
            if hashlib.file_digest(f,"sha256").hexdigest()!=sha(portatil):
                raise ValueError("ZIP portátil incorporado divergente")
    if assinatura!=assinatura_base():
        raise RuntimeError("O ZIP de origem mudou durante a montagem")
    return len(nomes)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--preparar-base",action="store_true",help="Prepara somente a cópia temporária dos membros estáveis")
    args=ap.parse_args()
    if args.preparar_base:
        preparar_base()
        print("Base temporária preparada, 24.218 JEZ conferidos com os manifestos.")
        return
    portatil=temporario()
    try:
        quantidade=montar_portatil(portatil)
        acervo=montar_completo(portatil)
        # Ambos já tiveram CRC, links e conteúdo conferidos; cada substituição é atômica.
        os.replace(BASE,COMPLETO)
        os.replace(portatil,PORTATIL)
        print(f"Portátil: {quantidade} arquivos, {PORTATIL.stat().st_size} bytes, SHA-256 {sha(PORTATIL)}")
        print(f"Completo: {acervo} arquivos, {COMPLETO.stat().st_size} bytes, SHA-256 {sha(COMPLETO)}")
    finally:
        portatil.unlink(missing_ok=True)


if __name__=="__main__":
    main()
