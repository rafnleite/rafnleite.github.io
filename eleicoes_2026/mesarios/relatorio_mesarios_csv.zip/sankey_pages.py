"""Liga a consulta do Sankey às fichas publicadas no relatório dos mesários."""
import csv
from io import TextIOWrapper
import json
import re

from casos_em_aberto import decimal, secao, tempo
from relogios import CSV_CASOS


def _trajetos(pacote):
    por_caso = {}
    with pacote.open(f"dados/relatorio/{CSV_CASOS.name}") as entrada:
        for linha in csv.DictReader(TextIOWrapper(entrada, encoding="utf-8-sig", newline="")):
            chave = f"f-{linha['turno']}-{linha['id_caso'].lower()}"
            origem = linha["hora_origem"].split()[-1]
            destino = linha["hora_destino"].split()[-1]
            intervalo = float(linha["intervalo_s"])
            duracao = ("−" if intervalo < 0 else "") + tempo(abs(intervalo))
            trecho = [f"{secao(linha, 'origem')} → {secao(linha, 'destino')}",
                      f"Registros às {origem} e às {destino}. Intervalo registrado de {duracao}."]
            if linha["tempo_trajeto_s"]:
                trecho.append(f"Percurso de {decimal(linha['percurso_rede_km'], 3)} km "
                              f"({linha['modo']}). Tempo estimado de {tempo(linha['tempo_trajeto_s'])}.")
            elif linha["distancia_km"]:
                trecho.append(f"Distância em linha reta de {decimal(linha['distancia_km'], 3)} km.")
            por_caso[chave] = trecho
    return por_caso


def _substituir(html, antigo, novo):
    if html.count(antigo) != 1:
        raise ValueError(f"Estrutura inesperada na consulta do Sankey: {antigo[:65]}")
    return html.replace(antigo, novo, 1)


def ajustar_sankey(html, destinos, pacote):
    """Mantém equipes, horários e percursos acessíveis inclusive sem ficha narrativa."""
    bloco = re.search(r'(<script type="application/json" id="dados">)(.*?)</script>', html, re.S)
    if not bloco:
        raise ValueError("Sankey sem bloco de casos")
    lugares, casos = json.loads(bloco[2])
    trajetos = _trajetos(pacote)
    consultas = {}
    for caso in casos:
        chave = f"f-{caso[0]}-{caso[2].lower()}"
        destino = destinos.get(chave)
        if chave in trajetos:
            consultas[chave] = {"trecho": trajetos[chave]}
        if destino:
            consultas.setdefault(chave, {})["ficha"] = destino
    dados = json.dumps([lugares, casos, consultas], ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    html = html[:bloco.start(2)] + dados + html[bloco.end(2):]
    html = _substituir(html, "const [lugares,casos]=JSON.parse", "const [lugares,casos,consultas]=JSON.parse")

    antigo = """      if(c[4]){
        const link=document.createElement('a');link.href='relatorio_tecnico.html#f-'+c[0]+'-'+c[2].toLowerCase();
        if(c[9])link.dataset.equipePrever=c[0]+'-'+c[2].toLowerCase();
        link.append(numero);titulo.append(link);
      }else{titulo.append(numero)}"""
    novo = """      const chaveEquipe = c[0] + '-' + c[2].toLowerCase();
      const consulta = consultas['f-' + chaveEquipe];
      if (consulta?.ficha) {
        const link = document.createElement('a');
        link.href = 'relatorio.html#' + consulta.ficha;
        if (c[9]) link.dataset.equipePrever = chaveEquipe;
        link.append(numero);
        titulo.append(link);
      } else if (c[9]) {
        const botao = document.createElement('button');
        botao.type = 'button';
        botao.className = 'ver-equipe';
        botao.dataset.equipePrever = chaveEquipe;
        botao.setAttribute('aria-label', 'Ver equipes das urnas do título ' + c[1]);
        botao.setAttribute('aria-haspopup', 'dialog');
        botao.setAttribute('aria-controls', 'previa-equipes');
        botao.setAttribute('aria-expanded', 'false');
        botao.append(numero);
        titulo.append(botao);
      } else {
        titulo.append(numero);
      }"""
    html = _substituir(html, antigo, novo)
    html = _substituir(html, "if(c[8]||c[7]){", "if(consulta?.trecho || c[8] || c[7]){")
    html = _substituir(html, "notas.append(texto('summary','Detalhes da ficha'));desfecho.append(notas);",
                       """notas.append(texto('summary',consulta?.trecho ? 'Ver trajeto e horários' : 'Ver detalhes'));
        desfecho.append(notas);
        for (const trecho of consulta?.trecho || []) notas.append(texto('small',trecho));""")
    html = _substituir(html, 'href="casos_em_aberto.html">Lista atual dos casos sem explicação',
                       'href="relatorio.html#em-aberto">Casos sem explicação no relatório dos mesários')
    html = _substituir(html, "Selecione a contagem para consultar a lista e abra um título para conferir a comparação entre as urnas.",
                       "Selecione uma contagem para consultar a lista de casos.")
    html = _substituir(html, "na urna, inclusive os zeros à esquerda. A linha de registro",
                       "na urna, inclusive os zeros à esquerda. Os títulos com ficha abrem a comparação no relatório dos mesários. "
                       "Nos demais casos entre locais distintos, o botão do título mostra as equipes e a coluna Desfecho reúne o trajeto e os horários. "
                       "A linha de registro")
    return html
