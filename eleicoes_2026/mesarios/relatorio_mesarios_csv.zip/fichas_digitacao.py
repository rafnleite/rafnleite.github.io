"""Fichas dos títulos semelhantes entre locais de votação distintos no cadastro de 25/10.

Executar este módulo para conferir novamente os pacotes JEZ e atualizar o extrato.
preparar_fichas() devolve {(turno, titulo): {html, forca, subtitulo, ...}}.
"""
from collections import Counter, defaultdict
from html import escape
import json
from pathlib import Path
from tempfile import NamedTemporaryFile

from casos_em_aberto import NOTAS, chave, decimal, secao, tempo, trecho_principal
from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify
from ilustracoes import ESTILO as ESTILO_DIGITOS, cartao_candidato, nome_municipio, painel_casa_nova, rotulos_mesarios
from logistica import CURTO
from relogios import MARGEM_MIN
from sankey_casos import QUATRO_PONTES


ARQUIVO = BASE / "evidencia_fichas_digitacao.json"
GOIANESIA = "M-56737337C02A"
CASA_NOVA = "M-DAB0A007A18D"
BURITI_DOS_MONTES = "M-CB8776247A86"
PEDRA_BRANCA = "M-CBDB94FBA0EF"
DESLOCAMENTOS_REVISTOS = {
    "M-868F9DA649CE": (
        "No 1º turno, a seção 306 registrou este título na abertura às 07:38:31 e atribuiu a ele uma habilitação às 12:27:28. "
        "A seção 22 registrou a presença às 14:04:03, durante a votação. Às 14:52:30, outra habilitação "
        "foi atribuída ao título na seção 306. As rotas de ida e volta levam cerca de três a quatro minutos. "
        "O título semelhante, 001547331503, só aparece no 2º turno."
    ),
    "M-3A24203A38EC": (
        "No 2º turno, a seção 60 registrou o título na abertura. No fim do dia, a seção 13 o registrou às 17:04:05 "
        "e a seção 60 às 17:06:22, ambos no encerramento. O trajeto de volta leva cerca de 3min19s e cabe no intervalo "
        "com 1min02s de diferença entre os relógios, dentro da tolerância adotada. O título 035935400850 já constava "
        "junto com 035934900850 na abertura e no encerramento da seção 60 no 1º turno."
    ),
    "M-E5B95278ADDF": (
        "No 2º turno, a seção 670 registrou o título na abertura às 07:36:22. A seção 510, em outra escola da mesma "
        "zona, registrou a presença às 09:53:09, durante a votação, e no encerramento às 17:02:05. O número recebeu "
        "quatro habilitações na seção 510. O título semelhante, 123763470493, consta na seção 670 apenas no 1º turno."
    ),
}
CANDIDATOS_TRES = {
    QUATRO_PONTES: "109699530604",
    "M-7D65F5D2F1F5": "013587111406",
    "M-6991E2FC1BB9": "355001420108",
}
ETAPAS = ("abertura", "encerramento")
ESTILO = ESTILO_DIGITOS + """
.ficha-dig .tit-comparacao{max-width:100%}
"""


def extrair():
    classes = {chave(r): r["avaliacao"] for r in linhas("logistica_por_caso_revisao.csv")}
    pares = defaultdict(dict)
    for r in linhas("duas_edicoes_pares.csv"):
        k = chave(r)
        if k not in classes or r["fonte"] != "registro":
            continue
        terceira = r["titulo_alternativo"] == CANDIDATOS_TRES.get(r["id_caso"]) and r["distancia_levenshtein"] == "3"
        if r["custo_ampliado"] not in ("1","2") and not terceira:
            continue
        mesa = identify(r)[1:]
        alternativo = r["titulo_alternativo"]
        linha = pares[k].setdefault((mesa,alternativo),r)
        if (r["caminho_usual"],r["caminho_ampliado"]) != (linha["caminho_usual"],linha["caminho_ampliado"]):
            raise ValueError("Caminhos divergentes entre os turnos da fonte")
    mesas = defaultdict(set)
    for arquivo in ("comparacao_secoes.csv", "revisao_comparacao_secoes.csv"):
        for r in linhas(arquivo):
            if chave(r) in pares:
                mesas[chave(r)].add(identify(r)[1:])
    trechos = defaultdict(list)
    for r in linhas("trajetos_por_evento_revisao.csv"):
        if chave(r) in pares:
            trechos[chave(r)].append(r)
    pedidas = {(t,*s) for secoes in mesas.values() for s in secoes for t in ("1","2")}
    fontes = {identify(r):r for r in linhas("manifesto.csv") if identify(r) in pedidas}
    enderecos = {identify(r):r for r in linhas("enderecos.csv") if identify(r) in pedidas}
    qualificados = defaultdict(Counter)
    for r in linhas("registros_qualificados.csv"):
        k=identify(r)
        if k in pedidas:
            ref=(r["titulo"],r["data_hora"],r["urna"],r["tipo"],r["membro"],int(r["linha"]))
            qualificados[k][ref]+=1
    if set(fontes) != pedidas or set(enderecos) != pedidas:
        raise ValueError(f"Seções sem pacote ou cadastro: {pedidas-set(fontes) | pedidas-set(enderecos)}")
    fontes_conferidas = {}
    for k in sorted(pedidas):
        titulos = {ref[0] for ref in qualificados[k]}
        fontes_conferidas[k] = ler_secao(fontes[k], enderecos[k], titulos, qualificados[k])
    dados=[]
    for k, grupo in sorted(pares.items()):
        if len(grupo)!=1 or len(mesas[k])!=2:
            raise ValueError(f"Rever os candidatos ou o número de seções do caso {k}")
        (mesa,alt),r=next(iter(grupo.items()))
        rep=k[1]
        registros=[]
        for t in ("1","2"):
            for local in sorted(mesas[k],key=lambda s:(s!=mesa,s)):
                evidencia=fontes_conferidas[(t,*local)]
                e={campo:evidencia[campo] for campo in ("turno","uf","municipio","zona","secao","endereco","nome",
                            "urnas","arquivo","sha256","url_log","registros")}
                e["mesa_alternativo"] = local==mesa
                e["habilitacoes"] = [ev for ev in evidencia["habilitacoes"] if ev["titulo"] in (rep,alt)]
                registros.append(e)
        dados.append(dict(turno=k[0],titulo=rep,id_caso=r["id_caso"],alternativo=alt,
                          caminho=json.loads(r["caminho_usual"] or r["caminho_ampliado"] or "[]"),
                          operacoes=int(r["custo_usual"] or r["custo_ampliado"] or 3),
                          classe=classes[k],trecho=trecho_principal(trechos[k],classes[k]),secoes=registros))
    if {c["id_caso"] for c in dados if c["operacoes"]==3} != set(CANDIDATOS_TRES):
        raise ValueError("Faltou algum candidato da revisão contextual")
    return dados


def atualizar():
    """Lê cada JEZ requerido, confere o SHA e as linhas contra o índice e grava o extrato."""
    dados=extrair()
    with NamedTemporaryFile("w",encoding="utf-8",dir=BASE,delete=False) as f:
        tmp=Path(f.name)
        try:
            json.dump(dados,f,ensure_ascii=False,separators=(",",":"))
            f.write("\n")
        except Exception:
            f.close()
            tmp.unlink(missing_ok=True)
            raise
    try:
        tmp.replace(ARQUIVO)
    finally:
        tmp.unlink(missing_ok=True)
    return dados


def cod(valor):
    return f"<code>{escape(valor)}</code>"


def equipe(mesa, etapa):
    return {e["titulo"] for e in mesa["registros"] if e["etapa"]==etapa}


def turno_mesa(c, no_turno, local):
    return next(s for s in c["secoes"] if (str(s["turno"])==c["turno"])==no_turno and s["mesa_alternativo"]==local)


def qualificar(c):
    """Avalia as duas grafias nas fontes verificadas das seções e dos turnos."""
    ident = c["id_caso"]
    if ident in DESLOCAMENTOS_REVISTOS:
        return "trajeto", DESLOCAMENTOS_REVISTOS[ident]
    if ident == PEDRA_BRANCA:
        return "forte", ("Na seção 97, os outros três títulos permanecem e a única mudança na lista do 2º turno "
                         "é compatível com a omissão de um 5 no encerramento. O trajeto do 1º turno também é plausível.")
    r, a = c["titulo"], c["alternativo"]
    par = {r, a}
    local = turno_mesa(c, True, True)
    outra_data = turno_mesa(c, False, True)
    outra_secao = turno_mesa(c, True, False)
    outra_secao_outra_data = turno_mesa(c, False, False)

    def grafias(mesa):
        return {e["titulo"] for e in mesa["registros"]} & par

    if grafias(outra_data) == par:
        return "indicio", "Os dois títulos também coexistem na mesma seção no outro turno"
    if grafias(outra_data) != {a} or grafias(outra_secao) != {r} or a in grafias(outra_secao_outra_data):
        return "indicio", "Os registros das duas seções não permitem atribuir a troca"

    abertura, fecho = (equipe(local, etapa) & par for etapa in ETAPAS)
    if (abertura, fecho) in (({a}, {r}), ({r}, {a})):
        return "forte", "As grafias se alternam entre abertura e encerramento, com confirmação no outro turno"
    if grafias(local) == {r} and any(r in equipe(local, etapa) and a in equipe(outra_data, etapa) for etapa in ETAPAS):
        return "forte", "As grafias se alternam entre os turnos na mesma etapa da seção"

    repetidos = [e for e in local["registros"] if e["titulo"] == r]
    if (c["operacoes"] <= 3 and len(repetidos) == 1 and par <= abertura and fecho == {a}
            and equipe(local, "abertura") - {r} == equipe(local, "encerramento")
            and all(a in equipe(outra_data, etapa) for etapa in ETAPAS)
            and r in grafias(outra_secao_outra_data)):
        extra = repetidos[0]
        if any(e["titulo"] == a and (e["urna"], e["membro"], e["linha_marcador"]) ==
               (extra["urna"], extra["membro"], extra["linha_marcador"]) and e["linha"] > extra["linha"]
               for e in local["registros"]):
            return "forte", "O título repetido é a única presença adicional na abertura, e a grafia local aparece nas quatro listas"
    if c["operacoes"] <= 2 and len(repetidos) == 1:
        if repetidos[0]["etapa"] == "durante a votação" and a in abertura and any(
                e["titulo"] == a for e in local["habilitacoes"]):
            return "forte", "Registro isolado durante a votação, com a grafia local corroborada pelas habilitações"
        eventos = sorted(local["registros"], key=lambda e: (e["data_hora"], e["membro"], int(e["linha"])))
        for antes, depois in zip(eventos, eventos[1:]):
            if (antes["titulo"] == a and depois["titulo"] == r
                    and antes["etapa"] == depois["etapa"] == "registro pelo menu de votação"
                    and (antes["urna"], antes["membro"], antes["linha_marcador"])
                    == (depois["urna"], depois["membro"], depois["linha_marcador"])):
                return "forte", "Grafias consecutivas no mesmo ciclo do menu, corroboradas pelo outro turno"
    if par <= abertura or par <= fecho:
        return "indicio", "As duas grafias foram registradas na mesma etapa, sem uma substituição identificável"
    return "indicio", "A semelhança numérica não localiza a digitação que originou o registro"


def figura(c, *, erro_forte):
    a,r = c["alternativo"],c["titulo"]
    secao_alternativo = turno_mesa(c, True, True)
    secao_referencia = turno_mesa(c, True, False)
    rotulos = rotulos_mesarios(secao_alternativo, secao_referencia)
    if c["id_caso"]==CASA_NOVA:
        return painel_casa_nova(rotulos, erro_forte=erro_forte)
    if c["id_caso"] == PEDRA_BRANCA:
        secao = rotulos_mesarios(secao_alternativo, secao_alternativo)
        rotulos = secao._replace(origem=f"{secao.origem} · abertura do 2º turno",
                                 contraparte=f"{secao.contraparte} · encerramento do 2º turno")
        omissao = dict(tipo="omissao", antes=r, depois=r[:4] + r[5:], posicoes=[5])
        return cartao_candidato(dict(titulo_alternativo=r, titulo=a, caminho_usual=[omissao]),
                                rotulos, erro_forte=erro_forte)
    caminho = c["caminho"]
    if c["operacoes"]==3:
        dif=[i for i,(v,z) in enumerate(zip(a,r,strict=True)) if v!=z]
        if len(dif)!=3:
            raise ValueError("Rever o alinhamento a três substituições")
        corrente=a
        caminho=[]
        for i in dif:
            depois=corrente[:i]+r[i]+corrente[i+1:]
            caminho.append(dict(tipo="substituicao",antes=corrente,depois=depois,posicoes=[i+1]))
            corrente=depois
    return cartao_candidato({"titulo_alternativo":a,"titulo":r,"caminho_usual":caminho}, rotulos,
                            erro_forte=erro_forte)


def particularidade(c):
    ident,r,a = c["id_caso"],c["titulo"],c["alternativo"]
    local=turno_mesa(c, True, True)
    anterior=turno_mesa(c, False, True)
    outra=turno_mesa(c, True, False)
    abertura,fecho = (equipe(local,x) for x in ETAPAS)
    if ident==GOIANESIA:
        return (f"Em Goianésia, {cod(r)} aparece tanto na abertura quanto no encerramento do 1º turno. "
                f"Na mesma seção, {cod(a)} aparece na abertura e no encerramento do 2º turno. Os outros três títulos "
                f"são os mesmos nas quatro listas de Goianésia. Em Ataléia, {cod(r)} consta na abertura e no "
                f"encerramento dos dois turnos. A composição das equipes indica que, nas duas digitações do "
                f"1º turno em Goianésia, foi omitido o 2 da quarta posição de {cod(a)}.")
    if ident==CASA_NOVA:
        return (f"Em Casa Nova, o número da abertura do 2º turno foi {cod(a)} e recebeu quatro habilitações. "
                f"No encerramento, entrou {cod(r)}. Foram mantidos os mesmos outros três títulos. "
                f"Omitir o 3 da segunda posição de {cod(a)} e duplicar o 2 da sétima posição original "
                f"produz {cod(r)}, registrado no encerramento das mesas de Casa Nova e Porto Seguro com 21 segundos de diferença.")
    if ident == BURITI_DOS_MONTES:
        return (f"Na abertura do 2º turno em Buriti dos Montes (Z34, S33), às 07:39:32, a urna registrou {cod(r)} "
                "e informou que o titular não era eleitor daquela seção (linhas 6057–6058). "
                f"No encerramento, às 17:02:56, registrou {cod(a)} e o identificou como eleitor da própria seção "
                "(linhas 9265–9266). Esse título já constava na abertura e no encerramento do 1º turno em Buriti "
                f"(linhas 658 e 5430). Em Milton Brandão (Z12, S210), a urna identifica {cod(r)} como título de eleitor "
                "da seção nas quatro listas (linhas 643–644 e 4586–4587 no 1º turno, 5196–5197 e 7592–7593 no 2º). "
                "A sequência indica que na abertura de Buriti foi digitado <strong>4 no lugar de 1 na sexta posição</strong>. "
                "Essa troca preserva os dois dígitos verificadores (03). A soma usada no primeiro passa de 132 para 153. "
                "Os restos da divisão por 11 são 0 e 10, e ambos produzem o dígito 0 para o código de UF 15. "
                "Com a mesma UF e o mesmo primeiro verificador, o segundo continua 3.")
    if ident=="M-6991E2FC1BB9":
        return (f"Em São Paulo (Z257, S168), {cod(r)} aparece apenas na abertura do 1º turno (linha 560). "
                f"Às 17:08:23, a urna registrou {cod(a)} no encerramento (linha 6751). Essa grafia voltou no "
                f"encerramento do 2º turno. Em São Miguel Arcanjo, {cod(r)} aparece nas quatro listas de abertura "
                f"e encerramento. Trocar o prefixo 3550 de {cod(a)} por 3335 reproduz {cod(r)}, registrado "
                "na abertura paulistana. Há ainda um possível erro em outro par da mesma mesa. Omitir o 7 da "
                f"sétima posição de {cod('311676790116')} e completar com um zero à esquerda produz {cod('031167690116')}.")
    if ident=="M-7D65F5D2F1F5":
        return (f"Em Santa Teresa (zona 11, seção 55), {cod(a)} consta na abertura e no encerramento dos dois turnos "
                "(linhas 630 e 5463 no 1º turno, 6232 e 9926 no 2º). Na abertura do 2º turno, a urna registrou "
                f"também {cod(r)} às 07:26:07 (linha 6221). Dos cinco títulos registrados, esse foi o único que "
                f"não reapareceu no encerramento. Na própria abertura, a urna registrou {cod('021826121490')} às 07:27:01 "
                f"(linha 6227) e, em seguida, {cod(a)} às 07:27:47. "
                f"Em Vila Velha (zona 57, seção 76), {cod(r)} consta nas aberturas dos dois turnos e no "
                "encerramento do 2º. A urna atribuiu a esse número seis habilitações de eleitores no 1º turno "
                f"e três no 2º. A comparação aponta para a digitação de <strong>894 no lugar de 711 nas posições "
                f"6, 7 e 8</strong> na abertura de Santa Teresa. A urna aceitou tanto {cod(r)} quanto {cod(a)}. "
                "O log não assinala uma correção explícita.")
    if ident in CANDIDATOS_TRES:
        return escape(NOTAS[ident])
    if ident=="M-92F6D4907F6A":
        return (f"Na abertura de Birigui, a urna gravou {cod(r)} no 1º turno e {cod(a)} no 2º. Os outros "
                f"três títulos são os mesmos nas duas listas. O único registro de {cod(a)} em Birigui ocorreu "
                f"na abertura do 2º turno. Omitir o 6 da oitava posição de {cod(a)} e completar com um zero à esquerda "
                f"produz {cod(r)}. Em Mauá, {cod(r)} consta na abertura e no encerramento dos dois turnos.")
    if ident=="M-3748C6A3A45D":
        return (f"Em Jaboatão dos Guararapes (Z118, S214), a urna registrou {cod(a)} às 07:43:51 "
                f"na abertura do 1º turno (linha 636). Às 17:51:46, no encerramento (linha 7465), entrou {cod(r)}. "
                f"Omitir o 6 da 5ª posição de {cod(a)} produz {cod('03691250868')}. Duplicar o zero que vem logo depois do 5 "
                f"produz exatamente {cod(r)}. Dos quatro títulos da abertura, dois se repetiram no encerramento. "
                f"O único número novo entre os três do encerramento foi {cod(r)}. O outro título que saiu, "
                f"{cod('045847860809')}, está a nove edições de {cod(r)}. No 2º turno, {cod(a)} voltou "
                "a constar na abertura e no encerramento dessa mesma seção (linhas 8225 e 12303). "
                f"Em Caruaru (Z106, S243), {cod(r)} consta na abertura e no encerramento dos dois turnos. "
                "A sequência dos registros nas duas mesas sustenta a conclusão de erro de digitação no encerramento de Jaboatão.")
    if ident=="M-8428348D675C":
        return (f"Na seção 296 de Maracanaú, {cod(a)} aparece nas duas etapas dos dois turnos. No 2º turno, "
                f"a urna atribuiu cinco habilitações a esse título. Omitir o bloco 58 das posições 7 e 8 de {cod(a)} "
                f"e completar com zeros à esquerda produz {cod(r)}, registrado uma única vez em Maracanaú, às 17:00:33 "
                "(linha 11220), durante a votação. Às 17:03:25, a urna assinalou uma tentativa de título inválido "
                f"(linha 11247). Às 17:03:50, registrou {cod(a)} no encerramento (linha 11250). "
                f"Em Fortaleza, {cod(r)} consta na abertura e no encerramento dos dois turnos, inclusive às "
                "17:03:13 daquele dia, apenas 2min40s depois do registro de Maracanaú.")
    if ident=="M-7B5C3C53AC1F":
        return (f"Em Alegre, {cod(a)} aparece nas três listas disponíveis de abertura e encerramento. No 2º turno, "
                f"a urna atribuiu 13 habilitações a esse número. Omitir o 1 da 6ª posição de {cod(a)} e completar com um zero "
                f"à esquerda produz {cod(r)}, registrado em Alegre uma única vez, às 17:01:11, durante a votação "
                "(linha 9825). A seção não tem título registrado com marcador de encerramento nesse dia. "
                f"Guarapari, a 116,24 km em linha reta, registrou {cod(r)} 38 segundos depois, às 17:01:49.")
    if ident=="M-BB767AB8769D":
        return (f"Na seção de Palmas, o menu de registro de mesários recebeu {cod(a)} às 08:30:19 e {cod(r)} às 08:30:54 "
                "do 2º turno, 35 segundos depois. Entre eles, às 08:30:28, a urna assinalou uma tentativa com título inválido "
                f"(linha 7922). Omitir o 3 da 10ª posição de {cod(a)} e completar com um zero à esquerda reproduz "
                f"{cod(r)}. Em Palmas, {cod(a)} já constava na abertura do 1º turno. Em Cidade Ocidental, {cod(r)} aparece "
                "na abertura e no encerramento dos dois turnos. Esses registros sustentam a hipótese de erro na "
                "digitação das 08:30:54 em Palmas. O log não revela os dígitos da tentativa inválida.")
    if ident == PEDRA_BRANCA:
        return (f"No 1º turno, os mesmos quatro títulos constam na abertura das seções 79 e 97. O título "
                f"{cod(r)} foi registrado às 07:32:45 e às 08:35:46, respectivamente. O intervalo de "
                f"1h03min01s comporta o trajeto estimado de 4min43s. No 2º turno, a "
                f"seção 97 registrou {cod(r)} na abertura às 07:33:02 (linha 5163) e {cod(a)} no encerramento "
                f"às 17:15:45 (linha 7674). Os outros três títulos se mantiveram. A urna identificou {cod(r)} "
                f"como título de eleitor da seção 97. Ao omitir um dos dois algarismos 5 consecutivos e "
                f"preencher com zero à esquerda, chega-se a {cod(a)}. O indício de digitação está no encerramento "
                f"do 2º turno. A repetição do 1º turno também é compatível com o remanejamento da equipe.")
    if qualificar(c)[0]!="forte":
        descricoes = []
        for sec in (local, anterior, outra, turno_mesa(c, False, False)):
            partes = []
            for titulo in (a, r):
                etapas = Counter(ev["etapa"] for ev in sec["registros"] if ev["titulo"] == titulo)
                contagens = ", ".join(f"{escape(etapa)} ({n})" for etapa, n in etapas.items())
                partes.append(f"{cod(titulo)} — {contagens or 'sem registro'}")
            descricoes.append(f"No {sec['turno']}º turno, seção {sec['secao']} de "
                              f"{escape(nome_municipio(sec['municipio']))}/{escape(sec['uf'])}, "
                              + " e ".join(partes) + ".")
        return " ".join(descricoes)
    primeiro,ultimo=(r,a) if r in abertura else (a,r)
    descricao = (f"No {local['turno']}º turno, a seção {local['secao']} de {escape(nome_municipio(local['municipio']))} "
                 f"registrou {cod(primeiro)} na abertura "
                 f"e {cod(ultimo)} no encerramento.")
    if ident=="M-88FCC3674D2F":
        descricao+=f" Antes de aceitar {cod(r)}, a urna assinalou uma entrada inválida às 07:49:02 (linha 645)."
    if all(a in equipe(anterior,x) for x in ETAPAS):
        descricao+=f" No {anterior['turno']}º turno, essa seção registrou {cod(a)} na abertura e no encerramento."
    elif a in equipe(anterior,"encerramento"):
        extras=[e for e in anterior["registros"] if e["titulo"]==a and e["etapa"] not in ETAPAS]
        if extras:
            ev=extras[0]
            descricao+=f" No {anterior['turno']}º turno, essa seção registrou {cod(a)} às {ev['data_hora'][11:]} ({escape(ev['etapa'])}) e no encerramento."
    referencia = f"seção {outra['secao']} de {escape(nome_municipio(outra['municipio']))}"
    if all(r in equipe(outra,x) for x in ETAPAS):
        outro_turno = turno_mesa(c, False, False)
        periodo = f"do {outra['turno']}º turno"
        if all(r in equipe(outro_turno, etapa) for etapa in ETAPAS):
            periodo = "dos dois turnos"
        descricao+=f" A {referencia} registrou {cod(r)} na abertura e no encerramento {periodo}."
    else:
        etapas_repetido=[ev["etapa"] for ev in outra["registros"] if ev["titulo"]==r]
        descricao+=f" Na {referencia}, {cod(r)} consta no {outra['turno']}º turno com a indicação {' e '.join(map(escape,etapas_repetido))}."
    return descricao


def montar_ficha(c):
    categoria,forca=qualificar(c)
    a=c["alternativo"]
    if categoria == "trajeto":
        return dict(forca=forca, categoria=categoria, alternativo=a, operacoes=c["operacoes"])
    t=c["trecho"]
    trajetoria=(f"De {escape(secao(t,'origem'))} a {escape(secao(t,'destino'))}, o trecho analisado tem "
                f"<b>{decimal(t['distancia_km'],2)} km</b> em linha reta. Entre {t['hora_origem'][11:]} e "
                f"{t['hora_destino'][11:]} decorreram <b>{tempo(t['intervalo_s'])}</b>.")
    if t["tempo_trajeto_s"] and c["classe"]==CURTO:
        trajetoria+=f" A rota estimada exige {tempo(t['tempo_trajeto_s'])}."
    if c["id_caso"] == BURITI_DOS_MONTES:
        trajetoria += (f" Essa distância é incompatível com o intervalo, mesmo considerando a margem "
                       f"de {MARGEM_MIN} minutos entre os relógios.")
    h=(f"<div class='ficha-dig'><p>{trajetoria}</p><p>{particularidade(c)}</p>"
       f"{figura(c, erro_forte=categoria=='forte')}</div>")
    return dict(html=h,forca=forca,categoria=categoria,alternativo=a,operacoes=c["operacoes"])


def preparar_fichas():
    """Mapa (turno str, título str) → html (abaixo do h3), forca, categoria, alternativo, operacoes."""
    dados=json.loads(ARQUIVO.read_bytes()) if ARQUIVO.exists() else atualizar()
    return {chave(c):montar_ficha(c) for c in dados}


if __name__=="__main__":
    print(len(atualizar()), "fichas lidas dos pacotes originais.")
    print(dict(Counter(v["categoria"] for v in preparar_fichas().values())))
