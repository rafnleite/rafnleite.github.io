"""Ilustra, na direção candidato → número repetido, os caminhos testados."""
import html
import json
from collections import defaultdict
from typing import NamedTuple

from comparar import valor


ESTILO = """
.tit-comparacao{margin:12px 0 17px;padding:14px 16px;border:1px solid #cadbd4;border-radius:5px;background:#fafcf9;color:#192f2d;break-inside:avoid}
.tit-comparacao.tit-capa{padding:clamp(14px,3vw,30px);border-top:4px solid #116254;background:#f4f8f2;margin:1rem 0}
.tit-comparacao .tit-grade{overflow-x:auto;max-width:100%;padding:4px 1px}
.tit-comparacao .tit-linha{display:grid;grid-template-columns:minmax(9rem,15rem) minmax(0,1fr);align-items:center;gap:.15rem .7rem;margin:6px 0}
.tit-comparacao .tit-rotulo{color:#39534d;font-size:.8rem;font-weight:650;line-height:1.25}
.tit-comparacao .tit-papel{display:block;color:#486159;font-size:.75rem;font-weight:400;line-height:1.3;margin-top:2px}
.tit-comparacao .tit-faixa{display:grid;grid-template-columns:repeat(var(--tit-cols),clamp(.78rem,3.3vw,1.7rem));align-items:center;width:max-content;gap:1px}
.tit-comparacao .tit-cel{display:block;text-align:center;background:transparent;font:600 1.125rem/1.55 Consolas,'Courier New',monospace;font-variant-numeric:tabular-nums;border-bottom:2px solid transparent;border-radius:2px}
.tit-comparacao .tit-vazio{color:#627770;font-weight:400}
.tit-comparacao .tit-amostra{display:inline-block;width:1.05em;height:.9em;border-radius:2px;border-bottom:2px solid transparent}
.tit-comparacao .tit-sai{background:#ffe8db;color:#772d12;border-bottom:2px dashed #9f401b}
.tit-comparacao .tit-entra,.tit-comparacao .tit-duplica{background:#d5f1db;color:#145035;border-bottom:2px solid #226b42}
.tit-comparacao .tit-duplica{border-bottom:3px double #226b42}
.tit-comparacao .tit-troca{background:#fbecc8;color:#674700;border-bottom-color:#987300}
.tit-comparacao .tit-inversao{background:#eee6f7;color:#59357b;border-bottom:3px double #78518c}
.tit-comparacao .tit-troca-inversao{background:#fbecc8;color:#59357b;border-bottom:3px double #78518c}
.tit-comparacao .tit-zero{background:#e5edf1;color:#405963;border-bottom:2px dotted #667f89}
.tit-comparacao figcaption{margin-top:8px;color:#405951;font-size:.82rem}
.tit-comparacao .tit-legenda{display:flex;flex-wrap:wrap;gap:.2rem 1rem}
.tit-comparacao .tit-chave{display:inline-flex;align-items:center;gap:.3em}
.tit-comparacao .tit-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
@media(max-width:660px){.tit-comparacao{padding:10px}.tit-comparacao .tit-linha{display:block;margin-bottom:5px}.tit-comparacao .tit-linha .tit-rotulo{display:block;margin-bottom:2px}.tit-comparacao .tit-grade{padding:0}}
@media print{.tit-comparacao{background:white;border-color:#888;print-color-adjust:exact;-webkit-print-color-adjust:exact}.tit-comparacao .tit-grade{overflow:visible}}
"""


MARCAS = {
    "entra": "Inserção",
    "duplica": "Duplicação",
    "sai": "Omissão",
    "troca": "Substituição",
    "inversao": "Troca de posição",
    "troca-inversao": "Substituição e troca de posição",
    "zero": "Ajuste de zero à esquerda",
}


class RotulosMesarios(NamedTuple):
    origem: str
    contraparte: str
    secao_digitacao: str


def nome_municipio(municipio):
    partes = municipio.title().split()
    return " ".join(p.lower() if i and p in {"Da", "Das", "De", "Do", "Dos", "E"} else p
                    for i, p in enumerate(partes))


def rotulos_mesarios(secao_origem, destinos, *, so_mencao=False):
    """Identifica a mesa de comparação e as demais mesas em que o número se repetiu."""
    if isinstance(destinos, dict):
        destinos = [destinos]
    grupos = defaultdict(list)
    for secao in destinos:
        grupos[secao["municipio"], secao["uf"]].append(secao)
    if not grupos:
        raise ValueError("Comparação sem seção de contraparte")

    def local(secao):
        nome = nome_municipio(secao["municipio"])
        preposicao = "do" if nome in {"Rio de Janeiro", "Recife", "Cabo de Santo Agostinho"} else "de"
        homonimo = any(s["municipio"] == secao["municipio"] and s["uf"] != secao["uf"]
                       for s in [secao_origem, *destinos])
        return f"{preposicao} {nome}" + (f" ({secao['uf']})" if homonimo else "")

    cidade_origem = local(secao_origem)
    secao_digitacao = f"seção {secao_origem['secao']} {cidade_origem}"
    rotulo_origem = f"Menção na {secao_digitacao}" if so_mencao else f"Mesário {cidade_origem}"
    chave_origem = (secao_origem["municipio"], secao_origem["uf"])
    if chave_origem in grupos and not so_mencao:
        rotulo_origem += f" · zona {secao_origem['zona']}, seção {secao_origem['secao']}"

    contrapartes = []
    for chave, secoes in grupos.items():
        rotulo = f"Mesário {local(secoes[0])}"
        if chave == chave_origem or len(secoes) > 1:
            zonas = defaultdict(set)
            for s in secoes:
                zonas[s["zona"]].add(s["secao"])
            for zona, numeros in zonas.items():
                secoes_texto = ", ".join(map(str, sorted(numeros, key=int)))
                rotulo += f" · zona {zona}, {'seção' if len(numeros) == 1 else 'seções'} {secoes_texto}"
        contrapartes.append(rotulo)
    return RotulosMesarios(rotulo_origem, " / ".join(contrapartes), secao_digitacao)


def _linha(rotulo, papel, digitos, classes):
    numero = "".join(d for d in digitos if d is not None)
    pedacos = []
    mudancas = []
    posicao = 0
    for digito, marca in zip(digitos, classes, strict=True):
        if digito is None:
            pedacos.append("<span class='tit-cel tit-vazio'>·</span>")
            continue
        posicao += 1
        atributo = ""
        classe = "tit-cel"
        if marca:
            descricao = f"{MARCAS[marca]} · {posicao}ª posição · {digito}"
            mudancas.append(descricao)
            atributo = f" title='{html.escape(descricao, quote=True)}'"
            classe += " tit-" + marca
        pedacos.append(f"<span class='{classe}'{atributo}>{html.escape(digito)}</span>")
    acessivel = f"<span class='tit-sr'>{html.escape(numero)}</span>"
    if mudancas:
        acessivel += f"<span class='tit-sr tit-mudancas'>. {html.escape('. '.join(mudancas))}.</span>"
    return (f"<div class='tit-linha'><span class='tit-rotulo'>{html.escape(rotulo)}"
            f"<span class='tit-papel'>{html.escape(papel)}</span></span>"
            f"<div>{acessivel}<span aria-hidden='true' class='tit-faixa'>{''.join(pedacos)}</span></div></div>")


def _figura(rotulos, colunas, *, erro_forte=False, destaque=False, legenda=""):
    origem, repetido, marcas_origem, marcas_repetido = zip(*colunas, strict=True)
    classe = "tit-comparacao tit-capa" if destaque else "tit-comparacao"
    usadas = {marca for linha in (marcas_origem, marcas_repetido) for marca in linha}
    chaves = [f"<span class='tit-chave'><i class='tit-amostra tit-{marca}' aria-hidden='true'></i>{nome}</span>"
              for marca, nome in MARCAS.items() if marca in usadas]
    if None in origem or None in repetido:
        chaves.append("<span class='tit-chave'><b aria-hidden='true'>·</b> Sem algarismo</span>")
    texto = html.escape(legenda)
    papel_origem = "Título correto" if erro_forte else "Título de comparação"
    papel_destino = f"Digitado por engano na {rotulos.secao_digitacao}" if erro_forte else "Número registrado nas mesas comparadas"
    return (f"<figure class='{classe}' style='--tit-cols:{len(origem)}'><div class='tit-grade'>"
            f"{_linha(rotulos.origem, papel_origem, origem, marcas_origem)}"
            f"{_linha(rotulos.contraparte, papel_destino, repetido, marcas_repetido)}</div>"
            f"<figcaption><span class='tit-legenda'>{''.join(chaves)}</span>{texto}</figcaption></figure>")


def _alinhar_caminho(origem, repetido, caminho):
    """Aplica a sequência documentada e alinha apenas os dígitos das duas pontas."""
    if not caminho:
        raise ValueError("Caminho de edições vazio")
    # Cada coluna preserva sua posição na grade. A identidade de um algarismo
    # acompanha as permutas, inclusive quando ele também foi substituído.
    ordem = list(range(len(origem)))
    ativas = ordem.copy()
    identidade = {col: col for col in ordem}
    natureza = {}
    substituidos, invertidos = set(), set()

    def inserir(pos, quantidade, classe):
        novas = list(range(len(ordem), len(ordem) + quantidade))
        coluna = ordem.index(ativas[pos]) if pos < len(ativas) else len(ordem)
        ordem[coluna:coluna] = novas
        ativas[pos:pos] = novas
        for col in novas:
            identidade[col] = col
            natureza[col] = classe

    def ajustar_zeros(antes, depois):
        if antes == depois:
            return
        if valor(antes) != valor(depois):
            raise ValueError("Ajuste de zeros incompatível com os títulos")
        diferenca = len(depois) - len(antes)
        if diferenca > 0:
            inserir(0, diferenca, "zero")
        else:
            for col in ativas[:-diferenca]:
                natureza[identidade[col]] = "zero"
            del ativas[:-diferenca]

    anterior = caminho[0]["antes"]
    ajustar_zeros(origem, anterior)
    for passo in caminho:
        tipo, antes, depois = passo["tipo"], passo["antes"], passo["depois"]
        if antes != anterior:
            raise ValueError("Etapas de digitação descontínuas")
        posicoes = [int(p) - 1 for p in passo["posicoes"]]
        i = posicoes[0]
        if tipo == "omissao":
            if antes[:i] + antes[i+1:] != depois:
                raise ValueError("Omissão inconsistente")
            natureza[identidade[ativas.pop(i)]] = "sai"
        elif tipo in ("duplicacao", "insercao"):
            if depois[:i] + depois[i+1:] != antes:
                raise ValueError("Inserção inconsistente")
            if tipo == "duplicacao" and (i == 0 or depois[i-1] != depois[i]):
                raise ValueError("Duplicação inconsistente")
            inserir(i, 1, "duplica" if tipo == "duplicacao" else "entra")
        elif tipo == "substituicao":
            if antes[:i] + depois[i] + antes[i+1:] != depois:
                raise ValueError("Substituição inconsistente")
            substituidos.add(identidade[ativas[i]])
        elif tipo in ("troca_adjacente", "troca_nao_adjacente"):
            j = posicoes[1]
            simulado = list(antes)
            simulado[i], simulado[j] = simulado[j], simulado[i]
            if "".join(simulado) != depois:
                raise ValueError("Permuta inconsistente")
            a, b = ativas[i], ativas[j]
            invertidos.update((identidade[a], identidade[b]))
            identidade[a], identidade[b] = identidade[b], identidade[a]
        else:
            raise ValueError(f"Operação desconhecida: {tipo}")
        anterior = depois
    ajustar_zeros(anterior, repetido)

    def classe(digito):
        if digito in natureza:
            return natureza[digito]
        if digito in invertidos:
            return "troca-inversao" if digito in substituidos else "inversao"
        return "troca" if digito in substituidos else ""

    fim = dict(zip(ativas, repetido, strict=True))
    return [(origem[col] if col < len(origem) else None, fim.get(col),
             classe(col) if col < len(origem) else "", classe(identidade[col]) if col in fim else "")
            for col in ordem if col < len(origem) or col in fim]


def painel_casa_nova(rotulos, *, erro_forte=True):
    """Mostra a reconstrução exata sugerida para o encerramento do segundo turno."""
    origem,intermediario,destino = "137009230523","17009230523","170092230523"
    passos = [
        dict(tipo="omissao",antes=origem,depois=intermediario,posicoes=[2]),
        dict(tipo="duplicacao",antes=intermediario,depois=destino,posicoes=[7]),
    ]
    return _figura(rotulos, _alinhar_caminho(origem, destino, passos), erro_forte=erro_forte, destaque=True,
                   legenda="Na seção 249 de Casa Nova, o primeiro número consta na abertura e o segundo no encerramento.")


def cartao_candidato(linha, rotulos, *, erro_forte=False):
    """Renderiza a menor sequência do CSV, preferindo operações usuais quando há empate."""
    caminhos=[]
    for perfil in ("usual","ampliado"):
        valor_json = linha.get("caminho_"+perfil)
        if valor_json:
            caminho = json.loads(valor_json) if isinstance(valor_json,str) else valor_json
            if caminho:
                caminhos.append(caminho)
    if not caminhos:
        return comparacao_mais_proxima(linha["titulo_alternativo"], linha["titulo"], rotulos, erro_forte=erro_forte)
    colunas = _alinhar_caminho(linha["titulo_alternativo"], linha["titulo"], min(caminhos,key=len))
    return _figura(rotulos, colunas, erro_forte=erro_forte)


def comparacao_mais_proxima(origem, repetido, rotulos, *, erro_forte=False):
    """Alinhamento descritivo de custo mínimo, com grafias originais completas."""
    a,b = valor(origem),valor(repetido)
    custo = [list(range(len(b)+1))]
    for i,x in enumerate(a,1):
        linha=[i]
        for j,y in enumerate(b,1):
            linha.append(min(custo[-1][j-1]+(x!=y),custo[-1][j]+1,linha[-1]+1))
        custo.append(linha)
    i,j=len(a),len(b)
    colunas=[]
    while i or j:
        if i and j and custo[i][j]==custo[i-1][j-1]+(a[i-1]!=b[j-1]):
            estilo="troca" if a[i-1]!=b[j-1] else ""
            colunas.append((a[i-1],b[j-1],estilo,estilo))
            i-=1
            j-=1
        elif i and custo[i][j]==custo[i-1][j]+1:
            colunas.append((a[i-1],None,"sai",""))
            i-=1
        else:
            colunas.append((None,b[j-1],"","entra"))
            j-=1
    colunas.reverse()
    zeros_a,zeros_b=len(origem)-len(a),len(repetido)-len(b)
    largura=max(zeros_a,zeros_b)
    zeros=[]
    for k in range(largura):
        x = "0" if k >= largura-zeros_a else None
        y = "0" if k >= largura-zeros_b else None
        zeros.append((x, y, "zero" if x and not y else "", "zero" if y and not x else ""))
    distancia=custo[-1][-1]
    legenda=f"Distância de edição {distancia} ao considerar inserções, omissões e substituições."
    return _figura(rotulos, zeros + colunas, erro_forte=erro_forte, legenda=legenda)
