"""Reavalia os casos sem estimativa de rede no cadastro TSE de 25/10/2026.

Cada transição é delimitada por eventos consecutivos do mesmo título e turno.
A velocidade é o mínimo geométrico com o intervalo integral, sem folga de relógio.
"""
import csv
from collections import defaultdict
from datetime import datetime

from geografia import DADOS, distancia, ler_csv, secao
from geografia_revisao import coordenadas
from logistica import CURTO, EXTREMO, INCERTO


SAIDA = DADOS / "relatorio" / "trechos_sem_rota.csv"
CADASTRO = "https://cdn.tse.jus.br/estatistica/sead/odsele/eleitorado_locais_votacao/eleitorado_local_votacao_2026.zip"
# Triagem para nova revisão individual, sem atribuir um meio de transporte.
# Nenhum trecho deste recorte exige mais de 48 km/h pela distância retilínea.
REVER_ACIMA_KMH = 60


def duracao(segundos):
    horas, resto = divmod(segundos, 3600)
    minutos, segundos = divmod(resto, 60)
    return f"{horas:02d}h{minutos:02d}min{segundos:02d}s"


def decimal(valor):
    return f"{valor:.2f}".replace(".", ",")


def par_externo(r):
    return frozenset(((r["zona_sem_ponto"], r["secao_sem_ponto"]),
                      (r["zona_outro"], r["secao_outro"])))


def detalhar(evento, enderecos, fontes, conferencias, divisas):
    t = dict(evento)
    intervalo = int(t["intervalo_s"])
    segundos = datetime.fromisoformat(t["hora_destino"]) - datetime.fromisoformat(t["hora_origem"])
    if segundos.total_seconds() != intervalo:
        raise ValueError(f"Intervalo diferente dos horários dos eventos em {t['id_caso']}")

    par = frozenset((t["zona_" + lado], t["secao_" + lado]) for lado in ("origem", "destino"))
    conf = conferencias.get((t["id_caso"], par))
    pontos = []
    for lado in ("origem", "destino"):
        chave = secao(t, "_" + lado)
        endereco = enderecos[chave]
        if endereco["geracao"] != "25/10/2026":
            raise ValueError(f"Edição do cadastro inesperada em {chave}")
        ponto = coordenadas(endereco)
        if (not ponto and conf and conf["latitude_externa"] and
                (t["zona_" + lado], t["secao_" + lado]) == (conf["zona_sem_ponto"], conf["secao_sem_ponto"])):
            ponto = (float(conf["latitude_externa"]), float(conf["longitude_externa"]))
        pontos.append(ponto)
        t["latitude_" + lado], t["longitude_" + lado] = ponto or (None, None)
        t["url_log_" + lado] = fontes[(t["id_caso"], chave)]

    km = distancia(*pontos)
    if t["distancia_km"] and (km is None or abs(km - float(t["distancia_km"])) > 0.00006):
        raise ValueError(f"Distância inconsistente com as coordenadas em {t['id_caso']}")
    if conf and conf["distancia_reta_m"] and (km is None or abs(km * 1000 - float(conf["distancia_reta_m"])) > 1):
        raise ValueError(f"Distância externa inconsistente em {t['id_caso']}")

    categoria = "TSE"
    origem = "Coordenadas dos dois locais no cadastro TSE de 25/10/2026"
    limite = "A linha reta mede a separação entre os pontos. A extensão e a duração do percurso real permanecem desconhecidas."
    if conf:
        categoria = "externa"
        origem = "Cadastro TSE e " + conf["situacao"].lower()
        limite += " " + conf["verificacao"]
    if km is None:
        categoria = "sem coordenadas"
        origem = "Coordenadas insuficientes para medir a distância entre os locais"
        limite = conf["verificacao"] if conf else origem
    kmh = km * 3600 / intervalo if km is not None and intervalo > 0 else None
    viz = divisas.get((t["turno"], frozenset((secao(t, "_origem"), secao(t, "_destino")))))
    t.update(
        intervalo_h=round(intervalo / 3600, 6), intervalo_legivel=duracao(intervalo),
        distancia_reta_km=round(km, 4) if km is not None else None,
        velocidade_minima_kmh=round(kmh, 5) if kmh is not None else None,
        tipo_distancia=categoria, fonte_distancia=origem,
        url_cadastro=CADASTRO, url_fonte_distancia=(conf["fonte_primaria"] if conf else CADASTRO) if km is not None else "",
        url_verificacao_local=conf["fonte_primaria"] if conf else "",
        url_fonte_complementar=conf["segunda_fonte"] if conf else "",
        divisa_confirmada=bool(viz and viz["vizinhos"] == "1" and viz["contato"] == "trecho de divisa"),
        divisa_comum_km_ibge=viz["limite_km_ibge_2024"] if viz else "",
        url_divisa_ibge=viz["fonte_tabela"] if viz else "",
        limites_trecho=limite,
    )
    return t


def concluir(trechos):
    # O trecho principal é o que exige maior velocidade mínima. Na ausência de
    # um par de pontos em todo o caso, apresenta-se o menor intervalo observado.
    medidos = [t for t in trechos if t["velocidade_minima_kmh"] is not None]
    pior = (max(medidos, key=lambda t: t["velocidade_minima_kmh"]) if medidos
            else min(trechos, key=lambda t: int(t["intervalo_s"])))
    municipal = all(t["mesmo_municipio"] == "1" for t in trechos)
    zonal = all(t["mesma_zona"] == "1" for t in trechos)
    divisa = all(t["mesmo_municipio"] == "1" or t["divisa_confirmada"] for t in trechos)
    conflito = any(t["avaliacao_logistica"] in (CURTO, EXTREMO) or int(t["intervalo_s"]) <= 0
                   for t in trechos)
    alta = any(t["velocidade_minima_kmh"] > REVER_ACIMA_KMH for t in medidos)
    # O único par intermunicipal deste recorte foi revisto individualmente.
    # A regra municipal não se estende automaticamente a qualquer par vizinho.
    intermunicipal_revisto = (
        (pior["turno"], pior["titulo"]) == ("2", "121958550281") and divisa and zonal and
        len(trechos) == 1 and set((pior["codigo_municipio_origem"], pior["codigo_municipio_destino"])) == {"50431", "50890"}
        and pior["distancia_reta_km"] == 47.2155 and int(pior["intervalo_s"]) == 33850
    )
    plausivel = (municipal or intermunicipal_revisto) and not conflito and not alta
    contexto = "Mesmo município" if municipal else "Municípios distintos"
    if not municipal and divisa:
        contexto = "Municípios vizinhos com divisa confirmada pelo IBGE"
    if zonal:
        contexto += " e mesma zona eleitoral"
    if pior["distancia_reta_km"] is None:
        medida = f"Intervalo de {pior['intervalo_legivel']}. Faltam coordenadas verificadas para medir a separação entre os locais."
        base = "Município e intervalo entre eventos"
    else:
        km = pior["distancia_reta_km"]
        extensao = f"{round(1000 * km)} m" if km < 1 else f"{decimal(km)} km"
        medida = f"{extensao} em linha reta e {pior['intervalo_legivel']} entre os registros."
        base = "Linha reta e intervalo entre eventos"
    justificativa = f"{contexto}. {medida}"
    if pior["tipo_distancia"] == "externa":
        justificativa += " " + pior["fonte_distancia"] + "."
    status = "Requer avaliação individual"
    if plausivel:
        status = "Plausível no mesmo município" if municipal else "Plausível entre municípios vizinhos"
    return dict(plausivel=plausivel, status=status, justificativa=justificativa, trecho_principal=pior,
                trechos=trechos, base=base, limites=pior["limites_trecho"])


def avaliar():
    casos = {(r["turno"], r["titulo"]): r for r in ler_csv("logistica_por_caso_revisao.csv")
             if r["avaliacao"] == INCERTO}
    enderecos = {secao(r): r for r in ler_csv("enderecos.csv")}
    fontes = {(r["id_caso"], secao(r)): r["url_log"] for r in ler_csv("secoes_por_caso.csv")}
    conferencias = {(r["id_caso"], par_externo(r)): r for r in ler_csv("conferencia_coordenadas.csv")}
    divisas = {(r["turno"], frozenset((secao(r, "_a"), secao(r, "_b")))): r for r in ler_csv("vizinhanca.csv")}
    trechos = defaultdict(list)
    for r in ler_csv("trajetos_por_evento_revisao.csv"):
        chave = (r["turno"], r["titulo"])
        if chave in casos:
            trechos[chave].append(detalhar(r, enderecos, fontes, conferencias, divisas))
    for chave, caso in casos.items():
        if len(trechos[chave]) != int(caso["mudancas_de_local"]) or not trechos[chave]:
            raise ValueError(f"Número inesperado de transições para {chave}")
    return {chave: concluir(trechos[chave]) for chave in casos}


def gravar_csv(avaliacoes):
    linhas = [dict(t, status_caso=caso["status"], justificativa_caso=caso["justificativa"],
                   trecho_principal=int(t is caso["trecho_principal"]))
              for caso in avaliacoes.values() for t in caso["trechos"]]
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    with SAIDA.open("w", encoding="utf-8-sig", newline="") as arquivo:
        dados = csv.DictWriter(arquivo, fieldnames=linhas[0].keys())
        dados.writeheader()
        dados.writerows(linhas)
    return SAIDA


if __name__ == "__main__":
    gravar_csv(avaliar())
