"""Gera o Sankey local com as mesmas linhas classificadas pelo gerador da análise."""
import json
from collections import Counter
from html import escape
from pathlib import Path

from casos_em_aberto import GRUPOS_ESTADUAIS, GRUPOS_GEOGRAFICOS
from listas_equipes import carregar_listas
from previa_equipes import componentes
from relogios import COMPATIVEL, IMPROVAVEL, INDETERMINADO, MARGEM_MIN
from sankey_casos import ERRO_FORTE, INDICIO, REMANEJAMENTO, SEM_EVIDENCIA, TRAJETO_INDETERMINADO, aplicar_margem

ROOT = Path(__file__).resolve().parent


def numero(n):
    return f"{n:,}".replace(",", ".")


def porcentagem(n, total):
    return f"{n / total * 100:.1f}%".replace(".", ",")


def painel(turno, casos):
    """Monta fluxos contínuos com a mesma escala em todas as colunas."""
    total = len(casos)
    distintos = [c for c in casos if c["locais"] == "Locais distintos"]
    por_tempo = Counter(c["situacao_relogios"] for c in distintos)
    n_por_grupo = Counter(c["grupo"] for c in distintos)
    por_tempo_e_grupo = Counter((c["situacao_relogios"], c["grupo"]) for c in distintos)

    # Coordenadas horizontais em milésimos da largura; posições verticais em pixels.
    etapas = ("Turno", "Local de votação", "Tempo para o deslocamento", "Desfecho do caso", "Município e zona eleitoral", "Estado das seções")
    larguras = (112, 126, 148, 168, 172, 130)
    espaco = (1000 - sum(larguras)) / (len(etapas) - 1)
    posicoes = [sum(larguras[:i]) + i * espaco for i in range(len(etapas))]
    nos = {}
    filhos = {}

    def no(chave, nome, quantidade, coluna, y, cor, campo, valor=None, pai=None, tempo=None):
        if not quantidade:
            return
        nos[chave] = (nome, quantidade, coluna, y, cor, campo, valor or nome, tempo)
        if pai:
            filhos.setdefault(pai, []).append((chave, quantidade))

    no("turno", f"{turno}º turno", total, 0, 140, "origem", "todos")
    no("mesmo", "Mesmo local", total-len(distintos), 1, 80, "local", "locais", pai="turno")
    no("distintos", "Locais distintos", len(distintos), 1, 238, "investigado", "locais", pai="turno")
    tempos = ((COMPATIVEL, "Trajeto compatível", 124, "trajeto"),
              (IMPROVAVEL, "Deslocamento improvável", 340, "aberto"),
              (INDETERMINADO, TRAJETO_INDETERMINADO, 500, "incerto"))
    for situacao, rotulo, y, cor in tempos:
        no(situacao, rotulo, por_tempo[situacao], 2, y, cor, "tempo", situacao, "distintos")

    desfechos = ((REMANEJAMENTO, "Remanejamento plausível", "trajeto"), (ERRO_FORTE, ERRO_FORTE, "titulo"),
                 (INDICIO, INDICIO, "indicio"), (SEM_EVIDENCIA, SEM_EVIDENCIA, "aberto"),
                 (TRAJETO_INDETERMINADO, TRAJETO_INDETERMINADO, "incerto"))
    y = 68
    for grupo, rotulo, cor in desfechos:
        if not n_por_grupo[grupo]:
            continue
        if grupo == ERRO_FORTE:
            for situacao, *_ in tempos:
                n = por_tempo_e_grupo[situacao, grupo]
                if n:
                    no(f"{grupo} · {situacao}", rotulo, n, 3, y, cor, "grupo", grupo, pai=situacao, tempo=situacao)
                    y += 112
            continue
        no(grupo, rotulo, n_por_grupo[grupo], 3, y, cor, "grupo", grupo)
        for situacao in por_tempo:
            n = por_tempo_e_grupo[situacao, grupo]
            if n:
                filhos.setdefault(situacao, []).append((grupo, n))
        y += 112

    abertos = [c for c in distintos if c["situacao_relogios"] == IMPROVAVEL and c["grupo"] in (INDICIO, SEM_EVIDENCIA)]
    por_local = Counter(c["grupo_geografico"] for c in abertos)
    cruzamentos = Counter((c["grupo"], c["grupo_geografico"]) for c in abertos)
    locais_presentes = [local for local in GRUPOS_GEOGRAFICOS if por_local[local]]
    centro_abertos = max((nos[c["grupo"]][3] for c in abertos), default=0)
    # A geografia só desdobra os deslocamentos improváveis ainda sem explicação.
    # Se um mesmo nó reúne indícios com e sem essa condição, a parcela restante termina aqui.
    indicios_improvaveis = por_tempo_e_grupo[IMPROVAVEL, INDICIO]
    demais_indicios = n_por_grupo[INDICIO] - indicios_improvaveis
    if indicios_improvaveis and demais_indicios:
        no("outros-indicios", "Indício sem deslocamento improvável", demais_indicios, 4,
           centro_abertos - 200, "indicio", "outros-indicios", pai=INDICIO)
    for i, local in enumerate(locais_presentes):
        centro = centro_abertos + (i - (len(locais_presentes) - 1) / 2) * 128
        cor = "geografia-comum" if local == GRUPOS_GEOGRAFICOS[0] else "geografia-distinta"
        no(local, local, por_local[local], 4, centro, cor, "geografia")
        for grupo in (INDICIO, SEM_EVIDENCIA):
            if cruzamentos[grupo, local]:
                filhos.setdefault(grupo, []).append((local, cruzamentos[grupo, local]))

    entre_municipios_e_zonas = GRUPOS_GEOGRAFICOS[1]
    por_estado = Counter(c["grupo_estadual"] for c in abertos if c["grupo_geografico"] == entre_municipios_e_zonas)
    estados_presentes = [estado for estado in GRUPOS_ESTADUAIS if por_estado[estado]]
    for i, estado in enumerate(estados_presentes):
        centro_pai = nos[entre_municipios_e_zonas][3]
        centro = centro_pai + (i - (len(estados_presentes) - 1) / 2) * 104
        no(estado, estado, por_estado[estado], 5, centro, "geografia-distinta", "estado", pai=entre_municipios_e_zonas)

    altura = max(n[3] for n in nos.values()) + 66
    escala = 64 / total
    faixas, botoes = [], []
    entradas = Counter()
    origens = Counter(destino for destinos in filhos.values() for destino, _ in destinos)
    denominadores = {}
    for pai, destinos in filhos.items():
        _, quantidade, coluna, centro, *_ = nos[pai]
        if sum(n for _, n in destinos) != quantidade:
            raise ValueError(f"Fluxos divergentes no {turno}º turno: {pai}")
        topo = centro - quantidade * escala / 2
        x1 = posicoes[coluna] + larguras[coluna]
        x2 = posicoes[coluna+1]
        meio = (x1 + x2) / 2
        for destino, n in destinos:
            nome, total_destino, _, centro_destino, cor, campo, *_ = nos[destino]
            denominador = quantidade
            if campo == "geografia":
                denominador = len(abertos)
            elif campo == "grupo" and origens[destino] > 1:
                denominador = len(distintos)
            denominadores[destino] = denominador
            h = n * escala
            inicio = topo
            base = centro_destino + (entradas[destino] - total_destino / 2) * escala
            entradas[destino] += n
            curva = (f"M{x1:.2f} {inicio:.4f} C{meio:.2f} {inicio:.4f} {meio:.2f} {base:.4f} {x2:.2f} {base:.4f} "
                     f"v{h:.4f} C{meio:.2f} {base+h:.4f} {meio:.2f} {inicio+h:.4f} {x1:.2f} {inicio+h:.4f} Z")
            faixa = f'<path class="banda" d="{curva}"/>'
            if h < 1.5:
                # O traço central mantém legíveis até os fluxos de um caso.
                a = topo + h/2
                fim = base + h/2
                faixa += (f'<path class="fio" d="M{x1:.2f} {a:.4f} '
                          f'C{meio:.2f} {a:.4f} {meio:.2f} {fim:.4f} {x2:.2f} {fim:.4f}"/>')
            faixas.append(f'<g class="{cor}" data-de="{escape(pai)}" data-para="{escape(destino)}" '
                          f'data-casos="{n}"><title>{escape(nos[pai][0])} → {escape(nome)} · {numero(n)}</title>{faixa}</g>')
            topo += h

    for chave, (nome, n, coluna, centro, cor, campo, valor, tempo) in nos.items():
        if chave != "turno" and entradas[chave] != n:
            raise ValueError(f"Fluxos de entrada divergentes no {turno}º turno: {nome}")
        pct = porcentagem(n, denominadores.get(chave, total))
        origem = f" · {nos[tempo][0]}" if tempo else ""
        filtro_tempo = f' data-tempo="{escape(tempo, quote=True)}"' if tempo else ""
        descricao = f"Consultar {nome}{origem}, {numero(n)} {'caso' if n == 1 else 'casos'} no {turno}º turno"
        detalhe = ""
        if campo == "geografia" and n_por_grupo[INDICIO]:
            partes = [f"{cruzamentos[g, chave]} {rotulo}" for g, rotulo in
                      ((INDICIO, "com indício"), (SEM_EVIDENCIA, "sem evidência")) if cruzamentos[g, chave]]
            detalhe = f'<small>{" · ".join(partes)}</small>'
        botoes.append(
            f'<button type="button" class="no {cor}" data-turno="{turno}" data-campo="{campo}" '
            f'data-valor="{escape(valor, quote=True)}"{filtro_tempo} aria-label="{escape(descricao, quote=True)}" '
            f'style="left:{posicoes[coluna]/10:.3f}%;width:{larguras[coluna]/10:.1f}%;top:{centro}px">'
            f'<span class="nome">{escape(nome)}</span><span class="valor">{numero(n)}</span>'
            f'<span class="percentual">{pct}</span>{detalhe}</button>')
    cabecalhos = "".join(f'<span style="left:{posicoes[i]/10:.3f}%;width:{larguras[i]/10:.1f}%">{e}</span>'
                         for i, e in enumerate(etapas))
    return (f'<article data-turno="{turno}" aria-label="Sankey do {turno}º turno">'
            f'<figure class="fluxo" aria-label="Do local de votação ao desfecho de cada caso no {turno}º turno">'
            f'<div class="rolar-grafico" tabindex="0" aria-label="Diagrama de fluxos do {turno}º turno">'
            f'<div class="prancha"><div class="etapas">{cabecalhos}</div>'
            f'<div class="sankey" style="height:{altura}px">'
            f'<svg viewBox="0 0 1000 {altura}" preserveAspectRatio="none" aria-hidden="true">'
            f'{"".join(faixas)}</svg>{"".join(botoes)}</div></div></div></figure></article>')


def gerar(casos, adicionais=()):
    from relogios import avaliar
    casos = [dict(r, improvavel=r["situacao_relogios"] == IMPROVAVEL)
             for r in aplicar_margem(casos, avaliar())]
    adicionais = list(adicionais)
    turnos={t:[r for r in casos if str(r["turno"])==t] for t in ("1","2")}
    if sum(map(len,turnos.values()))!=len(casos) or len({(r["turno"],r["titulo"]) for r in casos})!=len(casos):
        raise ValueError("Casos de título e turno duplicados ou turno desconhecido")
    listas = carregar_listas()
    previas = {(str(r["turno"]), r["titulo"]) for r in casos if r["locais"] == "Locais distintos"} & listas.keys()
    estilo_previa, controles_previa = componentes(listas, previas)
    indices = {}
    linhas = []
    for r in casos:
        lugar=r["secoes"].replace(" | "," ↔ ")
        if lugar not in indices:
            indices[lugar]=len(indices)
        linha = [str(r["turno"]),r["titulo"],r["id_caso"],indices[lugar],
                       r["grupo"] if r["locais"]=="Locais distintos" else "",
                       r["desfecho"] if r["locais"]=="Locais distintos" else "",int(r["improvavel"]),r.get("contexto") or "",
                       r["situacao_relogios"], (str(r["turno"]),r["titulo"]) in previas]
        if r["improvavel"] and r["grupo"] in (INDICIO, SEM_EVIDENCIA):
            linha.extend((r["grupo_geografico"], int(r["mesmo_municipio"]), int(r["mesma_zona"]), r["grupo_estadual"]))
        linhas.append(linha)
    dados=json.dumps([list(indices),linhas],ensure_ascii=False,separators=(",",":")).replace("<","\\u003c")
    paineis="".join(painel(t,rows) for t,rows in turnos.items())
    if adicionais:
        saldo=Counter((str(r["turno"]),r["locais"]) for r in adicionais)
        nota=", ".join(f'{n} {"caso" if n == 1 else "casos"} no {t}º turno ({locais.lower()})' for (t,locais),n in saldo.items())
        extras="".join(f'<tr><td><code>{escape(r["titulo"])}</code></td><td>{escape(r["turno"])}º</td>'
                      f'<td>{escape(r["contexto"].title())}</td><td>{escape(r["secoes"])}</td></tr>' for r in adicionais)
        suplemento=(f'<p>Os logs das urnas de contingência registram {nota}. Esses casos adicionais ficam fora do universo publicado pela Arvor.</p>'
                    f'<details><summary>Ver os títulos suplementares ({len(adicionais)})</summary><div class="rolar"><table><thead><tr>'
                    f'<th>Título registrado</th><th>Turno</th><th>Município</th><th>Seções</th></tr></thead><tbody>{extras}</tbody></table></div>'
                    '<a href="dados/repeticoes_adicionais.csv" download>Baixar o CSV com os títulos e links dos logs do TSE</a></details>')
    else:
        suplemento=""
    distintos = sum(r["locais"] == "Locais distintos" for r in casos)
    compativeis = sum(r["situacao_relogios"] == COMPATIVEL for r in casos)
    plausiveis = sum(r["grupo"] == REMANEJAMENTO for r in casos)
    improvaveis = Counter(r["turno"] for r in casos if r["improvavel"])
    resumo = (f"Em {numero(compativeis)} dos {numero(distintos)} casos em locais distintos, "
              f"o intervalo é compatível com o deslocamento. Desses, {compativeis-plausiveis} têm indício de digitação "
              f"e {plausiveis} têm o remanejamento como explicação plausível. "
              f"Dos {sum(improvaveis.values())} casos de deslocamento improvável, {improvaveis['1']} ocorreram no primeiro turno e "
              f"{improvaveis['2']} no segundo.")
    pagina = MODELO.replace("%%PAINEIS%%",paineis).replace("%%SUPLEMENTO%%",suplemento).replace("%%TOTAL%%",numero(len(casos))).replace("%%DADOS%%",dados).replace("%%RESUMO%%",resumo)
    pagina = pagina.replace("%%MARGEM%%", str(MARGEM_MIN))
    opcoes_geo = "".join(f'<label><input type="radio" name="filtro-geo" value="{escape(grupo, quote=True)}"> '
                         f'{escape(grupo or "Todos")} (<span>0</span>)</label>'
                         for grupo in ("", *GRUPOS_GEOGRAFICOS))
    pagina = pagina.replace("%%OPCOES_GEO%%", opcoes_geo)
    nota_indicios = ("Um indício é inconclusivo quando há outro título de mesário semelhante na seção, "
                     "mas a composição das equipes permite mais de uma interpretação. " if any(r["grupo"] == INDICIO for r in casos) else "")
    pagina = pagina.replace("%%NOTA_INDICIOS%%", nota_indicios).replace("%%ESTILO_PREVIA%%",estilo_previa).replace("%%CONTROLES_PREVIA%%",controles_previa)
    caminho=ROOT / "sankey_turnos.html"
    caminho.write_text(pagina,encoding="utf-8")
    return caminho


MODELO = r"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Desfechos por turno · Títulos de mesário</title>
<style>
:root{color-scheme:light;--tinta:#22352f;--verde:#116453;--linha:#cad8d0;--papel:#fcfcf8;font-family:"Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;background:var(--papel);color:var(--tinta);font-size:16px;line-height:1.48}
main{max-width:1600px;margin:auto;padding:24px clamp(14px,3vw,48px) 50px}
a{color:var(--verde);text-underline-offset:3px}:focus-visible{outline:3px solid #1b69a0;outline-offset:3px}
nav{display:flex;gap:12px 20px;flex-wrap:wrap;font-size:.92rem}
h1,h2,p,figure{margin:0}h1,h2{font-family:Georgia,serif;font-weight:500;line-height:1.14}
h1{font-size:clamp(2rem,3.9vw,3.3rem);margin:20px 0 6px;letter-spacing:-.035em}p{max-width:90ch}
.cab-grafico{display:flex;align-items:center;flex-wrap:wrap;gap:8px 22px;margin:18px 0 12px}
.chaves{display:inline-flex;gap:3px;padding:3px;background:#eef2ed;border:1px solid #cbd6cf;border-radius:7px}
.chaves button,button.controle{color:var(--tinta);border:1px solid #a4b7aa;border-radius:4px;padding:8px 14px;background:transparent;font:inherit;cursor:pointer}
.chaves button{border:0;padding:6px 14px}.chaves button[aria-pressed=true]{background:#205d4b;color:white}
.legenda{font-size:.89rem;color:#455d51}.dica-rolagem{display:none}
.fluxo{margin:0}.rolar-grafico{overflow-x:auto;border-top:1px solid #b8c9be;border-bottom:1px solid #b8c9be;background:#f6f8f3}
.prancha{min-width:1100px;padding:16px 12px 2px}.etapas,.sankey{position:relative}
.etapas{height:34px;border-bottom:1px solid #dce5db}.etapas span{position:absolute;top:0;color:#455d51;font-weight:650;font-size:.86rem;line-height:1.2}
.sankey svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
.origem{--cor:#344f43}.local{--cor:#56806b}.investigado{--cor:#326a84}.trajeto{--cor:#237661}.titulo{--cor:#724592}.aberto{--cor:#ad542c}
.geografia-comum{--cor:#306f80}.geografia-distinta{--cor:#8d4842}
.indicio{--cor:#97722f}.incerto{--cor:#66717e}.no small{display:block;color:#4d6157;font-size:.76rem;line-height:1.2}
.banda{fill:var(--cor);opacity:.44}.fio{fill:none;stroke:var(--cor);stroke-width:1.5;vector-effect:non-scaling-stroke}
.no{position:absolute;transform:translateY(-50%);padding:9px 10px 9px 12px;min-height:74px;line-height:1.15;font:inherit;text-align:left;cursor:pointer;background:#fff;border:1px solid #c1cfc5;border-left:5px solid var(--cor);border-radius:4px;color:var(--tinta);font-variant-numeric:tabular-nums}
.no:hover,.no:focus-visible,.no.selecionado{border-color:var(--cor);background:#fcfdfa;box-shadow:0 0 0 1px var(--cor)}
.no .nome{display:block;font-size:clamp(.8rem,1.17vw,1rem);line-height:1.2;font-weight:600;overflow-wrap:break-word}
.valor{font-size:clamp(1.22rem,1.75vw,1.7rem);font-weight:700;letter-spacing:-.04em;line-height:1.2}
.percentual{margin-left:.45em;font-size:.78rem;white-space:nowrap;color:#4d6157}
.consulta,.metodo{margin-top:22px;padding-top:16px}.metodo{border-top:1px solid var(--linha);color:#455d51}
.filtro-geo{padding:8px 12px 10px;margin:14px 0;border:1px solid var(--linha);border-radius:4px}
.filtro-geo legend{font-weight:600;padding:0 4px}.filtro-geo div{display:flex;gap:6px 18px;flex-wrap:wrap}
.filtro-geo label{cursor:pointer}.filtro-geo input{accent-color:var(--verde)}
.consulta h2,.metodo h2{font-size:1.6rem}.consulta .resumo{font-weight:600;margin-top:5px}.ferramentas{display:flex;flex-wrap:wrap;align-items:end;gap:9px 20px;margin:14px 0}.ferramentas label{display:grid;gap:3px;font-size:.9rem}.ferramentas input{font:inherit;width:min(330px,100%);color:var(--tinta);padding:7px 9px;border:1px solid #a4b7aa;border-radius:4px}button.controle{min-height:34px;padding:3px 10px}button:disabled{opacity:.45;cursor:default}.paginas{display:flex;gap:10px;align-items:center;justify-content:start;flex-wrap:wrap;font-size:.9rem;margin:13px 0}.rolar{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.92rem}td,th{text-align:left;vertical-align:top;border-bottom:1px solid var(--linha);padding:8px 7px}th{background:#edf2e9}td small{display:block;color:#536659}code{white-space:nowrap}details>summary{color:var(--verde);cursor:pointer;font-weight:600}.metodo p{margin:10px 0}.fim{margin-top:25px}[hidden]{display:none!important}
@media(max-width:1170px){.dica-rolagem{display:inline}}
@media(max-width:805px){main{padding-inline:12px}.rolar-grafico{scrollbar-color:#93aa9c #e6ede6}.prancha{padding-inline:8px}.no{padding:7px 6px 7px 8px}.percentual{font-size:.73rem}.etapas span{font-size:.79rem}}
@media(max-width:540px){nav{gap:6px 12px}.consulta td:not(:first-child){min-width:105px}.cab-grafico{gap:6px}}
@page{size:landscape;margin:12mm}
@media print{body{background:white}main{max-width:none;padding:0}nav,.cab-grafico,.consulta,.fim{display:none}article[data-turno][hidden]{display:block!important}article[data-turno]+article{break-before:page}figure{break-inside:avoid}.prancha{min-width:0}.rolar-grafico{overflow:visible}.fluxo{print-color-adjust:exact;-webkit-print-color-adjust:exact}.metodo{margin-top:6px}}

main p,main figcaption,footer p{text-align:justify;hyphens:auto}
</style>%%ESTILO_PREVIA%%</head><body><main><nav aria-label="Relatórios"><a href="relatorio.html">Relatório ilustrado</a><a href="casos_em_aberto.html">Lista atual dos casos sem explicação</a></nav>
<h1>Desfechos dos títulos repetidos</h1><p>%%TOTAL%% casos nas eleições de 2026. Cada caso corresponde a um título registrado em mais de uma seção no mesmo turno. O cálculo do deslocamento admite até <strong>%%MARGEM%% minutos de diferença entre os relógios das urnas</strong>, com um ajuste fixo por urna em cada caso. <a href="relatorio.html#cenario-relogios">Ver o critério de horário</a>.</p>
<div class="cab-grafico"><div class="chaves" hidden id="seletor" role="group" aria-label="Turno do diagrama"><button type="button" data-ir="1" aria-pressed="true">1º turno</button><button type="button" data-ir="2" aria-pressed="false">2º turno</button></div>
<p class="legenda">Selecione uma contagem para ver os casos. Cada card de erro de digitação usa o total do seu ramo de origem. <span class="dica-rolagem">Deslize para ver todas as etapas.</span></p></div>
%%PAINEIS%%
<section id="consulta" class="consulta" hidden aria-labelledby="consulta-titulo"><h2 id="consulta-titulo">Casos do fluxo selecionado</h2><p class="resumo" id="grupo"></p>
<p>Os 12 algarismos reproduzem o número digitado na urna, inclusive os zeros à esquerda. A linha de registro de presença no log público do TSE contém o número sem o nome do titular.</p>
<fieldset class="filtro-geo" id="filtro-geo" hidden><legend>Municípios e zonas eleitorais das seções</legend><div>%%OPCOES_GEO%%</div></fieldset>
<div class="ferramentas"><label>Buscar título, município, seção ou ID<input id="busca" type="search" autocomplete="off"></label></div>
<div class="rolar"><table><thead><tr><th>Turno</th><th>Título registrado</th><th>Seções</th><th>Desfecho</th></tr></thead><tbody id="linhas"></tbody></table></div>
<div class="paginas"><button type="button" class="controle" id="anterior">Anterior</button><span id="paginacao" aria-live="polite"></span><button type="button" class="controle" id="proxima">Próxima</button></div></section>
<section class="metodo"><details open><summary>Como ler as categorias</summary><p>Em cada turno, a espessura das faixas acompanha a quantidade de casos. A coluna de desfechos mostra cada caso em locais distintos uma vez. O percentual usa o total do ramo de origem. Quando um desfecho reúne mais de um ramo, a base são todos os casos em locais distintos do turno. A divisão por município e zona considera apenas os deslocamentos improváveis que permanecem sem explicação. A divisão por estado usa como base os casos desse grupo em municípios e zonas diferentes.</p>
<p>%%RESUMO%% Os locais de votação seguem o cadastro do TSE de 25 de outubro.</p>
<p>Quando as seções ficam em locais distintos, a comparação dos títulos registrados como mesário tem prioridade no desfecho. Isso inclui casos em que o intervalo permite o deslocamento. A triagem considera pares a até duas operações de digitação e os pares com evidência forte documentada nas fichas. As ocorrências de um número somente como título de eleitor ficam fora dessa comparação. A categoria de remanejamento plausível reúne os trajetos compatíveis em que a comparação das equipes não identificou indício de digitação. Selecione a contagem para consultar a lista e abra um título para conferir a comparação entre as urnas.</p>
<p>%%NOTA_INDICIOS%%Em “Sem evidência de erro de digitação”, a comparação das listas não identificou outro título que explicasse o registro. Para os casos que seguem em aberto, o diagrama mostra a localização das seções. Quando os municípios e as zonas diferem, o diagrama distingue os casos restritos à mesma UF dos que envolvem mais de uma.</p>
<p>A ata da mesa permite conferir um remanejamento específico.</p>%%SUPLEMENTO%%
<nav class="fim"><a href="dados/secoes_por_caso.csv">Seções de cada caso</a><a href="dados/duas_edicoes_casos.csv">Teste de digitação</a><a href="dados/relatorio/deslocamento_possivel.csv" download>Deslocamentos possíveis</a><a href="dados/relatorio/deslocamento_improvavel.csv" download>Deslocamentos improváveis por turno</a></nav></details></section></main>
<script type="application/json" id="dados">%%DADOS%%</script>
%%CONTROLES_PREVIA%%
<script>
(()=>{
  const el=id=>document.getElementById(id);
  const [lugares,casos]=JSON.parse(el('dados').textContent);
  const botoes=document.querySelectorAll('button.no[data-campo][data-valor][data-turno]');
  const nomesTempo=new Map([...botoes].filter(b=>b.dataset.campo==='tempo')
    .map(b=>[b.dataset.valor,b.querySelector('.nome').textContent]));
  const paineis=document.querySelectorAll('article[data-turno]');
  const turnos=el('seletor').querySelectorAll('button[data-ir]');
  const cabecalho=el('consulta-titulo');
  const filtroGeo=el('filtro-geo');
  const opcoesGeo=filtroGeo.querySelectorAll('input');
  cabecalho.tabIndex=-1;
  cabecalho.setAttribute('aria-describedby','grupo');
  const tamanho=20;
  const simples=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  let selecionado, conjunto=[],filtrados=[],pagina=0;
  function corresponde(c,{turno,campo,valor,tempo}){
    if(c[0]!==turno || (tempo && c[8]!==tempo))return false;
    switch(campo){
      case 'todos':return true;
      case 'tempo':return valor===c[8];
      case 'outros-indicios':return !c[6] && c[4]==='Indício numérico inconclusivo';
      case 'locais':return valor===(c[4]?'Locais distintos':'Mesmo local');
      case 'grupo':return valor===c[4];
      case 'desfecho':return valor===c[5];
      case 'geografia':return valor===c[10];
      case 'estado':return valor===c[13];
      default:return false;
    }
  }
  function texto(tag,s){const t=document.createElement(tag);t.textContent=s;return t}
  function mostrar(){
    const body=el('linhas');body.replaceChildren();
    const inicio=pagina*tamanho;
    filtrados.slice(inicio,inicio+tamanho).forEach(c=>{
      const linha=document.createElement('tr'),titulo=document.createElement('td'),lugar=document.createElement('td'),desfecho=document.createElement('td');
      const numero=texto('code',c[1]);
      if(c[4]){
        const link=document.createElement('a');link.href='relatorio_tecnico.html#f-'+c[0]+'-'+c[2].toLowerCase();
        if(c[9])link.dataset.equipePrever=c[0]+'-'+c[2].toLowerCase();
        link.append(numero);titulo.append(link);
      }else{titulo.append(numero)}
      titulo.append(texto('small','Referência · '+c[2]));
      lugar.textContent=lugares[c[3]];desfecho.textContent=c[5]||'Seções no mesmo local';
      if(c[10] && (!filtroGeo.hidden || ['geografia','estado'].includes(selecionado.dataset.campo))){
        const municipio=c[11]?'Mesmo município':'Municípios diferentes';
        const zona=c[12]?'mesma zona':'zonas diferentes';
        lugar.append(texto('small',[municipio,zona,c[13]].filter(Boolean).join(' · ')));
      }
      if(c[8]||c[7]){
        const notas=document.createElement('details');notas.append(texto('summary','Detalhes da ficha'));desfecho.append(notas);
        if(c[8])notas.append(texto('small','Tempo para o deslocamento · '+c[8]));
        if(c[7])notas.append(texto('small',c[7]));
      }
      linha.append(texto('td',c[0]+'º'),titulo,lugar,desfecho);body.append(linha);
    });
    el('paginacao').textContent=filtrados.length?(inicio+1)+'–'+Math.min(inicio+tamanho,filtrados.length)+' de '+filtrados.length.toLocaleString('pt-BR'):'Nenhum caso encontrado';
    el('anterior').disabled=pagina===0;el('proxima').disabled=inicio+tamanho>=filtrados.length;
  }
  function filtrar(){const termos=simples(el('busca').value.trim()).split(/\s+/).filter(Boolean);
    const geo=filtroGeo.hidden?'':filtroGeo.querySelector('input:checked').value;
    filtrados=conjunto.filter(c=>{
      if(geo && c[10]!==geo)return false;
      const s=simples([c[1],c[2],lugares[c[3]],c[5],c[7]].join(' '));return termos.every(t=>s.includes(t));
    });pagina=0;mostrar()}
  function ativar(botao,rolar){
    if(selecionado){
      selecionado.setAttribute('aria-pressed','false');
      selecionado.classList.remove('selecionado');
    }
    selecionado=botao;
    botao.setAttribute('aria-pressed','true');
    botao.classList.add('selecionado');
    const {turno,campo,valor,tempo}=botao.dataset;
    conjunto=casos.filter(c=>corresponde(c,botao.dataset));
    filtroGeo.hidden=!(conjunto.length && (campo==='grupo' || campo==='desfecho') && conjunto.every(c=>c[10]));
    if(!filtroGeo.hidden){
      for(const opcao of opcoesGeo){
        const quantidade=opcao.value?conjunto.filter(c=>c[10]===opcao.value).length:conjunto.length;
        opcao.labels[0].querySelector('span').textContent=quantidade;
        opcao.checked=!opcao.value;
        opcao.disabled=!quantidade;
      }
    }
    el('busca').value='';
    const descricao=[turno+'º turno'];
    if(campo==='estado')descricao.push(conjunto[0][10]);
    if(tempo)descricao.push(nomesTempo.get(tempo));
    if(campo!=='todos')descricao.push(valor);
    descricao.push(conjunto.length.toLocaleString('pt-BR')+(conjunto.length===1?' caso':' casos'));el('grupo').textContent=descricao.join(' · ');
    filtrar();
    if(rolar){
      cabecalho.focus({preventScroll:true});
      cabecalho.scrollIntoView({block:'start'});
    }
  }
  botoes.forEach(b=>{
    b.setAttribute('aria-pressed','false');
    b.setAttribute('aria-controls','consulta');
    b.addEventListener('click',()=>ativar(b,true));
  });
  function mudarTurno(turno){
    for(const painel of paineis)painel.hidden=painel.dataset.turno!==turno;
    for(const botao of turnos)botao.setAttribute('aria-pressed',String(botao.dataset.ir===turno));
    const inicio=document.querySelector(`button.no[data-turno="${turno}"][data-campo="todos"]`);
    ativar(inicio,false);
  }
  turnos.forEach(b=>b.addEventListener('click',()=>{
    if(b.dataset.ir!==selecionado.dataset.turno)mudarTurno(b.dataset.ir);
  }));
  el('busca').addEventListener('input',filtrar);
  filtroGeo.addEventListener('change',filtrar);
  el('proxima').addEventListener('click',()=>{pagina++;mostrar()});el('anterior').addEventListener('click',()=>{pagina--;mostrar()});
  el('consulta').hidden=false;
  el('seletor').hidden=false;
  mudarTurno('1');
})();
</script></body></html>"""
