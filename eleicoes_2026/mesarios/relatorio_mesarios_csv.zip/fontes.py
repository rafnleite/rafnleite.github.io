"""Prepara o recorte da Arvor e conserva cada pacote oficial de log com SHA-256.

python fontes.py preparar       # lê dados/arvor.zip ou baixa a edição indicada
python fontes.py baixar         # reiniciável, confere o ZIP e conserva downloads.csv
"""
import argparse
import csv
import hashlib
import http.client
import io
import json
import os
import re
import ssl
import sys
import tempfile
import time
import urllib.request
import zipfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "dados"
sys.path.insert(0, str(ROOT.parent / "logs-urnas"))
from extrair_logs import source_log
from transporte_tse import PersistentHTTPS

ARVOR = "https://brasil.arvor.co/auditoria-2026/mesarios/dados.zip"
ARVOR_SHA = "dd169030b61b9f25bb209256b95d5f6aa39cf00f1187f0851d1cc1aaafdef67a"
OFICIAL = "https://resultados.tse.jus.br/oficial/ele2026/arquivo-urna"
FIELDS = ("turno uf codigo_municipio zona secao arquivo sha256 municipio local nome latitude longitude "
          "ids escopo url_log sha256_referencia prioridade").split()


def write_csv(path, fields, rows):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", newline="", encoding="utf-8-sig") as fout:
        writer = csv.DictWriter(fout, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(path)


def csv_file(path):
    with path.open(encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))


def csv_member(z, name):
    with io.TextIOWrapper(z.open(name), encoding="utf-8-sig", newline="") as src:
        return list(csv.DictReader(src))


def ids(value):
    return re.findall(r"M-[A-F0-9]{12}", value)


def key(turn, uf, mun, zone, section):
    return int(turn), uf.upper(), str(int(mun)).zfill(5), int(zone), int(section)


def create_row(k, municipio="", nome=""):
    turn, uf, mun, zone, section = k
    fname = f"o{3219+turn:05}{uf.lower()}{mun}{zone:04}{section:04}-log.jez"
    return dict(zip(FIELDS[:5], k), arquivo=f"logs/{turn}/{uf}/{fname}",
                sha256="", municipio=municipio, local="", nome=nome, latitude="", longitude="",
                ids="", escopo=set(), url_log="", sha256_referencia="", prioridade=3)


def consolidate(manifest, verified):
    addresses = DATA/"enderecos.csv"
    locations = {tuple(str(r[f]) for f in FIELDS[:5]):r for r in csv_file(addresses)} if addresses.exists() else {}
    for row in manifest:
        location = locations.get(tuple(str(row[f]) for f in FIELDS[:5]))
        if location and (not row["local"] or row["local"] == location["local"]):
            for field in ("local","nome"):
                if not row[field]:
                    row[field] = location[field]
        record = verified.get(row["arquivo"])
        if not record or record.get("erro") or not record.get("sha256"):
            continue
        if row["sha256_referencia"] and row["sha256_referencia"] != record["sha256"]:
            raise ValueError("Hash publicado incompatível com a verificação anterior.")
        row.update(sha256=record["sha256"], url_log=record["url_log"])
    write_csv(DATA/"manifesto.csv", FIELDS, manifest)


def prepare():
    import openpyxl

    DATA.mkdir(exist_ok=True)
    package = DATA / "arvor.zip"
    if not package.exists():
        with urllib.request.urlopen(ARVOR, timeout=90) as resp:
            buf = resp.read(32 * 1024 * 1024)
        if hashlib.sha256(buf).hexdigest() != ARVOR_SHA:
            raise ValueError("Pacote da Arvor difere da edição de referência.")
        package.write_bytes(buf)
    if hashlib.sha256(package.read_bytes()).hexdigest() != ARVOR_SHA:
        raise ValueError("SHA-256 do pacote da Arvor divergente.")
    rows = {}
    id_keys = defaultdict(set)
    city_lookup = {}
    coords = {}
    reference = {}
    links = []
    with zipfile.ZipFile(package) as z:
        for loc in csv_member(z, "locais.csv"):
            coords[(int(loc["turno"]), loc["uf"].upper(), loc["codigo_municipio"],
                    int(loc["zona"]), loc["local"])] = loc["latitude"], loc["longitude"]
        for r in csv_member(z, "fontes_municipios.csv"):
            reference[r["url"]] = r["sha256"]
        for r in csv_member(z, "registros_sp_zona_254.csv"):
            reference[r["URL do log"]] = r["SHA-256 do arquivo conferido"]
        for r in csv_member(z, "votos_por_secao.csv"):
            k = key(r["turno"],r["uf"],r["mun"],r["zona"],r["secao"])
            if k in rows:
                raise ValueError(f"Seção repetida na base publicada: {k}")
            city_lookup[(k[1], r["municipio"])] = k[2]
            lat, lon = coords.get((*k[:4],r["local"]), ("",""))
            row = create_row(k, r["municipio"], r["nome"])
            row.update(local=r["local"], latitude=lat, longitude=lon, url_log=r["url_log"],
                       sha256_referencia=reference.get(r["url_log"], ""), ids=" ".join(ids(r["IDs"])))
            row["escopo"].add("repeticao")
            rows[k] = row
            for ident in ids(r["IDs"]):
                id_keys[k[0],ident].add(k)
        # O código municipal nem sempre ocorre nas seções repetidas. Os cadastros
        # de resultados do TSE da cópia local trazem municípios de todo o Brasil.
        for loc in csv_member(z, "locais.csv"):
            city_lookup[(loc["uf"].upper(),loc["municipio"])] = loc["codigo_municipio"]
        workbook = openpyxl.load_workbook(io.BytesIO(z.read("mesarios_por_secao.xlsx")),
                                          read_only=True,data_only=True)
        all_sections = list(workbook["Seções"].values)[5:]
        workbook.close()
    missing = {(uf, city) for ident, turn, uf, city, *_ in all_sections
               if (uf,city) not in city_lookup}
    # Normalmente a inscrição já pertence ao mesmo município de alguma repetição.
    # Complementa municípios com os cadastros estaduais se necessário.
    for uf, city in sorted(missing):
        import sqlite3
        db = ROOT.parent / "logs-urnas/dados-logs/votos_2026_2t.sqlite3"
        if db.exists():
            with sqlite3.connect(db.resolve().as_uri()+"?mode=ro",uri=True) as cx:
                found = cx.execute("select distinct municipio_codigo from secoes where uf=? and municipio=?",
                                   (uf,city)).fetchall()
            if len(found)==1:
                city_lookup[(uf,city)] = str(found[0][0]).zfill(5)
        if (uf,city) not in city_lookup:
            cfg = DATA / f"municipios_{uf}.json"
            if not cfg.exists():
                url = f"{OFICIAL}/3221/config/{uf.lower()}/{uf.lower()}-p003221-cs.json"
                with urllib.request.urlopen(url,timeout=30) as resp:
                    cfg.write_bytes(resp.read())
            for record in json.loads(cfg.read_bytes())["abr"][0]["mu"]:
                city_lookup[(uf,record["nm"].upper())] = str(int(record["cd"])).zfill(5)
            if (uf,city) not in city_lookup:
                raise ValueError(f"Município sem código confirmado: {city}/{uf}")

    for ident, turn, uf, city, zone, sec, name, records, enabled in all_sections:
        k = key(turn,uf,city_lookup[uf,city],zone,sec)
        row = rows.setdefault(k,create_row(k,city,name))
        if k not in id_keys[(turn,ident)]:
            row["escopo"].add("registro_isolado")
        links.append(dict(zip(FIELDS[:5],k), id=ident,registros=records,habilitacoes=enabled))
    distinct_groups = 0
    for (turn, ident), keys in id_keys.items():
        if len(keys)>1 and len({(*k[1:4],rows[k]["local"]) for k in keys})>1:
            distinct_groups += 1
            for k in keys:
                rows[k]["prioridade"] = 0
                twin = (3-turn,*k[1:])
                other = rows.setdefault(twin,create_row(twin,rows[k]["municipio"]))
                other["escopo"].add("contraste_outro_turno")
                other["prioridade"] = min(other["prioridade"],1)
    for row in rows.values():
        if "repeticao" in row["escopo"]:
            row["prioridade"] = min(row["prioridade"], 2)
        row["escopo"] = " ".join(sorted(row["escopo"]))
        row["sha256"] = row["sha256_referencia"]
    with zipfile.ZipFile(package) as z:
        list_ids = {r["ID de auditoria"]:(int(r["Seções 1º T"]),int(r["Seções 2º T"]))
                    for r in csv_member(z,"lista_mesarios.csv")}
    counts = Counter((r["turno"],r["id"]) for r in links)
    if any(counts[t,i] != pair[t-1] for i,pair in list_ids.items() for t in (1,2)):
        raise ValueError("Os vínculos da planilha divergem da contagem por ID/turno.")
    if sum("repeticao" in r["escopo"] for r in rows.values()) != 16748 or distinct_groups != 698:
        raise ValueError("Cobertura diferente dos totais publicados.")
    write_csv(DATA/"vinculos.csv", [*FIELDS[:5],"id","registros","habilitacoes"], links)
    ledger = DATA/"downloads.csv"
    verified = {r["arquivo"]:r for r in csv_file(ledger)} if ledger.exists() else {}
    consolidate(sorted(rows.values(),key=lambda r:(r["prioridade"],*(r[f] for f in FIELDS[:5]))),verified)
    print(f"{len(rows)} pacotes, {len(links)} vínculos, {distinct_groups} IDs-turno entre locais.",flush=True)


def official_url(row, get):
    turn,uf,mun,zone,section = (row[f] for f in FIELDS[:5])
    contest = 3219 + int(turn)
    uf = uf.lower()
    base = f"{OFICIAL}/{contest}/dados/{uf}/{mun}/{int(zone):04}/{int(section):04}"
    name = Path(row["arquivo"]).name
    if row["url_log"]:
        if not re.fullmatch(re.escape(base)+r"/[0-9a-fA-F]+/"+re.escape(name),row["url_log"]):
            raise ValueError("URL incompatível com a identidade da seção.")
        return row["url_log"]
    aux = f"{base}/p{contest:06}-{uf}-m{mun}-z{int(zone):04}-s{int(section):04}-aux.json"
    selected, state = source_log(json.loads(get(aux)),SimpleNamespace(contest=contest),
                                 dict(uf=uf,municipio_codigo=int(mun), zona=int(zone),secao=int(section)))
    if selected is None:
        raise ValueError(f"Auxiliar sem log da seção ({state})")
    return f"{base}/{selected[0]}/{selected[1]}"


def cached_sources():
    mapped = {}
    for src in (ROOT.parent/"logs-urnas/relatorios").glob("*/fontes.json"):
        if not (src.parent/"pacotes").exists():
            continue
        for r in json.loads(src.read_bytes()):
            name = (f"{r['uf'].lower()}-{r['municipio_codigo']:05}-z{r['zona']:04}-"
                    f"s{r['secao']:04}-{r['sha256'][:12]}.jez")
            path = src.parent/"pacotes"/name
            mapped[r["url"]] = path, r["sha256"]
    return mapped


def verify(data, hashes):
    digest = hashlib.sha256(data).hexdigest()
    if any(ref and ref != digest for ref in hashes):
        raise ValueError(f"SHA-256 divergente: {digest}")
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        # Alguns pacotes reúnem mais de uma urna em ZIPs internos.
        if not any(n.lower().endswith((".dat", ".jez", ".zip")) for n in archive.namelist()):
            raise ValueError("ZIP sem membro de log.")
        if archive.testzip():
            raise ValueError("CRC inválido.")
    return digest


def download(workers, pending_only=False):
    manifest = csv_file(DATA/"manifesto.csv")
    ledger = DATA/"downloads.csv"
    fields = [*FIELDS[:5],"arquivo","sha256","bytes","url_log","origem","sha256_referencia","erro"]
    previous = {r["arquivo"]:r for r in csv_file(ledger) if not r["erro"]} if ledger.exists() else {}
    for r in manifest:
        prior = previous.get(r["arquivo"],{})
        if prior.get("url_log"):
            r["url_log"] = prior["url_log"]
    cache = cached_sources()
    transport = PersistentHTTPS(timeout=30,context=ssl.create_default_context())

    def get(url):
        for attempt in range(5):
            try:
                with transport.open(url,headers={"User-Agent":"AuditoriaMesarios2026/1.0", "Accept-Encoding":"identity"}) as resp:
                    # HTTPResponse diferencia read(None) de read(-1) sob chunked.
                    data = resp.read(None)
                if not data or len(data)>32*1024*1024:
                    raise ValueError("Tamanho inesperado do arquivo.")
                return data
            except (OSError, EOFError, http.client.HTTPException) as err:
                if getattr(err,"code",None) in (400,401,403,404) or attempt==4:
                    raise
                time.sleep(2**attempt)

    def fetch(row):
        result = {**row,"erro":"","bytes":"","origem":""}
        dest = DATA / row["arquivo"]
        try:
            url = official_url(row,get)
            result["url_log"] = url
            old = previous.get(row["arquivo"],{})
            hashes = [row.get("sha256"),row["sha256_referencia"],old.get("sha256"),cache.get(url,("",None))[1]]
            source = None
            if dest.exists():
                source = dest
                origem = old.get("origem") or "cache de download"
            elif url in cache and cache[url][0].exists():
                source = cache[url][0]
                origem = "cache oficial local"
            if source:
                try:
                    data = source.read_bytes()
                    sha = verify(data, hashes)
                except (OSError, ValueError, zipfile.BadZipFile):
                    source = None
            if source is None:
                data = get(url)
                origem = "TSE"
                sha = verify(data, hashes)
            if source != dest:
                dest.parent.mkdir(parents=True,exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=dest.parent,delete=False) as tmp:
                    tmp.write(data)
                os.replace(tmp.name,dest)
            result.update(sha256=sha,bytes=len(data),origem=origem)
        except Exception as exc:
            result.update(erro=f"{type(exc).__name__}: {exc}")
        return result

    complete = {}
    if pending_only:
        for row in manifest:
            old = previous.get(row["arquivo"])
            dest = DATA/row["arquivo"]
            if old and dest.is_file() and dest.stat().st_size == int(old["bytes"]):
                complete[row["arquivo"]] = old
    try:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            jobs = [pool.submit(fetch,r) for r in manifest if r["arquivo"] not in complete]
            for future in as_completed(jobs):
                row = future.result()
                complete[row["arquivo"]] = row
                if len(complete)%1000==0:
                    print(f"{len(complete):,}/{len(manifest):,} ({sum(bool(v['erro']) for v in complete.values())} erros)",flush=True)
    finally:
        transport.close()
        write_csv(ledger,fields,({**r,**complete.get(r["arquivo"],previous.get(r["arquivo"],{"erro":"pendente"}))}
                                 for r in manifest))
        consolidate(manifest,{**previous,**complete})
    errors = sum(bool(r["erro"]) for r in complete.values())
    print(f"{len(complete)} concluídos, {errors} com erro.",flush=True)
    if errors:
        raise SystemExit(1)


if __name__=="__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("etapa",choices=("preparar","baixar"))
    p.add_argument("--conexoes",type=int,default=24,choices=range(1,65),metavar="1–64")
    p.add_argument("--somente-pendentes", action="store_true",
                   help="retoma falhas e arquivos ausentes ou com tamanho alterado; reutiliza verificações registradas")
    args = p.parse_args()
    if args.etapa=="preparar":
        prepare()
    else:
        download(args.conexoes, args.somente_pendentes)
