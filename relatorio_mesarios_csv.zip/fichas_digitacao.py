"""Fichas dos títulos semelhantes nas viagens curtas ou extremas do cadastro de 25/10.

Executar este módulo para conferir novamente os pacotes JEZ e atualizar o extrato.
preparar_fichas() devolve {(turno, titulo): {html, forca, subtitulo, ...}}.
"""
from collections import Counter, defaultdict
from html import escape
import json
from pathlib import Path
from tempfile import NamedTemporaryFile

from casos_em_aberto import NOTAS, chave, decimal, secao, tempo, trecho_principal
from exemplos_ilustrados import ler_secao, linhas
from extrair import BASE, identify
from ilustracoes import ESTILO as ESTILO_DIGITOS, cartao_candidato, painel_casa_nova, rotulos_mesarios
from logistica import CURTO, EXTREMO
from sankey_casos import QUATRO_PONTES


ARQUIVO = BASE / "evidencia_fichas_digitacao.json"
GOIANESIA = "M-56737337C02A"
CASA_NOVA = "M-DAB0A007A18D"
CANDIDATOS_TRES = {
    QUATRO_PONTES: "109699530604",
    "M-7D65F5D2F1F5": "013587111406",
    "M-6991E2FC1BB9": "355001420108",
}
ETAPAS = ("abertura", "encerramento")
ESTILO = ESTILO_DIGITOS + """
.ficha-dig .tit-comparacao{max-width:100%}
"""


def extrair():
    classes = {chave(r): r["avaliacao"] for r in linhas("logistica_por_caso_revisao.csv")
               if r["avaliacao"] in (EXTREMO, CURTO)}
    pares = defaultdict(dict)
    for r in linhas("duas_edicoes_pares.csv"):
        k = chave(r)
        if k not in classes or r["fonte"] != "registro":
            continue
        terceira = r["titulo_alternativo"] == CANDIDATOS_TRES.get(r["id_caso"]) and r["distancia_levenshtein"] == "3"
        if r["custo_ampliado"] not in ("1","2") and not terceira:
            continue
        mesa = identify(r)[1:]
        alternativo = r["titulo_alternativo"]
        linha = pares[k].setdefault((mesa,alternativo),r)
        if (r["caminho_usual"],r["caminho_ampliado"]) != (linha["caminho_usual"],linha["caminho_ampliado"]):
            raise ValueError("Caminhos divergentes entre os turnos da fonte")
    mesas = defaultdict(set)
    for r in linhas("comparacao_secoes.csv"):
        if chave(r) in pares:
            mesas[chave(r)].add(identify(r)[1:])
    trechos = defaultdict(list)
    for r in linhas("trajetos_por_evento_revisao.csv"):
        if chave(r) in pares:
            trechos[chave(r)].append(r)
    pedidas = {(t,*s) for secoes in mesas.values() for s in secoes for t in ("1","2")}
    fontes = {identify(r):r for r in linhas("manifesto.csv") if identify(r) in pedidas}
    enderecos = {identify(r):r for r in linhas("enderecos.csv") if identify(r) in pedidas}
    qualificados = defaultdict(Counter)
    for r in linhas("registros_qualificados.csv"):
        k=identify(r)
        if k in pedidas:
            ref=(r["titulo"],r["data_hora"],r["urna"],r["tipo"],r["membro"],int(r["linha"]))
            qualificados[k][ref]+=1
    if set(fontes) != pedidas or set(enderecos) != pedidas:
        raise ValueError(f"Seções sem pacote ou cadastro: {pedidas-set(fontes) | pedidas-set(enderecos)}")
    fontes_conferidas = {}
    for k in sorted(pedidas):
        titulos = {ref[0] for ref in qualificados[k]}
        fontes_conferidas[k] = ler_secao(fontes[k], enderecos[k], titulos, qualificados[k])
    dados=[]
    for k, grupo in sorted(pares.items()):
        if len(grupo)!=1 or len(mesas[k])!=2:
            raise ValueError(f"Rever os candidatos ou o número de seções do caso {k}")
        (mesa,alt),r=next(iter(grupo.items()))
        rep=k[1]
        registros=[]
        for t in ("1","2"):
            for local in sorted(mesas[k],key=lambda s:(s!=mesa,s)):
                evidencia=fontes_conferidas[(t,*local)]
                e={campo:evidencia[campo] for campo in ("turno","uf","municipio","zona","secao","endereco","nome",
                            "urnas","arquivo","sha256","url_log","registros")}
                e["mesa_alternativo"] = local==mesa
                e["habilitacoes"] = [ev for ev in evidencia["habilitacoes"] if ev["titulo"] in (rep,alt)]
                registros.append(e)
        dados.append(dict(turno=k[0],titulo=rep,id_caso=r["id_caso"],alternativo=alt,
                          caminho=json.loads(r["caminho_usual"] or r["caminho_ampliado"] or "[]"),
                          operacoes=int(r["custo_usual"] or r["custo_ampliado"] or 3),
                          classe=classes[k],trecho=trecho_principal(trechos[k],classes[k]),secoes=registros))
    if {c["id_caso"] for c in dados if c["operacoes"]==3} != set(CANDIDATOS_TRES):
        raise ValueError("Faltou algum candidato da revisão contextual")
    return dados


def atualizar():
    """Lê cada JEZ requerido, confere o SHA e as linhas contra o índice e grava o extrato."""
    dados=extrair()
    with NamedTemporaryFile("w",encoding="utf-8",dir=BASE,delete=False) as f:
        tmp=Path(f.name)
        try:
            json.dump(dados,f,ensure_ascii=False,separators=(",",":"))
            f.write("\n")
        except Exception:
            f.close()
            tmp.unlink(missing_ok=True)
            raise
    try:
        tmp.replace(ARQUIVO)
    finally:
        tmp.unlink(missing_ok=True)
    return dados


def cod(valor):
    return f"<code>{escape(valor)}</code>"


def equipe(mesa, etapa):
    return {e["titulo"] for e in mesa["registros"] if e["etapa"]==etapa}


def turno_mesa(c, no_turno, local):
    return next(s for s in c["secoes"] if (str(s["turno"])==c["turno"])==no_turno and s["mesa_alternativo"]==local)


def qualificar(c):
    """Avalia as duas grafias nas fontes verificadas das seções e dos turnos."""
    r, a = c["titulo"], c["alternativo"]
    par = {r, a}
    local = turno_mesa(c, True, True)
    outra_data = turno_mesa(c, False, True)
    outra_secao = turno_mesa(c, True, False)
    outra_secao_outra_data = turno_mesa(c, False, False)

    def grafias(mesa):
        return {e["titulo"] for e in mesa["registros"]} & par

    if grafias(outra_data) == par:
        return "indicio", "Os dois títulos também coexistem na mesma seção no outro turno"
    if grafias(outra_data) != {a} or grafias(outra_secao) != {r} or a in grafias(outra_secao_outra_data):
        return "indicio", "Os registros das duas seções não permitem atribuir a troca"

    abertura, fecho = (equipe(local, etapa) & par for etapa in ETAPAS)
    if (abertura, fecho) in (({a}, {r}), ({r}, {a})):
        return "forte", "As grafias se alternam entre abertura e encerramento, com confirmação no outro turno"
    if grafias(local) == {r} and any(r in equipe(local, etapa) and a in equipe(outra_data, etapa) for etapa in ETAPAS):
        return "forte", "As grafias se alternam entre os turnos na mesma etapa da seção"

    repetidos = [e for e in local["registros"] if e["titulo"] == r]
    if (c["operacoes"] <= 3 and len(repetidos) == 1 and par <= abertura and fecho == {a}
            and equipe(local, "abertura") - {r} == equipe(local, "encerramento")
            and all(a in equipe(outra_data, etapa) for etapa in ETAPAS)
            and r in grafias(outra_secao_outra_data)):
        extra = repetidos[0]
        if any(e["titulo"] == a and (e["urna"], e["membro"], e["linha_marcador"]) ==
               (extra["urna"], extra["membro"], extra["linha_marcador"]) and e["linha"] > extra["linha"]
               for e in local["registros"]):
            return "forte", "O título repetido é a única presença adicional na abertura, e a grafia local aparece nas quatro listas"
    if c["operacoes"] <= 2 and len(repetidos) == 1:
        if repetidos[0]["etapa"] == "durante a votação" and a in abertura and any(
                e["titulo"] == a for e in local["habilitacoes"]):
            return "forte", "Registro isolado durante a votação, com a grafia local corroborada pelas habilitações"
        eventos = sorted(local["registros"], key=lambda e: (e["data_hora"], e["membro"], int(e["linha"])))
        for antes, depois in zip(eventos, eventos[1:]):
            if (antes["titulo"] == a and depois["titulo"] == r
                    and antes["etapa"] == depois["etapa"] == "registro pelo menu de votação"
                    and (antes["urna"], antes["membro"], antes["linha_marcador"])
                    == (depois["urna"], depois["membro"], depois["linha_marcador"])):
                return "forte", "Grafias consecutivas no mesmo ciclo do menu, corroboradas pelo outro turno"
    if par <= abertura or par <= fecho:
        return "indicio", "As duas grafias foram registradas na mesma etapa, sem uma substituição identificável"
    return "indicio", "A semelhança numérica não localiza a digitação que originou o registro"


def figura(c, *, erro_forte):
    a,r = c["alternativo"],c["titulo"]
    secao_alternativo = turno_mesa(c, True, True)
    secao_referencia = turno_mesa(c, True, False)
    rotulos = rotulos_mesarios(secao_alternativo, secao_referencia)
    if c["id_caso"]==CASA_NOVA:
        return painel_casa_nova(rotulos, erro_forte=erro_forte)
    caminho = c["caminho"]
    if c["operacoes"]==3:
        dif=[i for i,(v,z) in enumerate(zip(a,r,strict=True)) if v!=z]
        if len(dif)!=3:
            raise ValueError("Rever o alinhamento a três substituições")
        corrente=a
        caminho=[]
        for i in dif:
            depois=corrente[:i]+r[i]+corrente[i+1:]
            caminho.append(dict(tipo="substituicao",antes=corrente,depois=depois,posicoes=[i+1]))
            corrente=depois
    return cartao_candidato({"titulo_alternativo":a,"titulo":r,"caminho_usual":caminho}, rotulos,
                            erro_forte=erro_forte)


def particularidade(c):
    ident,r,a = c["id_caso"],c["titulo"],c["alternativo"]
    local=turno_mesa(c, True, True)
    anterior=turno_mesa(c, False, True)
    outra=turno_mesa(c, True, False)
    abertura,fecho = (equipe(local,x) for x in ETAPAS)
    if ident==GOIANESIA:
        return (f"Em Goianésia, {cod(r)} aparece tanto na abertura quanto no encerramento do 1º turno. "
                f"Na mesma seção, {cod(a)} aparece nas duas etapas do 2º. Os mesmos outros três títulos acompanham ambas "
                "as grafias nas quatro listas. O número de Ataléia também aparece nas duas etapas dos dois turnos. "
                "Essa continuidade aponta para a omissão do 2 da quarta posição em duas digitações no 1º turno.")
    if ident==CASA_NOVA:
        return (f"Em Casa Nova, o número da abertura do 2º turno foi {cod(a)} e recebeu quatro habilitações. "
                f"No encerramento, entrou {cod(r)}. Foram mantidos os mesmos outros três títulos. "
                "Omitir o 3 da segunda posição e duplicar o 2 da sétima posição original reproduz o número de Porto Seguro. "
                "As duas mesas o registraram no encerramento com apenas 21 segundos de diferença.")
    if ident=="M-CB8776247A86":
        return (f"Na abertura do 2º turno em Buriti dos Montes (Z34, S33), às 07:39:32, a urna registrou {cod(r)} "
                "e informou que o titular não era eleitor daquela seção (linhas 6057–6058). "
                f"No encerramento, às 17:02:56, registrou {cod(a)} e o identificou como eleitor da própria seção "
                "(linhas 9265–9266). Esse título já constava na abertura e no encerramento do 1º turno em Buriti "
                f"(linhas 658 e 5430). Em Milton Brandão (Z12, S210), a urna identifica {cod(r)} como título de eleitor "
                "da seção nas quatro listas (linhas 643–644 e 4586–4587 no 1º turno, 5196–5197 e 7592–7593 no 2º). "
                "A sequência indica que na abertura de Buriti foi digitado <strong>4 no lugar de 1 na sexta posição</strong>. "
                "Essa troca preserva os dois dígitos verificadores (03). A soma usada no primeiro passa de 132 para 153. "
                "Os restos da divisão por 11 são 0 e 10, e ambos produzem o dígito 0 para o código de UF 15. "
                "Com a mesma UF e o mesmo primeiro verificador, o segundo continua 3.")
    if ident=="M-6991E2FC1BB9":
        return (f"Em São Paulo (Z257, S168), {cod(r)} aparece apenas na abertura do 1º turno (linha 560). "
                f"Às 17:08:23, a urna registrou {cod(a)} no encerramento (linha 6751). Essa grafia voltou no "
                f"encerramento do 2º turno. Em São Miguel Arcanjo, {cod(r)} aparece nas quatro listas de abertura "
                "e encerramento. Mudar os três algarismos do prefixo 3550 para 3335 reproduz o título registrado "
                "na abertura paulistana. Há ainda uma segunda omissão aparente na mesma mesa, "
                f"entre {cod('311676790116')} e {cod('031167690116')}.")
    if ident=="M-7D65F5D2F1F5":
        return (f"Em Santa Teresa (zona 11, seção 55), {cod(a)} consta na abertura e no encerramento dos dois turnos "
                "(linhas 630 e 5463 no 1º turno, 6232 e 9926 no 2º). Na abertura do 2º turno, a urna registrou "
                f"também {cod(r)} às 07:26:07 (linha 6221). Dos cinco títulos registrados, esse foi o único que "
                "não reapareceu no encerramento. Na própria abertura, a urna registrou outro título às 07:27:01 "
                f"(linha 6227) e, em seguida, {cod(a)} às 07:27:47. "
                f"Em Vila Velha (zona 57, seção 76), {cod(r)} consta nas aberturas dos dois turnos e no "
                "encerramento do 2º. A urna atribuiu a esse número seis habilitações de eleitores no 1º turno "
                f"e três no 2º. A comparação aponta para a digitação de <strong>894 no lugar de 711 nas posições "
                "6, 7 e 8</strong> na abertura de Santa Teresa. Os dois registros foram aceitos e o log não "
                "assinala uma correção explícita.")
    if ident in CANDIDATOS_TRES:
        return escape(NOTAS[ident])
    if ident=="M-92F6D4907F6A":
        return (f"A omissão aparece na comparação entre as aberturas de Birigui. A urna gravou {cod(r)} no 1º turno "
                f"e {cod(a)} no 2º. Os outros três títulos são os mesmos nas duas listas. O alternativo só foi registrado "
                "na abertura do 2º turno. A seção de Mauá registra o outro número nas duas etapas dos dois turnos.")
    if ident=="M-3748C6A3A45D":
        return (f"Em Jaboatão dos Guararapes (Z118, S214), a urna registrou {cod(a)} às 07:43:51 "
                f"na abertura do 1º turno (linha 636). Às 17:51:46, no encerramento (linha 7465), entrou {cod(r)}. "
                f"Omitir o 6 da 5ª posição produz {cod('03691250868')}. Duplicar o zero que vem logo depois do 5 "
                f"produz exatamente {cod(r)}. Dos quatro títulos da abertura, dois se repetiram no encerramento. "
                f"O único número novo entre os três do encerramento foi {cod(r)}. O outro título que saiu, "
                f"{cod('045847860809')}, está a nove edições do número registrado. No 2º turno, {cod(a)} voltou "
                "a constar na abertura e no encerramento dessa mesma seção (linhas 8225 e 12303). "
                f"Em Caruaru (Z106, S243), {cod(r)} consta na abertura e no encerramento dos dois turnos. "
                "A sequência dos registros nas duas mesas sustenta a conclusão de erro de digitação no encerramento de Jaboatão.")
    if ident=="M-8428348D675C":
        return (f"Na seção 296 de Maracanaú, {cod(a)} aparece nas duas etapas dos dois turnos. No 2º turno, "
                f"a urna atribuiu cinco habilitações a esse título. Omitir o bloco 58 das posições 7 e 8 e completar "
                f"com zeros à esquerda produz {cod(r)}. Essa grafia aparece uma única vez em Maracanaú, às 17:00:33 "
                "(linha 11220), durante a votação. Às 17:03:25, a urna assinalou uma tentativa de título inválido "
                "(linha 11247). Às 17:03:50, voltou à grafia local no encerramento (linha 11250). "
                "Em Fortaleza, o repetido consta das duas etapas dos dois turnos, inclusive às "
                "17:03:13 daquele dia, apenas 2min40s depois do registro de Maracanaú.")
    if ident=="M-7B5C3C53AC1F":
        return (f"Em Alegre, {cod(a)} aparece nas três listas disponíveis de abertura e encerramento. No 2º turno, "
                "a urna atribuiu 13 habilitações a esse número. Omitir o 1 da 6ª posição e completar com um zero "
                f"à esquerda produz {cod(r)}. Em Alegre, essa grafia só aparece às 17:01:11, durante a votação "
                "(linha 9825). A seção não tem título registrado com marcador de encerramento nesse dia. "
                "Guarapari, a 116,24 km em linha reta, registrou o mesmo número 38 segundos depois, às 17:01:49.")
    if ident=="M-BB767AB8769D":
        return (f"Na seção de Palmas, o menu de registro de mesários recebeu {cod(a)} às 08:30:19 e {cod(r)} às 08:30:54 "
                "do 2º turno, 35 segundos depois. Entre eles, às 08:30:28, a urna assinalou uma tentativa com título inválido "
                f"(linha 7922). Omitir o 3 da 10ª posição de {cod(a)} e completar com um zero à esquerda reproduz "
                f"{cod(r)}. A primeira grafia já constava na abertura do 1º turno de Palmas. A segunda aparece "
                "na abertura e no encerramento dos dois turnos de Cidade Ocidental. Esses registros sustentam a hipótese "
                "de erro na segunda entrada do menu de Palmas. O log não revela os dígitos da tentativa inválida.")
    if ident=="M-3A24203A38EC":
        return (f"Na seção 60 de Santa Cruz do Capibaribe, {cod(a)} e {cod(r)} aparecem juntos na abertura e no encerramento "
                "do 1º turno e na abertura do 2º. O repetido surge também na seção 13, no encerramento do 2º turno. "
                f"Naquela seção, {cod('035930190850')} tem três algarismos diferentes do repetido e foi registrado às "
                "17:02:14, antes do repetido às 17:04:05. Mesmo a equipe de fechamento contém os dois. "
                "Na seção 60, a urna registra uma tentativa inválida na abertura do 2º turno (linha 6674), antes do repetido. "
                "A semelhança de duas operações observada nessa seção deixa a coincidência na seção 13 em aberto.")
    if qualificar(c)[0]!="forte":
        raise ValueError(f"Descrever a particularidade da composição de {ident}")
    primeiro,ultimo=(r,a) if r in abertura else (a,r)
    descricao = (f"Na seção {local['secao']} de {escape(local['municipio'].title())}, aparece {cod(primeiro)} na abertura "
                 f"e {cod(ultimo)} no encerramento.")
    if ident=="M-88FCC3674D2F":
        descricao+=" Antes de aceitar o número repetido, a urna assinalou uma entrada inválida às 07:49:02 (linha 645)."
    if all(a in equipe(anterior,x) for x in ETAPAS):
        descricao+=f" O alternativo aparece nas duas etapas do {anterior['turno']}º turno na mesma seção."
    elif a in equipe(anterior,"encerramento"):
        extras=[e for e in anterior["registros"] if e["titulo"]==a and e["etapa"] not in ETAPAS]
        if extras:
            ev=extras[0]
            descricao+=f" No {anterior['turno']}º turno, o alternativo já havia sido registrado às {ev['data_hora'][11:]} ({escape(ev['etapa'])}) e no encerramento."
    if all(r in equipe(outra,x) for x in ETAPAS):
        descricao+=f" A seção {outra['secao']} de {escape(outra['municipio'].title())} registrou o número repetido nas duas etapas do turno em análise."
    else:
        etapas_repetido=[ev["etapa"] for ev in outra["registros"] if ev["titulo"]==r]
        descricao+=f" Na seção {outra['secao']} de {escape(outra['municipio'].title())}, os marcadores do repetido foram {' e '.join(map(escape,etapas_repetido))}."
    return descricao


def montar_ficha(c):
    categoria,forca=qualificar(c)
    t=c["trecho"]
    a=c["alternativo"]
    trajetoria=(f"De {escape(secao(t,'origem'))} a {escape(secao(t,'destino'))}, o trecho mais restritivo tem "
                f"<b>{decimal(t['distancia_km'],2)} km</b> em linha reta. Entre {t['hora_origem'][11:]} e "
                f"{t['hora_destino'][11:]} decorreram <b>{tempo(t['intervalo_s'])}</b>.")
    if t["tempo_trajeto_s"] and c["classe"]==CURTO:
        trajetoria+=f" A rota estimada exige {tempo(t['tempo_trajeto_s'])}."
    h=(f"<div class='ficha-dig'><p>{trajetoria}</p><p>{particularidade(c)}</p>"
       f"{figura(c, erro_forte=categoria=='forte')}</div>")
    return dict(html=h,forca=forca,categoria=categoria,alternativo=a,operacoes=c["operacoes"])


def preparar_fichas():
    """Mapa (turno str, título str) → html (abaixo do h3), forca, categoria, alternativo, operacoes."""
    dados=json.loads(ARQUIVO.read_bytes()) if ARQUIVO.exists() else atualizar()
    return {chave(c):montar_ficha(c) for c in dados}


if __name__=="__main__":
    print(len(atualizar()), "fichas lidas dos pacotes originais.")
    print(dict(Counter(v["categoria"] for v in preparar_fichas().values())))
