"""Relatório de leitura pública e CSVs, aplicando os filtros na ordem geográfica."""
import base64
import csv
import gzip
import json
from collections import Counter, defaultdict
from html import escape
from pathlib import Path
from string import Template

from avaliar_sem_rota import avaliar, gravar_csv as gravar_trechos
from casos_em_aberto import FICHAS_INTERESTADUAIS, GRUPOS_ESTADUAIS, GRUPOS_GEOGRAFICOS, chave, decimal, ler, secao, tempo
from equipes_em_aberto import analisar_equipes, resumo_equipes
from listas_equipes import EXEMPLOS_MESMO_LOCAL, carregar_listas
from logistica import CURTO, EXTREMO, INCERTO, LIMIAR, MESMO, OK
from paineis_casos import painel_sao_paulo
from previa_equipes import atributo as previa, botao as botao_equipes, componentes as componentes_previa
from quadro_equipes import renderizar
import relogios
from sankey_casos import ERRO_FORTE, INDICIO, SEM_EVIDENCIA, indice, obter


ROOT = Path(__file__).resolve().parent
PASTA = ROOT/"dados"/"relatorio"
MESAS = "Mesmo local de votação"
VIAVEL = "Deslocamento possível"
IMPROVAVEL = "Deslocamento improvável"
SEM_ROTA = "Deslocamento indeterminado"
CURSOS = {MESMO:MESAS, OK:VIAVEL, LIMIAR:VIAVEL, CURTO:IMPROVAVEL, EXTREMO:IMPROVAVEL, INCERTO:SEM_ROTA}
ARQUIVOS = {
    "mesmo_local": "Casos no mesmo local",
    "deslocamento_possivel": "Casos com deslocamento possível",
    "deslocamento_improvavel": "Todos os deslocamentos improváveis",
    "deslocamento_indeterminado": "Deslocamentos indeterminados",
    "relogios_10min": "Horários e deslocamentos com margem de 10 minutos",
    "fichas_digitacao": "Comparações de títulos por seção e turno",
    "em_aberto": "Casos sem explicação específica",
    "equipes_em_aberto_casos": "Contagem das equipes por caso",
    "equipes_em_aberto_secoes": "Títulos, etapas e linhas do log por seção de cada caso",
    "listas_equipes_comparadas": "Listas de presença de todas as urnas comparadas",
}


def h(v):
    return escape(str(v),quote=True)


def titulo_html(r):
    return f"<code>{h(r['titulo'])}</code>"


def n(v):
    return f"{v:,}".replace(",",".")


def tab(colunas, linhas):
    head="".join(f"<th scope='col'>{c}</th>" for c in colunas)
    body="".join("<tr>"+"".join(f"<td>{v}</td>" for v in linha)+"</tr>" for linha in linhas)
    return f"<div class='scroll'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"


def ficha_id(r):
    return f"f-{r['turno']}-{r['id_caso'].lower()}"


def tecnica(r):
    return "relatorio_tecnico.html#"+ficha_id(r)


def equipes_tecnicas(r):
    return f"relatorio_tecnico.html#equipes-{r['turno']}-{r['id_caso'].lower()}"


def quadro_do_caso(r,listas,alternativo=None):
    return renderizar(listas[chave(r)],r["titulo"],alternativo,turno_do_caso=r["turno"])


def local_key(r):
    return r["turno"],r["uf"],r["codigo_municipio"],r["zona"],r["secao"]


def formatar_mesa(s, a):
    return f"{s['municipio'].title()}/{s['uf']}, Z{s['zona']} S{s['secao']}, local {a['local']}, {a['nome']}, {a['endereco']}"


def coletar(casos, fichas, sem_rota, relogios_por_caso):
    secoes=defaultdict(list)
    end={local_key(r):r for r in ler("enderecos")}
    for r in ler("secoes_por_caso"):
        secoes[chave(r)].append((r,end[local_key(r)]))
    num=indice("duas_edicoes_casos")
    comp_externa={r["id_caso"]:r for r in ler("conferencia_coordenadas")}
    resultado=[]
    for c in casos:
        k=chave(c)
        anterior=CURSOS[c["parecer"]]
        av=sem_rota[k] if c["parecer"]==INCERTO else None
        if av and av["plausivel"]:
            anterior=VIAVEL
        avaliacao=relogios_por_caso.get(k)
        grupo={relogios.COMPATIVEL:VIAVEL,relogios.IMPROVAVEL:IMPROVAVEL,relogios.INDETERMINADO:SEM_ROTA}[avaliacao["resultado"]] if avaliacao else MESAS
        mesas=secoes[k]
        locais={(s["uf"],s["codigo_municipio"],s["zona"],a["local"]) for s,a in mesas}
        if not mesas or ((len(locais)==1)!=(grupo==MESAS)):
            raise ValueError(f"Locais divergentes em {k}")
        f=fichas.get(k,{})
        principal=avaliacao["trecho_referencia"] if avaliacao else None
        nomes=list(dict.fromkeys(f"{s['municipio'].title()}/{s['uf']}" for s,_ in mesas))
        teste=num.get(k,{})
        reg=[int(v) for col,v in teste.items() if col.startswith("custo_ampliado_registro_") and v]
        men=[int(v) for col,v in teste.items() if col.startswith("custo_ampliado_mencao_") and v]
        evidencia=f.get("forca","")
        if grupo==IMPROVAVEL:
            leitura={"forte":ERRO_FORTE,"indicio":INDICIO}.get(f.get("categoria"),SEM_EVIDENCIA)
        else:
            leitura={MESAS:"Retirado pelo local",VIAVEL:"Retirado pelo tempo disponível",SEM_ROTA:"Trajeto indeterminado"}[grupo]
        row=dict(titulo=k[1],turno=k[0],id_caso=c["id_caso"],etapa=grupo,conclusao=leitura,
                 criterio_logistico=avaliacao["resultado"] if avaliacao else MESAS,
                 criterio_logistico_anterior=c["parecer"],etapa_anterior=anterior,
                 motivo_avaliacao=avaliacao["motivo"] if avaliacao else "",
                 tipo_referencia=avaliacao["tipo_referencia"] if avaliacao else "",
                 grupo_geografico=c["grupo_geografico"],mesmo_municipio=c["mesmo_municipio"],mesma_zona=c["mesma_zona"],
                 municipios=" ↔ ".join(nomes),numero_secoes=len(mesas),numero_locais=len(locais),
                 secoes_e_enderecos=" | ".join(formatar_mesa(s,a) for s,a in mesas),
                 presencas_por_secao=" | ".join(f"Z{s['zona']} S{s['secao']}: {s['registros']} ({s['primeiro']} a {s['ultimo']})" for s,_ in mesas),
                 registros_presenca=sum(int(s["registros"]) for s,_ in mesas),habilitacoes_atribuidas=sum(int(s["habilitacoes"]) for s,_ in mesas),
                 mudancas_de_local=avaliacao["trechos_entre_locais"] if avaliacao else 0,trecho_de_referencia="",hora_origem="",hora_destino="",evento_origem="",evento_destino="",
                 distancia_reta_km="",intervalo_s="",modo="",percurso_rede_km="",trajeto_estimado_s="",trajeto_com_folga_s="",
                 intervalo_ajustado_s="",deficit_referencia_s=avaliacao["deficit_referencia_s"] if avaliacao else "",
                 intervalo_maximo_entre_eventos_s="",velocidade_minima_com_margem_kmh="",
                 limite_terrestre_testado_kmh="",minimo_geometrico_s="",
                 velocidade_minima_sem_folga_kmh="",fonte_distancia_sem_rota="",base_sem_rota=av["base"] if av else "",
                 menor_numero_edicoes_em_registro=min(reg,default=""),menor_numero_edicoes_em_outra_mencao=min(men,default=""),
                 titulo_alternativo_examinado=f.get("alternativo",""),forca_da_evidencia=evidencia,nota=c.get("contexto",""),
                 conferencias_de_endereco=comp_externa.get(c["id_caso"],{}).get("interpretacao",""),
                 secoes_e_urls_dos_logs=" | ".join(f"Z{s['zona']} S{s['secao']}: {s['url_log']}" for s,_ in mesas))
        if principal:
            t=principal
            row.update(trecho_de_referencia=secao(t,"origem")+" → "+secao(t,"destino"),
                       hora_origem=t["hora_origem"],hora_destino=t["hora_destino"],evento_origem=t["evento_origem"],evento_destino=t["evento_destino"],
                       distancia_reta_km=t["distancia_km"],intervalo_s=t["intervalo_s"],modo=t["modo"],percurso_rede_km=t["percurso_rede_km"],
                       intervalo_ajustado_s=t.get("intervalo_ajustado_s",""),
                       intervalo_maximo_entre_eventos_s=t["intervalo_maximo_entre_eventos_s"],
                       velocidade_minima_com_margem_kmh=t["velocidade_minima_com_margem_kmh"],
                       limite_terrestre_testado_kmh=t["limite_terrestre_testado_kmh"],minimo_geometrico_s=t["minimo_geometrico_s"],
                       trajeto_estimado_s=t["tempo_trajeto_s"],trajeto_com_folga_s=t["tempo_com_folga_s"])
            if av:
                ref=av["trecho_principal"]
                if av["plausivel"]:
                    row.update(velocidade_minima_sem_folga_kmh=ref["velocidade_minima_kmh"],fonte_distancia_sem_rota=ref["fonte_distancia"])
        resultado.append(row)
    resultado.sort(key=lambda r:(r["turno"],r["municipios"],r["id_caso"]))
    return resultado, secoes


def gravar_csv(chave_nome, linhas, campos=None):
    path=PASTA/(chave_nome+".csv")
    with path.open("w",encoding="utf-8-sig",newline="") as arq:
        w=csv.DictWriter(arq,fieldnames=campos if campos is not None else linhas[0].keys())
        w.writeheader()
        w.writerows(linhas)
    return path


def botao(nome, quant, unidade=""):
    return f"<a class='download' href='dados/relatorio/{nome}.csv' download data-csv='{nome}'>Baixar CSV · {ARQUIVOS[nome]} ({n(quant)}{unidade})</a>"


def quadro_turnos(grupos, coluna="Etapa da triagem", base_percentual=None):
    def linha(rotulo,conjunto):
        cont=Counter(r["turno"] for r in conjunto)
        total = f"<b>{n(len(conjunto))}</b>"
        if base_percentual:
            percentual = decimal(100 * len(conjunto) / base_percentual, 1)
            total += f" ({percentual}%)"
        return h(rotulo),n(cont["1"]),n(cont["2"]),total
    cab_total = f"Total (% dos {n(base_percentual)} casos)" if base_percentual else "Total"
    return tab([coluna,"1º turno","2º turno",cab_total],[linha(k,v) for k,v in grupos])


def resumo_triagem(grupos, fortes, pistas, sem_alternativo):
    rotulo_geografia = f"{IMPROVAVEL}, {SEM_EVIDENCIA.lower()}"
    faixas = {
        GRUPOS_GEOGRAFICOS[0]: ("Mesma cidade ou zona eleitoral", "#d19044"),
        GRUPOS_ESTADUAIS[0]: ("Mesmo estado", "#b34e28"),
        GRUPOS_ESTADUAIS[1]: ("Estado diferente", "#81304c"),
    }
    por_geografia = {faixa: [] for faixa in faixas}
    for caso in sem_alternativo:
        por_geografia[caso["grupo_estadual"] or caso["grupo_geografico"]].append(caso)
    categorias = [
        (MESAS, "#517c69", grupos[MESAS]),
        ("Deslocamento compatível com a margem de 10 minutos", "#337497", grupos[VIAVEL]),
        (ERRO_FORTE, "#724592", fortes),
        (INDICIO, "#a67918", pistas),
    ]
    if grupos[SEM_ROTA]:
        categorias.append((SEM_ROTA, "#81765d", grupos[SEM_ROTA]))
    categorias.extend((rotulo, cor, por_geografia[faixa]) for faixa, (rotulo, cor) in faixas.items())
    rotulos_geograficos = {rotulo for rotulo, _ in faixas.values()}
    contagens = [(rotulo, cor, Counter(r["turno"] for r in casos)) for rotulo, cor, casos in categorias if casos]
    por_turno = sum((cont for _, _, cont in contagens), Counter())
    totais = (por_turno["1"], por_turno["2"], por_turno.total())

    def percentual(quantidade, base):
        if base == 0:
            return "—"
        if quantidade == base:
            return "100%"
        return decimal(100 * quantidade / base, 2) + "%"

    def celulas(valores):
        return "".join(f"<td>{n(q)}<small>{percentual(q, base)}</small></td>"
                       for q, base in zip(valores, totais))

    def rosca(turno):
        total = por_turno[turno]
        arcos, descricao = [], []
        acumulado = 0
        angulo_inicial = -90
        destaque = ""
        for rotulo, cor, cont in contagens:
            q = cont[turno]
            nome = f"{rotulo_geografia} — {rotulo}" if rotulo in rotulos_geograficos else rotulo
            legenda = f"{nome} · {n(q)} {'caso' if q == 1 else 'casos'} ({percentual(q, total)})"
            if q:
                descricao.append(legenda)
                # A fatia usa a fração exata dos casos deste turno.
                arcos.append(f"<circle cx='100' cy='100' r='79' pathLength='100' stroke='{cor}' "
                             f"stroke-dasharray='{100*q/total:.8f} 100' stroke-dashoffset='{-100*acumulado/total:.8f}'>"
                             f"<title>{h(legenda)}</title></circle>")
                if rotulo == ERRO_FORTE:
                    # Centraliza a pequena fatia sobre a chamada, sem alargá-la.
                    angulo_inicial = 90 - 360 * (acumulado + q / 2) / total
                    texto = "erro de digitação" if q == 1 else "erros de digitação"
                    destaque = (f"<path d='M100 192v12' stroke='{cor}' stroke-width='1.5'/>"
                                f"<text x='100' y='220' text-anchor='middle' fill='{cor}' "
                                f"font-size='15' font-weight='650'>{n(q)} {texto}</text>")
            acumulado += q
        return (f"<svg viewBox='0 0 200 228' role='img' aria-labelledby='rosca-titulo-{turno} rosca-descricao-{turno}'>"
                f"<title id='rosca-titulo-{turno}'>Distribuição dos {n(total)} casos do {turno}º turno</title>"
                f"<desc id='rosca-descricao-{turno}'>{h('. '.join(descricao))}.</desc>"
                f"<g fill='none' stroke-width='26' transform='rotate({angulo_inicial:.8f} 100 100)'>{''.join(arcos)}</g>"
                f"<g text-anchor='middle'><text class='rosca-total' x='100' y='103'>{n(total)}</text>"
                f"<text class='rosca-unidade' x='100' y='125'>{turno}º turno</text></g>{destaque}</svg>")

    linhas = []
    linhas_geograficas = []
    for rotulo, cor, cont in contagens:
        destino = linhas_geograficas if rotulo in rotulos_geograficos else linhas
        destino.append(f"<tr><th scope='row'><span class='categoria-triagem'>"
                       f"<i aria-hidden='true' style='background:{cor}'></i>{h(rotulo)}</span></th>"
                       f"{celulas((cont['1'], cont['2'], cont.total()))}</tr>")
    legenda_geografica = (f"<tbody><tr class='grupo-triagem'><th scope='rowgroup' colspan='4'>{h(rotulo_geografia)}</th></tr>"
                         f"{''.join(linhas_geograficas)}</tbody>") if linhas_geograficas else ""

    return (f"<figure id='triagem-geral' class='triagem-geral'><div class='distribuicao-triagem'>"
            f"<div class='roscas-por-turno'>{rosca('1')}{rosca('2')}</div>"
            f"<table aria-label='Contagem e percentual de casos por etapa e turno'><thead><tr>"
            f"<th scope='col'>Etapa da triagem</th><th scope='col'>1º turno</th>"
            f"<th scope='col'>2º turno</th><th scope='col'>Total</th></tr></thead>"
            f"<tbody>{''.join(linhas)}</tbody>{legenda_geografica}<tfoot><tr><th scope='row'>Total</th>"
            f"{celulas(totais)}</tr></tfoot></table></div>"
            f"<figcaption>Dos {n(len(grupos[IMPROVAVEL]))} casos de deslocamento improvável, {n(len(fortes))} têm evidência forte de erro de digitação "
            f"e {n(len(pistas)+len(sem_alternativo))} permanecem em aberto. “Mesmo estado” reúne seções de municípios e zonas eleitorais diferentes na mesma UF. "
            f"Os percentuais usam o total de cada coluna e são arredondados a duas casas decimais.</figcaption></figure>")


def equipe_do_exemplo(caso, listas, complemento=""):
    turno = caso["turno"]
    mesas = [m for m in listas[chave(caso)] if str(m["turno"]) == turno]
    grade = renderizar(mesas, caso["titulo"], turno_do_caso=turno)
    return (f"<details id='exemplo-{ficha_id(caso)}'><summary {previa(caso)}>"
            f"{h(caso['municipios'])} · {titulo_html(caso)} · {turno}º turno</summary>{grade}{complemento}</details>")


def exemplos_mesmo(exemplos,secoes,listas):
    saida=[]
    for r in exemplos:
        mesas=secoes[chave(r)]
        s,a=mesas[0]
        numeros=", ".join(str(i) for i in sorted(int(m["secao"]) for m,_ in mesas))
        saida.append((titulo_html(r),f"<b>{h(r['municipios'])}</b><small>{r['turno']}º turno</small>",
            f"{len(mesas)} seções na zona {s['zona']}<small>{numeros}</small>",f"{h(a['nome'])}<small>{h(a['endereco'])} · local {a['local']}</small>"))
    paineis="".join(equipe_do_exemplo(r, listas) for r in exemplos)
    return (tab(["Título registrado","Município","Seções","Estabelecimento no TSE"],saida)
            +"<p><b>Equipes dos exemplos de realocação no mesmo local</b></p>"+paineis)


def exemplo_realocacao(caso, listas):
    presencas = [(e, mesa) for mesa in listas[chave(caso)] if str(mesa["turno"]) == caso["turno"]
                 for e in mesa["registros"] if e["titulo"] == caso["titulo"]]
    presencas.sort(key=lambda item: item[0]["data_hora"])
    if caso["etapa"] != MESAS or [e["etapa"] for e, _ in presencas] != ["abertura", "encerramento"]:
        raise ValueError(f"Rever as etapas de presença no exemplo {caso['id_caso']}.")
    (abertura, origem), (encerramento, destino) = presencas
    fontes = [f"<a href='{h(mesa['url_log'])}'>Seção {mesa['secao']} · {h(e['membro'])}, linha {e['linha']}</a>"
              for e, mesa in presencas]
    return (f"Em {h(caso['municipios'])}, no {caso['turno']}º turno, o título {titulo_html(caso)} aparece "
            f"na abertura da seção {origem['secao']} às <b>{h(abertura['data_hora'][11:])}</b> "
            f"e no encerramento da seção {destino['secao']} às <b>{h(encerramento['data_hora'][11:])}</b>. "
            f"As duas mesas funcionavam no mesmo estabelecimento da zona {origem['zona']} "
            f"({h(origem['nome'].title())}). " + " · ".join(fontes) + ".")


def exemplos_viaveis(exemplos, listas):
    linhas=[]
    paineis=[]
    for r in exemplos:
        anexo = f"<p><a href='{tecnica(r)}'>Detalhes do trajeto no anexo técnico</a></p>"
        paineis.append(equipe_do_exemplo(r, listas, anexo))
        linhas.append((titulo_html(r),f"{h(r['trecho_de_referencia'])}<small>{r['turno']}º turno</small>",
                       tempo(r["intervalo_s"]),tempo(r["intervalo_ajustado_s"]) if r["intervalo_ajustado_s"] not in ("", None) else "—",
                       f"{decimal(r['percurso_rede_km'],2)} km · {h(r['modo'])}", tempo(r["trajeto_estimado_s"])))
    tabela = tab(["Título registrado","Trecho","Intervalo no log","Intervalo com ajuste dos relógios","Percurso na rede","Tempo estimado"],linhas)
    return tabela + "<p><b>Equipes dos exemplos de deslocamento entre locais</b></p>" + "".join(paineis)


def abrir_caso(r, fichas):
    if r["id_caso"] in FICHAS_INTERESTADUAIS:
        return "#" + FICHAS_INTERESTADUAIS[r["id_caso"]]
    return "#analise-"+r["id_caso"].lower()+"-"+r["turno"] if chave(r) in fichas else tecnica(r)


def caso_buriti_dos_montes(caso, fichas):
    km = float(caso["distancia_reta_km"])
    segundos = int(float(caso["intervalo_s"]))
    janela = caso["intervalo_maximo_entre_eventos_s"]
    velocidade = caso["velocidade_minima_com_margem_kmh"]
    limite = caso["limite_terrestre_testado_kmh"]
    return (f"<p>Na abertura do 2º turno, a seção 33 de Buriti dos Montes (zona 34) registrou "
            f"{titulo_html(caso)} às {h(caso['hora_origem'][11:])}. A seção 210 de Milton Brandão (zona 12) "
            f"registrou o mesmo número às {h(caso['hora_destino'][11:])}. As escolas estão a "
            f"<strong>{decimal(km)} km em linha reta</strong>. Mesmo acrescentando a margem inteira de dez minutos "
            f"aos {segundos} segundos entre os registros, restam <strong>{tempo(janela)}</strong>. "
            f"Seria preciso manter uma média de aproximadamente <strong>{decimal(velocidade, 0)} km/h</strong>. Mesmo a {decimal(limite, 0)} km/h, "
            f"o trajeto em linha reta levaria cerca de {tempo(caso['minimo_geometrico_s'])}.</p>"
            f"<p>Em Buriti dos Montes, o sexto algarismo do título <code>{h(caso['titulo_alternativo_examinado'])}</code> "
            f"foi digitado como 4 na abertura e voltou a aparecer como 1 no encerramento. "
            f"<a {previa(caso)} href='{abrir_caso(caso, fichas)}'>Comparar os títulos e as equipes das duas urnas</a>.</p>")


def lista_aberta(linhas,fichas,listas):
    itens=[]
    for r in linhas:
        distancia=decimal(r["distancia_reta_km"],2)+" km" if r["distancia_reta_km"] else "Sem coordenadas"
        candidato=fichas.get(chave(r),{}).get("alternativo")
        grade=quadro_do_caso(r,listas,candidato)
        itens.append(f"<details class='equipes-pendentes' id='listas-{ficha_id(r)}'>"
                     f"<summary {previa(r)}>{h(r['municipios'])} · {titulo_html(r)} · {r['turno']}º turno</summary>"
                     f"<p>{h(r['trecho_de_referencia'])} · {distancia} em linha reta · {tempo(r['intervalo_s'])}. "
                     f"{h(r['motivo_avaliacao'])} "
                     f"<a {previa(r)} href='{abrir_caso(r,fichas)}'>Ver a análise do caso</a>.</p>{grade}</details>")
    return "".join(itens)


def geografia_em_aberto(pendentes, fichas, listas):
    por_grupo = {rotulo: [] for rotulo in GRUPOS_GEOGRAFICOS}
    por_estado = {rotulo: [] for rotulo in GRUPOS_ESTADUAIS}
    coincidencias = Counter()
    for r in pendentes:
        por_grupo[r["grupo_geografico"]].append(r)
        coincidencias[r["mesmo_municipio"], r["mesma_zona"]] += 1
        if r["grupo_geografico"] == GRUPOS_GEOGRAFICOS[1]:
            por_estado[r["grupo_estadual"]].append(r)

    comum, diferentes = GRUPOS_GEOGRAFICOS
    mesmo_estado, interestaduais = GRUPOS_ESTADUAIS
    categorias = [(comum, por_grupo[comum]),
                  ("Municípios e zonas eleitorais diferentes, no mesmo estado", por_estado[mesmo_estado]),
                  ("Estados diferentes", por_estado[interestaduais])]
    quadro = quadro_turnos([*categorias, ("Total em aberto", pendentes)],
                          "Relação entre as seções", base_percentual=len(pendentes))
    total_mesma_uf = len(por_grupo[comum]) + len(por_estado[mesmo_estado])
    detalhe = (f"<p>Ao todo, <strong>{total_mesma_uf} dos {len(pendentes)} casos</strong> envolvem seções do mesmo estado. "
               f"Dos {len(por_grupo[comum])} que compartilham município ou zona eleitoral, "
               f"{coincidencias[1, 1]} compartilham ambos, {coincidencias[1, 0]} ficam no mesmo município em zonas diferentes "
               f"e {coincidencias[0, 1]} ficam em municípios diferentes da mesma zona.</p>")
    def bloco(rotulo, casos, conteudo):
        quantidade = len(casos)
        unidade = "caso" if quantidade == 1 else "casos"
        return (f"<details class='grupo-geografico'><summary>{h(rotulo)} · {quantidade} {unidade}</summary>"
                f"{conteudo}</details>")

    subdivisao = "".join(bloco(rotulo, casos, lista_aberta(casos, fichas, listas))
                        for rotulo, casos in por_estado.items() if casos)
    grupos = (bloco(comum, por_grupo[comum], lista_aberta(por_grupo[comum], fichas, listas))
              + bloco(diferentes, por_grupo[diferentes], subdivisao))
    return quadro + detalhe, grupos


def painel_equipes(casos,secoes,pendentes,pistas):
    res=resumo_equipes(casos,secoes)
    total=res["total"]
    campos=(("Casos em aberto","casos"),("Com 5 ou mais títulos na mesma seção ao longo do turno","casos_mais_de_4"),
            ("O próprio título repetido entrou depois de outros quatro na seção","casos_com_repetido_apos_quatro_no_turno"),
            ("Com 5 ou mais em um único registro de equipe¹","casos_mais_de_4_em_um_ciclo"),
            ("Com 5 ou mais numa abertura","casos_mais_de_4_na_abertura"),
            ("Com 5 ou mais num encerramento","casos_mais_de_4_no_encerramento"))
    quadro=tab(["Contagem de casos","1º turno","2º turno","Total"],
               [(h(rotulo),res["1"][c],res["2"][c],f"<b>{total[c]}</b>") for rotulo,c in campos])
    por_caso={chave(r):r for r in pendentes}
    positivas=[c for c in casos if c["alguma_secao_mais_de_4"]]
    detalhes=tab(["Título repetido","Turno","Seções com 5 ou mais (total do turno entre parênteses)","Onde o repetido entrou depois de outros quatro"],[
        (f"<a {previa(c)} href='{tecnica(por_caso[chave(c)])}'>{titulo_html(c)}</a>",c["turno"]+"º",h(c["secoes_mais_de_4"]),h(c["secoes_e_posicoes_do_repetido_apos_quatro"] or "—"))
        for c in sorted(positivas,key=lambda c:(c["turno"],por_caso[chave(c)]["municipios"],c["titulo"]))])
    resumo_pistas = ""
    if pistas:
        ids_pistas={chave(p) for p in pistas}
        pistas_positivas=len({chave(c) for c in positivas} & ids_pistas)
        pistas_na_mesma_secao=len({chave(s) for s in secoes if s["mais_de_4_no_turno"] and s["titulo_alternativo_da_ficha_nesta_secao"]} & ids_pistas)
        resumo_pistas = (f"Entre os casos com cinco ou mais títulos na mesma seção, há {pistas_positivas} "
                         f"com indício numérico inconclusivo. Em {pistas_na_mesma_secao} "
                         f"{'caso' if pistas_na_mesma_secao == 1 else 'casos'}, o título alternativo aparece "
                         "na própria seção que registrou mais de quatro títulos. ")
    quix=next(s for s in secoes if s["titulo"]=="058687990787" and int(s["secao"])==276)
    return (f"<p class='lead'>Em <strong>{total['casos_com_repetido_apos_quatro_no_turno']} dos {len(casos)} casos</strong>, "
            "uma das seções já havia cadastrado quatro ou mais títulos distintos quando registrou pela primeira vez "
            f"o título que se repetiu em outra urna. Foram {res['1']['casos_com_repetido_apos_quatro_no_turno']} casos no "
            f"primeiro turno e {res['2']['casos_com_repetido_apos_quatro_no_turno']} no segundo.</p>"
            "<p>Quatro é a composição habitual da mesa receptora de votos. Ela reúne quem preside a seção, "
            "dois mesários e quem exerce a secretaria. Se houver substituição durante os trabalhos, a lista do dia pode crescer. "
            "<a href='https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026'>"
            "Resolução TSE nº 23.751/2026, arts. 9º e 125</a>.</p>"
            f"<p>Em <strong>{len(positivas)} dos {len(casos)} casos ({decimal(100*len(positivas)/len(casos))}%)</strong>, "
            "pelo menos uma seção registrou cinco ou mais títulos distintos ao longo do turno, independentemente da ordem de cadastro.</p>"
            f"{quadro}<p class='fine'>¹ Cada ciclo começa com um marcador de registro de mesários no log da urna. "
            "A contagem inclui os títulos com confirmação de presença. Cada título conta uma única vez por seção e turno, "
            "mesmo que apareça em vários registros. Tentativas inválidas e habilitações de eleitores ficam fora desta contagem.</p>"
            f"<p>Em {len(positivas)-total['casos_mais_de_4_em_um_ciclo']} dos {len(positivas)} casos, a seção só ultrapassou quatro ao reunir "
            "registros de momentos diferentes. Isso pode ocorrer quando alguém substitui um integrante. "
            f"Considerando cada seção uma vez por turno, {total['secoes_distintas_mais_de_4']} de {total['secoes_distintas']} "
            f"registraram mais de quatro títulos. Há seções compartilhadas por mais de um caso.</p>"
            f"<p>{resumo_pistas}Em {total['casos_com_titulo_como_unico_adicional']} casos, o título repetido é o único número adicional "
            "ao comparar as listas. Para identificar as pessoas que efetivamente trabalharam, é preciso conferir a ata.</p>"
            f"<p><b>Quixeramobim/CE, zona {h(quix['zona'])}, seção {h(quix['secao'])}.</b> "
            "Os mesmos quatro títulos aparecem na abertura e no encerramento. O quinto, "
            f"<code>{h(quix['titulo'])}</code>, só aparece em registro de presença durante a votação, às 14h24min43s, "
            f"na linha 9848. <a href='{h(quix['url_log'])}'>Arquivo da urna de Quixeramobim</a>.</p>"
            f"<details><summary>Ver os {len(positivas)} casos e as seções que ultrapassaram quatro títulos</summary>{detalhes}</details>")


def seccao_fichas(registros,fichas,listas):
    if not registros:
        return ""
    prioridade={"M-DAB0A007A18D":0,"M-56737337C02A":1}
    ordenadas=sorted(registros,key=lambda r:(prioridade.get(r["id_caso"],2),r["turno"],r["municipios"],r["id_caso"]))
    indice_html=[]
    corpo=[]
    for r in ordenadas:
        f=fichas[chave(r)]
        ancora=abrir_caso(r,fichas)[1:]
        nomes=r["municipios"]
        pontos=f"<strong>{h(nomes)}</strong> · {r['turno']}º turno"
        indice_html.append(f"<li><a {previa(r)} href='#{ancora}'>{titulo_html(r)} · {pontos}</a></li>")
        corpo.append(f"<article class='ficha-numerica' id='{ancora}'><h4>{pontos}</h4>"
                     f"<p class='cred'>Título repetido {titulo_html(r)} · {h(f['forca'])}</p>{f['html']}"
                     f"<h5>Todos os títulos registrados nas urnas comparadas</h5>"
                     f"{quadro_do_caso(r,listas,f['alternativo'])}</article>")
    return ("<details class='indice'><summary>Ir a uma das "+str(len(ordenadas))+" fichas</summary><ol>"+"".join(indice_html)
            +"</ol></details>"+"".join(corpo))


def publicar():
    from relatorio_votos_vizinhas import painel as painel_votos_vizinhas
    from caso_400 import painel_mogi_petropolis
    from fichas_digitacao import preparar_fichas, ESTILO as ESTILO_FICHAS
    from nota_dv import secao_dv
    from painel_dv_exaustivo import publicar as publicar_teste_dv
    from nota_mesario import leitura_casos_em_aberto, painel_mesario
    from usos_interestaduais import painel_bahia_patrocinio
    from sankey_relatorio import gerar as gerar_sankey
    publicar_teste_dv()
    fichas=preparar_fichas()
    listas=carregar_listas()
    sem_rota=avaliar()
    casos, adicionais=obter(fichas)
    cenarios = relogios.avaliar()
    linhas, secoes=coletar(casos,fichas,sem_rota,cenarios)
    por_id={(r["turno"],r["id_caso"]):r for r in linhas}
    grupos={k:[r for r in linhas if r["etapa"]==k] for k in (MESAS,VIAVEL,IMPROVAVEL,SEM_ROTA)}
    investigados=[r for r in linhas if chave(r) in fichas]
    fichas_improvaveis=[r for r in investigados if r["etapa"]==IMPROVAVEL]
    fichas_possiveis=[r for r in investigados if r["etapa"]==VIAVEL]
    fortes=[r for r in fichas_improvaveis if fichas[chave(r)]["categoria"]=="forte"]
    pistas=[r for r in fichas_improvaveis if fichas[chave(r)]["categoria"]=="indicio"]
    estado_por_caso = {chave(c): c["grupo_estadual"] for c in casos}
    pendentes = sorted(({**r, "grupo_estadual": estado_por_caso[chave(r)]} for r in grupos[IMPROVAVEL]
                        if r["conclusao"] in (INDICIO, SEM_EVIDENCIA)),
                       key=lambda r:(GRUPOS_GEOGRAFICOS.index(r["grupo_geografico"]),r["turno"],r["municipios"],r["id_caso"]))
    sem_reconst = [r for r in pendentes if r["conclusao"] == SEM_EVIDENCIA]
    if len(fortes)+len(pistas)+len(fichas_possiveis)!=len(fichas):
        raise ValueError("A cobertura das fichas numéricas diverge da triagem geográfica.")
    if sum(map(len,grupos.values()))!=len(linhas) or len(fortes)+len(pendentes)!=len(grupos[IMPROVAVEL]):
        raise ValueError("A soma das etapas diverge do universo.")
    PASTA.mkdir(parents=True,exist_ok=True)
    sem_trajeto=[r for r in linhas if r["criterio_logistico_anterior"]==INCERTO]
    casos_equipe,secoes_equipe=analisar_equipes(map(chave,pendentes),gravar=False)
    por_equipe={chave(c):c for c in casos_equipe}
    campos_equipe=("alguma_secao_mais_de_4","numero_secoes_mais_de_4","maximo_no_turno","secoes_mais_de_4",
                   "secoes_com_repetido_apos_quatro_no_turno","secoes_e_posicoes_do_repetido_apos_quatro")
    abertos_csv=[{**r,**{col:por_equipe[chave(r)][col] for col in campos_equipe}} for r in pendentes]
    saidas=dict(mesmo_local=grupos[MESAS],deslocamento_possivel=grupos[VIAVEL],deslocamento_improvavel=grupos[IMPROVAVEL],
                deslocamento_indeterminado=grupos[SEM_ROTA],
                fichas_digitacao=investigados,em_aberto=abertos_csv,
                equipes_em_aberto_casos=casos_equipe,equipes_em_aberto_secoes=secoes_equipe)
    # Inclui os CSVs também no HTML para os leitores que recebem só a página.
    incorporados={}
    for nome,rows in saidas.items():
        arq=gravar_csv(nome,rows,campos=linhas[0].keys() if not rows else None)
        incorporados[nome]=base64.b64encode(gzip.compress(arq.read_bytes(),mtime=0)).decode("ascii")
    gravar_csv("sem_rota",sem_trajeto)
    gravar_trechos(sem_rota)
    csv_listas=PASTA/"listas_equipes_comparadas.csv"
    incorporados["listas_equipes_comparadas"]=base64.b64encode(gzip.compress(csv_listas.read_bytes(),mtime=0)).decode("ascii")
    relogios.gravar_csv(cenarios)
    incorporados["relogios_10min"]=base64.b64encode(gzip.compress((PASTA/"relogios_10min.csv").read_bytes(),mtime=0)).decode("ascii")
    sp=json.loads((ROOT/"dados"/"exemplos_ilustrados.json").read_text(encoding="utf-8"))["sao_paulo"]
    sp_html=painel_sao_paulo(sp).replace("href='#f-","href='relatorio_tecnico.html#f-")
    improvaveis_por_turno=Counter(r["turno"] for r in grupos[IMPROVAVEL])
    em_ambas=sum(bool(r["menor_numero_edicoes_em_registro"] or r["menor_numero_edicoes_em_outra_mencao"]) for r in grupos[VIAVEL])
    exemplos_locais=[por_id[i] for i in EXEMPLOS_MESMO_LOCAL]
    exemplos_trajeto=[por_id[i] for i in (("1","M-54F5007E28C3"),("1","M-C03562E65A3B"),("2","M-96E61D5570E4"),("1","M-806B5D49C2D7"))]
    cards_mesmo=exemplos_mesmo(exemplos_locais,secoes,listas)
    cards_viaveis=exemplos_viaveis(exemplos_trajeto,listas)
    fontes = {chave(r):"exemplo-"+ficha_id(r) for r in exemplos_locais+exemplos_trajeto}
    fontes.update({chave(r):"listas-"+ficha_id(r) for r in pendentes})
    fontes.update({chave(r):abrir_caso(r,fichas)[1:] for r in investigados})
    sp_caso=por_id["1",sp["id_caso"]]
    bloco_indeterminados = ""
    if grupos[SEM_ROTA]:
        bloco_indeterminados = ("<h3>Deslocamentos indeterminados</h3>"
                                + lista_aberta(grupos[SEM_ROTA],fichas,listas)
                                + botao("deslocamento_indeterminado",len(grupos[SEM_ROTA])))
    estilo_previa, painel_previa = componentes_previa(listas, map(chave, exemplos_locais+exemplos_trajeto+grupos[IMPROVAVEL]+investigados+grupos[SEM_ROTA]+[sp_caso]),fontes)
    paineis = {"M-D811615A470E": painel_mogi_petropolis, "M-9E8E183333B2": painel_bahia_patrocinio}
    interestaduais = []
    for r in pendentes:
        if r["grupo_estadual"] != GRUPOS_ESTADUAIS[1]:
            continue
        painel = paineis[r["id_caso"]]
        ver_equipes = botao_equipes(r, "Ver os títulos das duas equipes na abertura e no encerramento", "#listas-"+ficha_id(r))
        interestaduais.append(f"{painel()}<p class='fine'>Distância entre as seções: {decimal(r['distancia_reta_km'])} km em linha reta. "
                              f"Intervalo entre os registros de referência: {tempo(r['intervalo_s'])}. {ver_equipes}.</p>")
    titulos_por_evidencia = [(ERRO_FORTE, fortes), (INDICIO, pistas), (SEM_EVIDENCIA, sem_reconst)]
    bloco_indicios = ""
    resumo_abertos = "Em nenhum desses casos a comparação dos algarismos permite reconstituir um erro de digitação."
    if pistas:
        bloco_indicios = f"<h3>{INDICIO}</h3>" + seccao_fichas(pistas, fichas, listas)
        unidade = "caso" if len(pistas) == 1 else "casos"
        resumo_abertos = (f"Em {len(pistas)} {unidade}, consta outro título de grafia semelhante na seção e o indício permanece "
                          "inconclusivo. Nos demais, os registros das equipes não explicam a repetição.")
    abertos_por_turno = Counter(r["turno"] for r in pendentes)
    resumo_geografico, fichas_geograficas = geografia_em_aberto(pendentes, fichas, listas)
    total=len(linhas)
    vars=dict(ESTILO=ESTILO_FICHAS,ESTILO_PREVIA=estilo_previa,PAINEL_PREVIA=painel_previa,
              TOTAL=n(total), UNICOS=n(len({r['titulo'] for r in linhas})), EXTRAIS=len(adicionais),
              GERAL=resumo_triagem(grupos, fortes, pistas, sem_reconst),
              CSV_RELOGIOS=botao("relogios_10min",len(cenarios)," casos"),
              MESMO=n(len(grupos[MESAS])),PCT_MESMO=decimal(len(grupos[MESAS])/total*100),RESTO=n(total-len(grupos[MESAS])),
              POSSIVEL=n(len(grupos[VIAVEL])),DUPLAS=em_ambas,
              DESCARTADOS=n(len(grupos[MESAS])+len(grupos[VIAVEL])),EX_MESMO=cards_mesmo,EX_POSSIVEL=cards_viaveis,
              IMPROVAVEL=len(grupos[IMPROVAVEL]),IMPROVAVEIS_T1=improvaveis_por_turno["1"],IMPROVAVEIS_T2=improvaveis_por_turno["2"],
              QUADRO_DIG=quadro_turnos([(k,v) for k,v in titulos_por_evidencia if v]),
              FORTES=len(fortes), RESUMO_ABERTOS=resumo_abertos, BLOCO_INDICIOS=bloco_indicios,
              FICHAS=seccao_fichas(fortes,fichas,listas),
              COMPARACOES_POSSIVEIS=(f"<details><summary>Comparação dos títulos em {len(fichas_possiveis)} casos com deslocamento possível</summary>"
                                     + seccao_fichas(fichas_possiveis,fichas,listas) + "</details>") if fichas_possiveis else "",
              CASO_PIAUI=caso_buriti_dos_montes(por_id["2","M-CB8776247A86"],fichas),
              BLOCO_INDETERMINADOS=bloco_indeterminados,
              CSV_LISTAS=botao("listas_equipes_comparadas",len(listas)," casos"),
              ABERTOS=len(pendentes),ABERTOS_T1=abertos_por_turno["1"],ABERTOS_T2=abertos_por_turno["2"],
              EQUIPES=painel_equipes(casos_equipe,secoes_equipe,pendentes,pistas),
              LEITURA_ABERTOS=leitura_casos_em_aberto(),CASOS_INTERESTADUAIS="".join(interestaduais),
              RESUMO_GEOGRAFICO=resumo_geografico,GEOGRAFIA_ABERTA=fichas_geograficas,
              EX_REALOCACAO=exemplo_realocacao(exemplos_locais[0],listas),
              SP=sp_html,SP_DESFECHO=h(sp_caso["etapa"]),SP_MOTIVO=h(sp_caso["motivo_avaliacao"]),
              EQUIPES_SP=botao_equipes(sp_caso,"Ver a abertura e o encerramento das dez seções de São Paulo",equipes_tecnicas(sp_caso)),
              VOTOS_VIZINHAS=painel_votos_vizinhas(),DV=secao_dv(),BIOM=painel_mesario(),DADOS=json.dumps(incorporados,separators=(",",":")))
    vars.update({"CSV_"+k.upper():botao(k,len(v)) for k,v in saidas.items()})
    template=Template((ROOT/"modelo_estruturado.html").read_text(encoding="utf-8"))
    pagina=template.substitute(vars)
    (ROOT/"relatorio.html").write_text(pagina,encoding="utf-8")
    gerar_sankey(casos,adicionais)
    print(f"{total} casos · {len(fortes)} fortes · {len(pistas)} indícios · {len(pendentes)} improváveis em aberto")


if __name__=="__main__":
    publicar()
