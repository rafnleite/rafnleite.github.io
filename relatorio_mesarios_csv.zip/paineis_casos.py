"""Exibe registros selecionados em seus horários, seções e locais de origem."""
import json
from html import escape
from math import cos, radians
from pathlib import Path

from quadro_equipes import indicador_eleitor


def original(s):
    return f"<a href='{escape(s['url_log'],quote=True)}'>Log do TSE</a>"


def tabela(titulos,linhas):
    head="".join(f"<th scope='col'>{t}</th>" for t in titulos)
    corpo="".join("<tr>"+"".join(f"<td>{v}</td>" for v in linha)+"</tr>" for linha in linhas)
    return f"<div class='scroll'><table><thead><tr>{head}</tr></thead><tbody>{corpo}</tbody></table></div>"


def painel_bahia(d):
    linhas=[]
    for s in sorted(d["secoes"],key=lambda s:(s["turno"],s["municipio"])):
        etapas=[]
        for fase in ("abertura","encerramento"):
            eventos=[r for r in s["registros"] if r["etapa"]==fase]
            etapas.append("<br>".join(f"<code>{escape(r['titulo'])}</code><small>"
                                     f"{r['data_hora'][11:]} · linha {r['linha']}{indicador_eleitor(r)}</small>" for r in eventos))
        linhas.append((f"{s['turno']}º",f"<b>{escape(s['municipio'].title())}</b><small>Z{s['zona']} · S{s['secao']}</small>",
                       *etapas,f"{s['equipe_em_ambas']} de {s['equipe_abertura']}",original(s)))
    tab=tabela(["Turno","Mesa","Na abertura","No encerramento","Títulos mantidos¹","Fonte"],linhas)
    distancia=f"{d['distancia_reta_km']:.1f}".replace(".",",")
    return (f"<p>No primeiro turno, cada título ilustrado aparece na abertura e no encerramento da respectiva seção. "
            f"No segundo, Porto Seguro manteve os quatro. Em Casa Nova, <b>três dos quatro se repetiram</b>. "
            f"A única mudança foi a do título ilustrado acima. A urna de Casa Nova também atribuiu quatro habilitações "
            f"ao número da abertura.</p><div class='evidencia'>{tab}</div><p class='fine'>¹ Títulos registrados "
            f"nas duas etapas da própria seção. Horários locais. Os números de linha são os dos arquivos originais indicados.</p>"
            f"<p>As duas urnas registraram <code>{d['titulo_repetido']}</code> no encerramento com "
            f"<b>{d['intervalo_encerramentos_s']} segundos</b> de diferença, a "
            f"<b>{distancia} km</b> em linha reta. A mudança isolada na equipe e a reprodução exata "
            f"dos algarismos sustentam a hipótese de erro de digitação em Casa Nova. "
            f"<a data-equipe-prever='2-{d['id_caso'].lower()}' href='#f-2-{d['id_caso'].lower()}'>Abrir a ficha das duas seções</a>.</p>")


def fundo_geosampa(projetar):
    base = json.loads((Path(__file__).parent / "dados/base_cartografica_zona_254.json").read_bytes())

    def caminho(linha):
        pontos = (projetar(lon, lat) for lon, lat in linha)
        return "M" + " ".join(f"{x:.1f},{y:.1f}" for x, y in pontos)

    agua = "".join(caminho(anel) + "Z" for poligono in base["agua"] for anel in poligono)
    ruas = "".join(caminho(linha) for linha in base["ruas"])
    avenidas = "".join(caminho(linha) for linha in base["avenidas"])
    rotulos = []
    for r in base.get("rotulos", []):
        x, y = projetar(r["lon"], r["lat"])
        rotulos.append(f"<text transform='translate({x:.1f} {y:.1f}) rotate({float(r['angulo']):.1f})'>"
                       f"{escape(r['texto'])}</text>")
    return ("<g class='base-geosampa' aria-hidden='true'>"
            "<rect width='560' height='368' fill='#f5f3e9'/>"
            f"<path class='agua' d='{agua}' fill='#b6d6dc' fill-rule='evenodd'/>"
            f"<path class='ruas' d='{ruas}' fill='none' stroke='#c9c9be' stroke-width='.85'/>"
            f"<path class='avenidas' d='{avenidas}' fill='none' stroke='#c6a977' stroke-width='1.7'/>"
            "<g text-anchor='middle' font-family='Segoe UI, sans-serif' font-size='11' "
            "font-weight='600' fill='#556057' stroke='#f8f7ee' stroke-width='3' paint-order='stroke' "
            f"stroke-linejoin='round'>{''.join(rotulos)}</g></g>")


def mapa_secoes(secoes):
    # Projeção local equiretangular, com uma única escala para os dois eixos.
    lat=[float(s["latitude"]) for s in secoes]
    lon=[float(s["longitude"]) for s in secoes]
    lat_km=111.195
    lon_km=lat_km*cos(radians(sum(lat)/len(lat)))
    oeste, norte = min(lon), max(lat)
    escala=min(540/((max(lon)-oeste)*lon_km),270/((norte-min(lat))*lat_km))

    def projetar(longitude, latitude):
        return 82+(longitude-oeste)*lon_km*escala, 38+(norte-latitude)*lat_km*escala

    pontos=[]
    for s, longitude, latitude in zip(secoes, lon, lat):
        x,y=projetar(longitude, latitude)
        sec=int(s["secao"])
        dx,dy=({75:(38,23),456:(-37,-13),187:(-25,-13),178:(0,28),95:(24,-11),
                154:(24,5),307:(-36,1)}).get(sec,(28,2))
        cor="#ae4b24" if sec==307 else "#135d58"
        pontos.append(f"<g><title>Seção {sec} · {escape(s['nome'])}</title>"
            f"<line x1='{x:.1f}' y1='{y:.1f}' x2='{x+dx*.7:.1f}' y2='{y+dy*.7:.1f}' stroke='{cor}' stroke-width='1.3'/>"
            f"<circle cx='{x:.1f}' cy='{y:.1f}' r='{'7' if sec==307 else '4'}' fill='{cor}' stroke='white' stroke-width='1.3'/>"
            f"<text x='{x+dx:.1f}' y='{y+dy+4:.1f}' text-anchor='middle' fill='{cor}' stroke='#fffef9' "
            f"paint-order='stroke' stroke-width='3.8' stroke-linejoin='round'>{sec}</text></g>")
    bar_y=342
    return ("<figure class='mapa' id='mapa-zona-254'><svg viewBox='0 0 560 368' role='img' aria-labelledby='titulo-mapa desc-mapa'>"
            "<title id='titulo-mapa'>Os dez locais da zona 254 de São Paulo</title>"
            "<desc id='desc-mapa'>Sobre o mapa de ruas de São Paulo, cada ponto indica um local de votação. O norte está no alto. A seção 307 aparece nos dois turnos. "
            "As seções 75 e 456 ficam a cerca de 43 metros uma da outra.</desc>"
            "<defs><clipPath id='moldura-mapa-sp'><rect width='560' height='368' rx='12'/></clipPath></defs>"
            "<g clip-path='url(#moldura-mapa-sp)'>"+fundo_geosampa(projetar)
            +"<g class='pontos-secoes' font-family='Segoe UI, sans-serif' font-size='16' font-weight='700'>"
            +"".join(pontos)+f"</g><rect x='23' y='{bar_y-30}' width='{escala+24:.2f}' height='38' rx='4' fill='#fffef9' fill-opacity='.92'/>"
            +f"<path d='M35 {bar_y-7}V{bar_y}h{escala:.2f}v-7' fill='none' stroke='#425e5c' stroke-width='2'/>"
            +f"<text x='35' y='{bar_y-11}' fill='#405b56' font-size='14'>1 km</text>"
            +"<rect x='496' y='12' width='45' height='29' rx='4' fill='#fffef9' fill-opacity='.92'/>"
            "<text x='505' y='32' fill='#405b56' font-size='17'>↑ N</text></g></svg>"
            "<figcaption>Os pontos indicam os locais de votação cadastrados pelo TSE. A seção 307, em laranja, "
            "reaparece no segundo turno. Base cartográfica da Prefeitura de São Paulo, adaptada do "
            "<a href='https://geosampa.prefeitura.sp.gov.br/'>GeoSampa</a> "
            "(<a href='https://creativecommons.org/licenses/by-sa/4.0/deed.pt-br'>CC BY-SA 4.0</a>). "
            "<a href='dados/base_cartografica_zona_254.json' download>Baixar o recorte do mapa</a>.</figcaption></figure>")


def painel_sao_paulo(d):
    secoes=sorted(d["secoes"],key=lambda s:(s["turno"],s["secao"]))
    resumo=d["resumo"]
    info=resumo["ambos"]
    sec307=next(s for s in secoes if s["turno"]==2)
    tab=[]
    for s in secoes:
        horarios="<br>".join(f"{r['data_hora'][11:]} · L{r['linha']}{indicador_eleitor(r)}" for r in s["registros"])
        tab.append((f"{s['turno']}º",s["secao"],s["local"],f"<strong>{escape(s['nome'])}</strong><small>{escape(s['endereco'])} · {escape(s['bairro'])}</small>",
                    "<code>"+", ".join(s["urnas"])+"</code>",horarios,original(s)))
    return (f"<p>O título <code>{d['titulo_repetido']}</code> aparece em <strong>dez seções de dez locais diferentes</strong> "
            "no primeiro turno, todos na 254ª zona da capital paulista. A ocorrência do segundo turno é da "
            f"<strong>mesma seção {sec307['secao']}, no mesmo endereço e na mesma urna</strong> "
            f"do primeiro, série <code>{sec307['urnas'][0]}</code>.</p>"
            f"<div class='caso-mapa'>{mapa_secoes([s for s in secoes if s['turno']==1])}<div>"
            f"<h3>Dez locais em duas datas</h3><dl class='conta'><dt>4 de outubro · 1º turno</dt>"
            f"<dd>10 locais · 10 urnas · {resumo['por_turno']['1']['registros']} registros</dd>"
            f"<dt>25 de outubro · 2º turno</dt><dd>1 local já contado · {resumo['por_turno']['2']['registros']} registros</dd>"
            f"<dt>Dois turnos reunidos</dt><dd>{info['secoes_turno']} combinações de seção e turno · "
            f"{info['urnas_distintas']} urnas físicas · {info['locais_distintos']} endereços</dd></dl></div></div>"
            f"<p>Em 4 de outubro houve um registro às <b>07:17:46</b> e outros "
            f"<b>{resumo['registros_apos_17h_1t']} entre {resumo['inicio_apos_17h_1t'][11:]} e {resumo['fim_apos_17h_1t'][11:]}</b>. "
            "Desses onze, dez têm marcador de encerramento. O da seção 187, às 17:03:08, ocorreu durante a votação. "
            "Por exemplo, a seção 75 registrou o título às 17:04:44 e a 178 às 17:04:54. "
            "São <b>1,71 km em linha reta e dez segundos</b> entre registros. Com os relógios alinhados, dez segundos seriam insuficientes para o trajeto entre essas duas mesas. "
            "A busca nas dez seções comparou o número com 40 outros títulos registrados. Foram 39 comparações no primeiro turno e 38 no segundo, "
            "pois parte dos títulos reaparece. Nenhum dos 77 pares chegou a duas operações ou menos. "
            "As urnas atribuíram zero habilitações de eleitor a esse número.</p>"
            f"<details><summary>Conferir os dez endereços, as séries e os horários</summary>"
            f"{tabela(['Turno','Seção','Local','Estabelecimento e endereço','Série física','Hora · linha','Fonte'],tab)}</details>"
            f"<p><a data-equipe-prever='1-{d['id_caso'].lower()}' href='#f-1-{d['id_caso'].lower()}'>Ver as comparações de títulos nas dez seções</a> · "
            "<a href='dados/exemplos_ilustrados.json'>Consultar o extrato conferido nos arquivos originais</a> · "
            "<a href='https://brasil.arvor.co/auditoria-2026/mesarios/relatorio.html'>Descrição do caso pela Arvor</a></p>")
