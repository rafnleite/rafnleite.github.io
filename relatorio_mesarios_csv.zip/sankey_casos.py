"""Classifica cada título-turno para os fluxos do diagrama, com o cadastro de 25/10."""
from collections import Counter, defaultdict

from casos_em_aberto import NOTAS, chave, geografia_das_secoes, ler
from logistica import CURTO, EXTREMO, INCERTO, LIMIAR, MESMO, OK


QUATRO_PONTES = "M-36DBCD935AE6"
ERRO_FORTE = "Erro de digitação com evidência forte"
SEM_EVIDENCIA = "Sem evidência de erro de digitação"
INDICIO = "Indício numérico inconclusivo"
SEM_ALTERNATIVO = "Nenhum outro título identificado que explique o registro"
TRAJETO_INDETERMINADO = "Deslocamento indeterminado"
DESFECHO_POR_EDICOES = {1:"Uma edição", 2:"Duas edições", 3:"Três substituições"}


def indice(nome):
    itens = {}
    for r in ler(nome):
        k = chave(r)
        if k in itens:
            raise ValueError(f"Chave duplicada em {nome}: {k}")
        itens[k] = r
    return itens


def classificar(parecer, teste):
    if parecer == MESMO:
        return "Mesmo local", "Seções no mesmo local"
    if parecer in (OK, LIMIAR):
        return "Deslocamento plausível", "Trajeto com folga" if parecer == OK else "Trajeto com pouca folga"
    custos = [int(teste["custo_ampliado_registro_"+t]) for t in ("turno","outro_turno")
              if teste["custo_ampliado_registro_"+t]]
    if custos:
        return "Título semelhante", DESFECHO_POR_EDICOES[min(custos)]
    if any(teste["custo_ampliado_mencao_"+t] for t in ("turno","outro_turno")):
        return "Título semelhante", "Só em outra menção"
    return {
        CURTO: ("Avaliação em aberto","Rota excedida"),
        EXTREMO: ("Avaliação em aberto","Extremo sem título reconstruído"),
        INCERTO: ("Trajeto sem estimativa","Sem rota estimada"),
    }[parecer]


def obter(fichas=None):
    from avaliar_sem_rota import avaliar
    if fichas is None:
        from fichas_digitacao import preparar_fichas
        fichas = preparar_fichas()
    casos = indice("todos_casos")
    geo = indice("logistica_por_caso_revisao")
    sem_rota = avaliar()
    if sem_rota.keys() != {k for k, r in geo.items() if r["avaliacao"] == INCERTO}:
        raise ValueError("A revisão dos deslocamentos sem rota diverge do cadastro de 25/10.")
    testes = indice("duas_edicoes_casos")
    if geo.keys() != testes.keys() or not geo.keys() <= casos.keys():
        raise ValueError("Os universos da revisão de locais e do teste numérico divergem.")
    secoes = defaultdict(list)
    for r in ler("secoes_por_caso"):
        local = f"{r['municipio'].title()}/{r['uf']} Z{r['zona']} S{r['secao']}"
        secoes[chave(r)].append(local)
    origens = {}
    for r in ler("enderecos"):
        ref = f"{r['uf']}/{int(r['codigo_municipio']):05d}/Z{int(r['zona']):04d}/S{int(r['secao']):04d}"
        origens[r["turno"],ref] = (r["uf"],r["codigo_municipio"],r["zona"],r["local"])

    def locais_do_caso(r):
        return {origens[r["turno"],ref] for ref in r["referencias_secoes"].split(" | ")}

    saida = []
    for k, r in casos.items():
        geo_r = geo.get(k)
        if geo_r is None and r["classe"] != MESMO:
            raise ValueError(f"Caso entre locais da Arvor sem revisão: {k}")
        parecer = geo_r["avaliacao"] if geo_r else MESMO
        locais = locais_do_caso(r)
        if (len(locais) == 1) != (parecer == MESMO):
            raise ValueError(f"Cadastro de 25/10 e trajetos divergentes em {k}")
        ident = r["id_caso"]
        grupo, desfecho = classificar(parecer, testes.get(k))
        contexto = NOTAS.get(ident, "")
        if k in fichas:
            f = fichas[k]
            contexto = " ".join(s for s in (f["forca"]+".", contexto) if s)
            if f["categoria"] == "forte":
                grupo = desfecho = ERRO_FORTE
            else:
                grupo, desfecho = "Avaliação em aberto", "Indício numérico inconclusivo"
        if parecer in (OK,LIMIAR) and any(v for c,v in testes[k].items() if c.startswith("custo_ampliado_")):
            contexto = "A comparação também encontra outro número compatível em até duas operações."
        if k in sem_rota:
            revisao = sem_rota[k]
            if revisao["plausivel"]:
                grupo, desfecho = "Deslocamento plausível", "Remanejamento plausível sem rota"
            elif grupo == "Trajeto sem estimativa":
                grupo = "Avaliação em aberto"
            contexto = " ".join(filter(None, (revisao["justificativa"], contexto)))
        saida.append(dict(turno=k[0],titulo=k[1],id_caso=ident,extremo=parecer==EXTREMO,
                          locais="Mesmo local" if parecer==MESMO else "Locais distintos",
                          grupo=grupo,desfecho=desfecho,contexto=contexto,parecer=parecer,
                          secoes=" | ".join(dict.fromkeys(secoes[k])), **geografia_das_secoes(locais)))
    adicionais=[]
    for r in ler("repeticoes_adicionais"):
        locais = locais_do_caso(r)
        if chave(r) in casos or len(locais)!=1:
            raise ValueError("Rever a origem ou o local de um caso suplementar.")
        adicionais.append(dict(turno=r["turno"],titulo=r["titulo"],id_caso=r["id_local"],
                               locais="Mesmo local",grupo="Mesmo local",desfecho="Seções no mesmo local",
                               extremo=False,contexto=r["municipio"],secoes=r["referencias_secoes"],parecer=MESMO,
                               **geografia_das_secoes(locais)))
    if len({chave(r) for r in adicionais}) != len(adicionais):
        raise ValueError("Caso de contingência contado duas vezes.")
    return saida, adicionais


def aplicar_margem(casos, cenarios):
    from relogios import COMPATIVEL, GEOMETRICO, IMPROVAVEL, INDETERMINADO
    if cenarios.keys() != {chave(r) for r in casos if r["locais"] == "Locais distintos"}:
        raise ValueError("A revisão dos relógios não cobre exatamente os casos em locais distintos.")
    revisados = []
    for r in casos:
        teste = cenarios.get(chave(r))
        if teste is None:
            revisados.append(dict(r, situacao_relogios=""))
            continue
        situacao = teste["resultado"]
        grupo, desfecho = r["grupo"], r["desfecho"]
        if situacao == COMPATIVEL:
            grupo, desfecho = "Deslocamento plausível", "Trajeto compatível com o intervalo"
        elif situacao == INDETERMINADO:
            grupo = desfecho = TRAJETO_INDETERMINADO
        elif situacao == IMPROVAVEL:
            if desfecho == INDICIO:
                grupo = INDICIO
            elif grupo != ERRO_FORTE:
                grupo, desfecho = SEM_EVIDENCIA, SEM_ALTERNATIVO
        else:
            raise ValueError(f"Resultado desconhecido para {chave(r)}: {situacao}")
        contexto = r["contexto"]
        if teste["base"] == GEOMETRICO:
            contexto = " ".join(filter(None, (contexto, teste["motivo"])))
        revisados.append(dict(r, grupo=grupo, desfecho=desfecho, situacao_relogios=situacao, contexto=contexto))
    return revisados


if __name__ == "__main__":
    from sankey_relatorio import gerar
    casos, adicionais = obter()
    gerar(casos, adicionais)
    print("Casos por turno:", dict(Counter(r["turno"] for r in casos)), "· Adicionais:", len(adicionais))
